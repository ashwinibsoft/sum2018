<?php
class ShortLinkHelper extends AppHelper {
	var $helpers = Array('Html','Form');
	var $requests = array();
	function show($data = ""){
		$ShortLink =& ClassRegistry::init("ShortLink");  
		$short_links = $ShortLink->find('all');
		//print_r($short_links);die;
		foreach($short_links as $short_link){
			$url = "";
			if($short_link['ShortLink']['module']=="Page"|| $link['Link']['module']=="page"){
					$url = Router::url(array('plugin'=>'content_manager','controller'=>'pages','action'=>'view',$short_link['ShortLink']['object_id']));
			}
			$data =str_replace($short_link['ShortLink']['short_code'],$url,$data);
		}
		return $data;
		
	}
	function afterRenderFile($viewFile, $content){
		
		if($this->params['admin']==1 || $this->params['controller']=='admin'){
			return $content;
		}
		if(!empty($this->requests)){
			foreach($this->requests as $request){
				if (strpos($content,$request['short_code']) !== false) {
					$content =str_replace($request['short_code'],$request['url'],$content);
				}
			}
		}
		return $content;
	}
	
	public function __construct(View $view, $settings = array()) {
        parent::__construct($view, $settings);
        self::__set_request();
    }
    
    private function __set_request(){
		
		$this->requests[] = array(
			'short_code'=>'{SERVICES}',
			'url'=>Router::url(array('plugin'=>'content_manager','controller'=>'pages','action'=>'view',15)),
			);
			
		
				
	}
}
?>