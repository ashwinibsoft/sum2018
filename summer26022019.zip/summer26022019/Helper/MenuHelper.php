<?php
class MenuHelper extends AppHelper {
	var $helpers = Array('Html','Form','Session');
	var $options = array(
		'separator'=>''
	);
	var $menu = array();
	var $is_admin_panel= false;
	var $admin_key_name_left = 'Menu.Left';
	var $view;
	public function __construct(View $view, $settings = array()) {
		$this->view = $view;
		//pr($settings);
		$this->options = array_merge($this->options,$settings);
		self::__get_plugins();
		if($this->params['controller']=="admin" || $this->params['admin']){
			$this->is_admin_panel = true;
		}
		parent::__construct($view, $settings);
	}
	
	private function __get_plugins(){
		if(empty($this->options['plugins'])){
			$this->options['plugins'] = Cache::read('plugins');
			if(empty($this->options['plugins'])){
				App::import('Model', 'Plugin');
				$Plugin = new Plugin();
				$this->options['plugins'] = $Plugin->find('all',array('conditions'=>array('Plugin.status'=>1)));
			}
		}
	}
	
	
	function show_pages($pages = array()){
		$data = "";
		if(!empty($pages)){
			//$data.="<ul>";
			foreach($pages as $page){
				$data.="<div class='checkbox'>";
				$data.='<div class="input checkbox">';
				$data.=$this->Form->checkbox('pages.', array('hiddenField' => false,'value'=>$page['Page']['id'],'id'=>'page_'.$page['Page']['id'])).'<label for="page_'.$page['Page']['id'].'">'.$page['Page']['name'].'</label>';
				$data.='<div class="all_child">';
					$data.= $this->show_pages($page['children']);
				$data.='</div>';
				$data.='</div>';
				$data.="</div>";
			}
			//$data.="</ul>";
		}
		return $data;
	}
	function show_links($links = array()){
		$data = "";
		if(!empty($links)){
			$data.='<ol class="dd-list dark">';
			foreach($links as $link){
				$this->request->data['Link'][$link['Link']['id']]['new_window'] = $link['Link']['new_window'];
				$data.='<li class="dd-item" data-id="'.$link['Link']['id'].'">';
				$data .= '<div class="dd-handle">'.$link['Link']['name'];
				if((int)$link['Link']['auto_add']){
					$data .= ' <small style="font-weight:normal;">(Auto Added)</small>';
				}
				$data .= '</div>';
				$data .= '<span class="item-type">'.$link['Link']['module'].'</span>';
				$url = ($link['Link']['module']=='Custom')?'<div class="boxx">
						<label>URL</label>
						'.
						$this->Form->text($link['Link']['id'].'.url',array('value'=>$link['Link']['url']))
						.'
					</div>':'';
				$data .= '<button type="button" data-action="" class="action caret-down"></button>';
				
				$data .= '<div class="caret-div" style="display:none;" >
					<div class="boxx">
						<label>Navigation Label</label>'.
						$this->Form->text($link['Link']['id'].'.name',array('value'=>$link['Link']['name'])).'
					</div>
					<div class="boxx">
						<label>Title Attribute</label>
						'.
						$this->Form->text($link['Link']['id'].'.tag_title',array('value'=>$link['Link']['tag_title'])).
						$this->Form->hidden($link['Link']['id'].'.auto_add',array('value'=>(int)$link['Link']['auto_add']))
						.'
					</div>
					'.$url.'
					<br clear="all" />
					<div class="input checkbox">'.
					$this->Form->checkbox($link['Link']['id'].'.new_window',array('value'=>$link['Link']['new_window'],'id'=>'NewWindow'.$link['Link']['id']))
					.'<label for="NewWindow'.$link['Link']['id'].'">Open link in a new window/tab</label></div>
				<div class="re-link"><a href="javascript:void(0);" class="btn btn-info btn-sm btn-small remove-link">Remove</a></div>
				<div><a href="javascript:void(0);" class="btn btn-info btn-sm btn-small cancel-link">Cancel</a></div>
				</div>';
				if(!empty($link['children'])){
					$data.= $this->show_links($link['children']);
				}
				
				$data.="</li>";
			}
			$data.="</ol>";
		}
		return $data;
	}
	function menus($menu_id=0,$current_id=null,$options = array()){
		$this->options = array_merge($this->options,$options);
		
		$data = "";
		$this->current_id = $current_id;
		$this->menu = ClassRegistry::init("Menu")->read(null,$menu_id);
		
		$Link = ClassRegistry::init("Link");  
		$this->menu['Link'] = $links = $Link->find('threaded',array('recursive'=>2,'conditions'=>array('Link.menu_id'=>$menu_id,'Link.status'=>1),'order'=>array('Link.reorder'=>'ASC')));
		return ($menu_id==1)?self::__menus($links):self::__menus2($links);
	}
	
	function re_create_url($url){
		if(!empty($url)){
			if(is_array($url)){
				$url = Router::url($url);
			}
		}else{
			$url = "javascript:;";
		}
		return $url;
	}
		
	
	function admin_left_menu(){
		$modules = array();
		
		foreach($this->options['plugins'] as $_plugin){
			if(empty($_plugin['Plugin']['title'])){
				continue;
			}
			//echo $_plugin['Plugin']['title'];
			//echo '<br />';
			if(!self::__access_permission($_plugin['Plugin']['title'])){
				continue;
			}
			$path = CakePlugin::path($_plugin['Plugin']['title']);
			if(!file_exists($path.'Config'.DS.'config.php')){
				continue;
			}
			Configure::load($_plugin['Plugin']['title'].'.config','default',false);
			
			if(Configure::check($this->admin_key_name_left)){
				$menus = Configure::read($this->admin_key_name_left);
				foreach($menus as $_menu){
					if(is_array($_menu) && !empty($_menu)){
						$current = 0;
						$url = '';
						if(!empty($_menu['url'])){
							$url = $_menu['url'];
						}
						if(is_string($url)){
							$url = Router::parse($_menu['url']);
						}
						if(empty($_menu['sub_menus'])){
							$_menu['sub_menus'] = array();
						}
						if(!empty($url['plugin']) && ($this->params['plugin']==$url['plugin']  || self::__have_active_child($_menu['sub_menus']) ) && !$this->request->query('popup')){
							$current =1;
						}
						$_menu['current'] = $current;
						$modules[] = $_menu;
					}
				}
				Configure::delete($this->admin_key_name_left);
			}
		}
		usort($modules,'sortbyorder');
		//pr($modules);
		return $this->view->element('admin/left_menu',array('menus'=>$modules));
	}
	
	
	private function __have_active_child($sub_menus = array()){
		$current = 0;
		
		foreach($sub_menus as $_sub_menu){
			if(is_string($_sub_menu['url'])){
				
			}
			if(is_array($_sub_menu['url'])){
				if(
					(!empty($_sub_menu['url']['plugin']) && $_sub_menu['url']['plugin']==$this->params['plugin']) ||
					(empty($this->params['plugin']) && $_sub_menu['url']['controller']==$this->params['controller'])
				
				){
					$current = 1;
				}
			}
		}
		return $current;
	}
	private function __access_permission($plugin = ''){
		if(empty($plugin) || $plugin == ''){
			return false;
		}
		//print_r($this->options['full_permissions']['groups']);die;
		if(in_array($this->options['user_group_id'],$this->options['full_permissions']['groups'])){
				return true;
		}
		if(in_array($this->options['user_id'],$this->options['full_permissions']['users'])){
				return true;
		}
		if(!empty($this->options['allow']) && in_array(Inflector::camelize($this->params['plugin']),$this->options['allow'])){
			return true;
		}
		
		if(!empty($this->options['user_group_id'])){
		if(!empty($this->options['permissions'][$plugin])&& $this->options['permissions'][$plugin]!=0){
				return true;
			
		}
		}
	
		
		/*if($this->options['user_group_id']==19){
			if(!empty($this->options['permissions'][$plugin]) && $this->options['permissions'][$plugin]!=0){
				
				return true;
			}
		}*/
		return false;
	}
	
	public function access_permission($plugin = ''){
		return self::__access_permission($plugin);
	}
	private function __modify_permission($plugin = ''){
		if(empty($plugin) || $plugin == ''){
			return false;
		}
		//print_r($this->options['full_permissions']['groups']);die;
		if(in_array($this->options['user_group_id'],$this->options['full_permissions']['groups'])){
				return true;
		}
		if(in_array($this->options['user_id'],$this->options['full_permissions']['users'])){
				return true;
		}
		if(!empty($this->options['allow']) && in_array(Inflector::camelize($this->params['plugin']),$this->options['allow'])){
			return true;
		}
		
		if(!empty($this->options['user_group_id'])){
		if(!empty($this->options['permissions'][$plugin])&& $this->options['permissions'][$plugin]==2){
				return true;
			
		}
		}
	
		
		/*if($this->options['user_group_id']==19){
			if(!empty($this->options['permissions'][$plugin]) && $this->options['permissions'][$plugin]!=0){
				
				return true;
			}
		}*/
		return false;
	}
	public function modify_permission($plugin = ''){
		return self::__modify_permission($plugin);
	}
	
	
	function is_super_admin(){
		if(in_array($this->options['user_group_id'],$this->options['full_permissions']['groups'])){
				return true;
		}
		if(in_array($this->options['user_id'],$this->options['full_permissions']['users'])){
				return true;
		}
		return false;
	}
	private function __menus($links = array(),$parent = 1){
		$data = $class = $li_class = $a_class = "";
		$wrapper = "<ul class='%s'>%s</ul>";
		$inner_wrapper = "<li class='%s'>%s</li>";
		$wrapper_class = 'slimmenu';
		$current_class = 'current';
		if(!empty($this->options['wrapper'])){
			if(!empty($this->options['wrapper']['tag'])){
				$tag = $this->options['wrapper']['tag'];
				if($tag=="div"){
					$wrapper = $inner_wrapper = "<div class='%s'>%s</div>";
				}
			}
			if(!empty($this->options['wrapper']['class'])){
				$wrapper_class = $this->options['wrapper']['class'];
			}
			if(!empty($this->options['current_class'])){
				$current_class = $this->options['current_class'];
			}
		}
		
		if($parent==1){
			$class = $wrapper_class;
		}
		
		if(!empty($links)){
		
			foreach($links as $link){
				$url = "";
				$attr = "";
				$a_class='';
				if($link['Link']['module']=="" || $link['Link']['module']==Null || strtolower($link['Link']['module'])=='custom'){
					$domain = preg_replace("(^https?://)", "", FULL_BASE_URL ).'<br />';
					$url = preg_replace("(^https?://)", "", $link['Link']['url'] ).'<br />';
					$url = trim($url,$domain).'<br />';
					$trim_current_url =  preg_replace("(^https?://)", "",$this->params->here)."<br />";
					if('/'.$url == $trim_current_url){
						$a_class=$current_class;
					}
					if (false !== strpos($link['Link']['url'],$this->params->here)) {
						//$a_class=$current_class;
					}
					$url = $link['Link']['url']; 
				}else if($link['Link']['module']=="Page"|| $link['Link']['module']=="page"){
					if($this->params['plugin']=="content_manager" && $this->params['controller']=="pages" && $this->current_id==$link['Link']['ref_id']){
						$a_class=$current_class;
					}else if($this->params['plugin']=="news_manager" && $this->params['controller']=="news_articles" && $this->current_id==$link['Link']['ref_id']){
						$a_class=$current_class;
					}
					$url = Router::url(array('plugin'=>'content_manager','controller'=>'pages','action'=>'view',$link['Link']['ref_id']));
				}else if($link['Link']['module']=="Gallery"|| $link['Link']['module']=="gallery"){
					if($this->params['plugin']=="gallery_manager" && $this->params['controller']=="galleries" && $this->params['action']=="index" && $this->current_id==$link['Link']['ref_id']){
						$a_class=$current_class;
					}
					
					$url = Router::url(array('plugin'=>'gallery_manager','controller'=>'galleries','action'=>'index',$link['Link']['ref_id']));
				}
				if($link['Link']['new_window']==1){
					$attr = 'target="_blank"';
				}
				
				
				//$_data ='<a href="'.$url.'" '.$attr.' class="'.$a_class.'" >'.$link['Link']['name'].'</a>';
				$_data ='<a href="'.$url.'" '.$attr.' class="'.$a_class.'" title="'.$link['Link']['tag_title'].'" >'.$link['Link']['name'].'</a>';
				
				
				$_data .= self::__menus($link['children'],0);
				$data .= sprintf($inner_wrapper,$a_class,$_data);
			}
			if($parent==0){
				$wrapper_class = "wsmenu-submenu";
			}
			
			$data = sprintf($wrapper,$wrapper_class,$data);
		}
		return $data;
	}
	private function __menus2($links = array()){
		$data = $class = $li_class = $a_class = "";
		if(!empty($links)){
			$data .= '<ul>';
			foreach($links as $link){
				$url = "";
				$attr = "";
				if($link['Link']['module']=="" || $link['Link']['module']==Null || strtolower($link['Link']['module'])=='custom'){
					$url = $link['Link']['url']; 
				}else if($link['Link']['module']=="Page"|| $link['Link']['module']=="page"){
					$url = Router::url(array('plugin'=>'content_manager','controller'=>'pages','action'=>'view',$link['Link']['ref_id']));
				}else if($link['Link']['module']=="Gallery"|| $link['Link']['module']=="gallery"){
					$url = Router::url(array('plugin'=>'gallery_manager','controller'=>'galleries','action'=>'index',$link['Link']['ref_id']));
				}
				if($link['Link']['new_window']==1){
					$attr = 'target="_blank"';
				}
				if(($link['Link']['module']=="Page"|| $link['Link']['module']=="page") && ($link['Link']['ref_id']==21)){
					$url = Router::url(array('plugin'=>'content_manager','controller'=>'galleries','action'=>'index'));
				}
				$data.='<li>';
				
				if($link['Link']['ref_id']==1){
					$data .='<a href="/" '.$attr.' class="'.$a_class.'" title="'.$link['Link']['tag_title'].'" >'.$link['Link']['name'];
				}else{
					//$data .='<a href="'.$url.'" '.$attr.' class="'.$a_class.'" >'.$link['Link']['name'];
					$data .='<a href="'.$url.'" '.$attr.' class="'.$a_class.'" title="'.$link['Link']['tag_title'].'" >'.$link['Link']['name'];
				}
				$data.='</a>';
				$data .= $this->options['separator'];
				if(!empty($link['children'])){
					$data .= self::__menus2($link['children']);
				}
				$data .= '</li>';
				
			}
			$data .= '</ul>';
			
		}
		return rtrim($data,$this->options['separator']);
	}
	function afterRenderFile($viewFile,$content){
		if(Configure::read('show_template_path')==1){
			$content = "<div style=''><span style='background:red;  top:0; left:0;'>".$viewFile."</span></div>".$content;
		}
		return $content;
	}
	
	function access_authorize($module=''){
		$permissions = json_decode($this->Session->read('Auth.User.UserGroups.permissions'),true);
		if(in_array($module,$permissions['access'])){
			return true;
		}
		return false;
	}
	function is_access_settings(){
		if(in_array($this->options['user_group_id'],$this->options['full_permissions']['groups'])){
				return true;
		}
		if(in_array($this->options['user_id'],$this->options['full_permissions']['users'])){
				return true;
		}
		
		return $this->Session->read('Auth.User.UserGroups.is_access_settings');
	}
	
}

?>