<?php
class MemberAuthHelper extends AppHelper {
	public $helpers = array("Session","Html");
	var $sessionKey = "";
	var $name = "";
	var $id = null;
	var $member_data = array();
	
	public function __construct(View $view, $settings = array()) {
		$this->settings = $settings;
		//pr($this->settings);
		//print_r($session->read('MemberAuth'));die;
		$this->member_data = $settings['active_user'];
		$this->name = $settings['name'];
		parent::__construct($view, $settings);
	}
	
	public function get_active_user_full_name(){
		//echo '<pre>';print_r($this->member_data);die;
		if(!empty($this->member_data[$this->name])){
			//if($this->member_data['memberType']==1){
				return ucfirst($this->member_data[$this->name]['first_name']).' '.ucfirst($this->member_data[$this->name]['last_name']);
			//}
			//else if($this->member_data['memberType']==2){
			//	return ucfirst($this->member_data[$this->name]['contact_person']);
			//}else if($this->member_data['memberType']==3){
			//	return ucfirst($this->member_data[$this->name]['name']);
			//}
		}
		return "";
	}
	
	public function get_city_name(){
		if(!empty($this->member_data[$this->name])){
			if($this->member_data['memberType']==1){
				return $this->member_data[$this->name]['city'];
			}
			else if($this->member_data['memberType']==2){
				return $this->member_data[$this->name]['city'];
			}else if($this->member_data['memberType']==3){
				return $this->member_data[$this->name]['city'];
			}
		}
		return "";
	}
	public function get_company_name(){
		if($this->member_data['memberType']==2){
			return ucfirst($this->member_data[$this->name]['company_name']);
		} else {
			return null;
		}
	}
	
	public function get_member_type(){
		$member_type = $this->member_data['memberType'];
		return $member_type;
	}
	public function get_account_type(){
		$account_type = '';
		$member_type = $this->member_data['memberType'];
		if($member_type==1){
			$account_type = $this->member_data[$this->name]['account_type'];
		}
		return $account_type;
	}
	public function get_account_owner_status(){
		$status = $this->member_data[$this->name]['status'];
		return $status;
	}
	public function get_country_name($country_id=null){
		$Country = ClassRegistry::init("Country");
		if(!empty($country_id)){
			$country_info = $Country->find('first',array('conditions'=>array('Country.id'=>$country_id)));
			$c_name = $country_info['Country']['countryName'];
			return $c_name;
		} else {
			return 'N/A';
		}
	}
	
	public function check_employee_profile(){
		$member_id = $this->member_data[$this->name]['id'];
		$EmployeeAccrual = ClassRegistry::init("EmployeeAccrual");
		$EmployeeElectronicDetail = ClassRegistry::init("EmployeeElectronicDetail");
		$EmployeeHrInformation = ClassRegistry::init("EmployeeHrInformation");
		$i_details = $EmployeeElectronicDetail->find('first',array('conditions'=>array('EmployeeElectronicDetail.employee_id'=>$member_id)));
		$hr_info = $EmployeeHrInformation->find('first',array('conditions'=>array('EmployeeHrInformation.employee_id'=>$member_id)));
		if(empty($i_details) || empty($hr_info)){
			return false;
		}
		return true;
	}
	
	function is_account_owner(){
		$memberType = $this->member_data['memberType'];
		if($memberType==1){
			return true;
		} else {
			return false;
		}
	}
	
	public function is_accountant(){
		$memberType = $this->member_data['memberType'];
		if($memberType==3){
			$is_accountant = $this->member_data[$this->name]['is_accountant'];
			if($is_accountant==1){
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	public function get_member_account_status(){
		$status = $this->member_data[$this->name]['status'];
		return $status;
	}
	
	public function get_member_id(){
		$active_user_id = $this->member_data[$this->name]['id'];
		return $active_user_id;
	}
	
	function get_client_status($client_id=null){
		$clientinfo = array();
		$status = '';
		$Client = ClassRegistry::init('AccountManager.Client');
		$member_type = $this->member_data['memberType'];
		if(!empty($client_id)){
			$cid = $client_id;
		} else {
			if($member_type==1){
				$c_id = $this->member_data[$this->name]['id'];
				$client_id = $c_id;
			}
			else if($member_type==2){
				$c_id = $this->member_data[$this->name]['client_id'];
				$client_id = $c_id;
			}
			else if($member_type==3){
				$c_id = $this->member_data[$this->name]['client_id'];
				$client_id = $c_id;
			}
		}
		$clientinfo = $Client->find('first',array('conditions'=>array('Client.id'=>$client_id)));
		if(!empty($clientinfo)){
			$status = $clientinfo['Client']['status'];
			return $status;
		}
	}
	

}
?>