<?php 
class ShortCodeHelper extends AppHelper{
	var $helpers = Array('Html','Form','System');
	var $current_id=null;
	var $requests = array();
	var $view;
	public function __construct(View $view, $settings = array()) {
		$this->requests = $settings;
		$this->view = $view;
		parent::__construct($view, $settings);
	}
	function afterRenderFile($viewFile, $content){
		if($this->params['admin']==1 || $this->params['controller']=='admin'){
			return $content;
		}
		
		
		if(!empty($this->requests)){
			foreach($this->requests as $code=>$value){
				if(!$this->is_html($value)){
					$value = nl2br($value);
				}
				$content =str_replace($code,$value,$content);
			}
		}
		return $content;
	}
	function is_html($string){
		return preg_match("/<[^<]+>/",$string,$m) != 0;
	}
	
}
?>


