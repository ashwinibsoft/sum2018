<?php
App::uses('AppModel', 'Model');
class Route extends AppModel{
	public $name = "Route";
}
?>