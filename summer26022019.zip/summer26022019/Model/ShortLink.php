<?php
Class ShortLink extends AppModel {
	public $name = "ShortLink";
}
?>