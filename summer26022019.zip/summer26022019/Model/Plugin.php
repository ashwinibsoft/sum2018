<?php
// app/Model/User.php
class Plugin extends AppModel 
{
    public $name = "Plugin";
   
}
?>