<?php
App::uses('AppModel', 'Model');
Class GalleryManagerAppModel extends AppModel {
}
?>