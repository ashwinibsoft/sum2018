<?php
App::uses('GalleryManagerAppModel', 'GalleryManager.Model');
class Gallery extends GalleryManagerAppModel {
	public $name = 'Gallery';
	public $validate = array(
			'name'=>array(
					'rule1'=> array('rule'=> array('maxLength', 150),'message'=>'Title should be less than 150 character(s)'
),
					'rule2'=>array('rule' =>'notEmpty','message'=>'Please enter gallery name.'),
				),
			'slug_url'=>array(
				'rule1'=>array('rule' => 'is_valid_url','message' => 'Please enter text in lower case without any space.'),
				'rule2'=>array('rule' => 'check_slug_url','message' => 'This slug url is already associated with other gallery or module')
				)
		
				
		    );
     
	function validate_image() {
		if((!empty($this->data['Gallery']['id'])) && $this->data['Gallery']['image']['name']=='') {
			return true;
		}else{
			if(!empty($this->data['Gallery']['image']['name'])) {
				$file_part = explode('.',$this->data['Gallery']['image']['name']);
				$ext = array_pop($file_part);		
				if(!in_array(strtolower($ext),array('gif', 'jpeg', 'png', 'jpg'))) {
					return false;
				}
			}
		return true;
		}
	}
	
	public function check_size(){
		if((!empty($this->data['Gallery']['id'])) && $this->data['Gallery']['image']['tmp_name']=='') {
			return true;
		}else {
			if($this->data['Gallery']['image']['error'] < 1){
				$imgSize = @getImageSize($this->data['Gallery']['image']['tmp_name']);
				//if(($imgSize[0]>=120 && $imgSize[0]<=285) && ($imgSize[1]>=50 && $imgSize[1]<=62))
				if($imgSize[0] >=50 && $imgSize[1] >= 50)
				{
					return true;
				}
			}
			return false;
		}
	}
	function check_slug_url(){
		if((!empty($this->data['Gallery']['id'])) && !empty($this->data['Gallery']['slug_url'])) {
			if($this->_check_uri_exist_on_other($this->data['Gallery']['slug_url'],'Gallery',$this->data['Gallery']['id'])){
				return false;
			}else{
				return true;
			}
		}
		return true;
	}
	function is_valid_url(){
		if((!empty($this->data['Gallery']['id'])) && !empty($this->data['Gallery']['slug_url'])) {
			return preg_match('|^[a-z-.]+$|', $this->data['Gallery']['slug_url']);
		}
		return true;
	}
	
	
}
?>