<?php
App::uses('GalleryManagerAppModel', 'GalleryManager.Model');
class GalleryImage extends GalleryManagerAppModel {
	public $name = 'GalleryImage';
	public $actsAs = array('Multivalidatable');
	public $validationSets = array(
			'gallery_image_edit'=>array(
				'title'=>array(
					'rule1' => array('rule' => 'notEmpty','message' => 'Please enter image title.'),
					'rule2' => array('rule' => array('maxLength', 255),'message' => 'Name should be less than 255 charcter(s).')
					),
			)
	);
}
?>