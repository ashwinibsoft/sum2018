<?php
$config = array();
$config['Name']['Plugin'] = "Gallery Manager";
/*$config['Menu']['Left'] = array(
					array(
					'position'=>2,
					'icon'=>'fa-th-large tip',
					'title'=>'Gallery Manager',
					'url'=>array('plugin'=>'gallery_manager','controller'=>'galleries','action'=>'admin_index','admin'=>true)
					)
				);*/
$config['Folder']['Gallery'] = "gallery";
$config['Path']['Gallery'] =  WWW_ROOT.'img'.DS.$config['Folder']['Gallery'].DS;
$config['Path']['NoImage'] =  WWW_ROOT.'img'.DS.'site'.DS.'noimage.jpg';
$config['image_admin_edit_width'] = "160";
$config['image_admin_edit_height'] = "160";

$config['image_front_gallery_slideshow_width'] = "310";
$config['image_front_gallery_slideshow_height'] = "190";


/*Gallery SEO Information trigger*/
$config['Section']['seo'] = true; 


?>
