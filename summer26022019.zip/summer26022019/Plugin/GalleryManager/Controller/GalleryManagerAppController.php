<?php
class GalleryManagerAppController extends AppController{
	public $page = array();
	function beforeFilter() {
		parent::beforeFilter();	
		Configure::load('GalleryManager.config');
	}
}
?>