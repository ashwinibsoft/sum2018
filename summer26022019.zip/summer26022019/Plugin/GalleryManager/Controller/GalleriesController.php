<?php
class GalleriesController extends GalleryManagerAppController{
	var $name = 'Galleries';
	var $helpers = array('Form');
	var $uses = array('GalleryManager.Gallery','GalleryManager.GalleryImage','ContentManager.Page');
	var $paginate = array();
	function admin_index($search=null,$limit=10){
		$this->paginate = array();
		$condition = null;
		if($search=="_blank"){
			$search=null;
		}
		if($this->request->is('post')){
			if(!empty($this->request->data['search'])){
				$search = urldecode($this->request->data['search']);
			}else{
				$search = '_blank';
			}
			if(!empty($this->request->data['limit'])){
				$limit = $this->request->data['limit'];
			}else{
				$limit = 10;
			}
			$this->redirect(array('plugin'=>'gallery_manager','controller'=>'galleries','action'=>'index',$search,$limit));
		}
		if($search!=null){
			$search = urldecode($search);
			$condition['Gallery.name like'] = '%'.$search.'%';
		}
		$this->paginate['limit']=$limit;
		$this->Gallery->virtualFields['total_images'] = "SELECT COUNT(`id`) FROM `gallery_images` as `GalleryImage` WHERE `GalleryImage`.`gallery_id` = `Gallery`.`id`"; 
		/*
		$this->Gallery->bindModel(array(
					'hasMany' => array(
								'GalleryImage' => array(
												'className'=>'GalleryImage',
											),
								)
					));
		*/ 
		$this->paginate['order']=array('Gallery.id'=>'DESC');
		$galleries=$this->paginate("Gallery", $condition);
		
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/home'),
			'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/gallery_manager/galleries/index'),
			'name'=>'Manage Gallery'
		);
		$this->heading =  array("Manage","Gallery");
		$this->set('galleries', $galleries);
		$this->set('search',$search);
		$this->set('limit',$limit);
		$this->set('url','/'.$this->params->url);
		if($this->request->is('ajax')){
			$this->layout = '';
			$this -> Render('ajax_admin_index');
		   
		}   
	}
	
	function admin_manage_image($id=null,$popup1=null){		
		if($id==null){
			throw new NotFoundException('404 Error - Page not found');
		}
		$scripts = array(
			'/plugins/dropzone/dropzone.js',
			'/plugins/dropzone/dropzone-amd-module.js',
			'/plugins/jquery-superbox/js/superbox.js'
		);
		$css = array(
			'/plugins/dropzone/css/basic.css',
			'/plugins/dropzone/css/dropzone.css',
			'/plugins/jquery-superbox/css/style.css',
			'//code.jquery.com/ui/1.8.4/themes/smoothness/jquery-ui.css'
		);
		
		$this->System->add_js($scripts);
		$this->System->add_css($css);
		$popup = $this->request->query('popup');
		//echo $closewindow = $popup1;
		$gallery_images = array();
		$this->breadcrumbs[] = array(
		'url'=>Router::url('/admin/home'),
		'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/gallery_manager/galleries'),
				'name'=>'Manage Gallery'
		);
		
		
		
		//$galleries = $this->Gallery->find('all');
		//echo '<pre>';print_r($galleries);die;
		
		if(!empty($this->request->data) && $this->validation()){
				self::__add2();
			if($popup==1){
				$this->redirect(array('action' => 'admin_created',$this->Gallery->id,'?'=>array('popup'=>'1')));
			}
			else{
				$this->redirect(array('controller'=>'galleries','action'=>'admin_manage_image',$id,'?'=>array('back'=>$this->request->data['Gallery']['url_back_redirect'])));
			}
			if($this->request->data['submit']=='Save'){
				$this->redirect(array('plugin'=>'gallery_manager','controller' => 'galleries', 'action' => 'admin_manage_image',$id));
			}else{
				//$this->redirect($this->request->data['Gallery']['redirect']);
				if(isset($this->request->data['save'])){
					//$this->redirect(array('controller'=>'galleries','action'=>'admin_add',$page_id));
				}else{
					//$this->redirect(array('controller'=>'galleries','action'=>'admin_index',$page_id));
				}
			}
		}
		else{
			if($id!=null){
				$this->Gallery->bindModel(
					array('hasMany' => array(
							'GalleryImage' => array(
								'className' => 'GalleryImage',
								'order' => array('GalleryImage.reorder'=>'ASC','GalleryImage.id'=>'DESC')
							)
						)
					)
				);
			$this->GalleryImage->bindModel(
			array('belongsTo' => array(
					'Gallery' => array(
						'className' => 'Gallery'
					)
				)
			)
		);
				$this->request->data = $this->Gallery->read(null,$id);
				
				//$this->request->data['Gallery']['slug_url'] = $this->Gallery->get_uri('Gallery',$id);
				$gallery_images=$this->request->data;
			}else{
				$this->request->data = array();
			}
		} 
		
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/gallery_manager/galleries/manage_image/'.$id),
				'name'=>sprintf("Manage Images (%s)",$this->request->data['Gallery']['name'])
		);
		$this->heading =  array("Manage","Images ".sprintf("(%s)",$this->request->data['Gallery']['name']));
		$referer_url = $this->request->query('back');
		if(!empty($referer_url)){
			$referer_url= $this->request->query('back');
		}else{
			$referer_url=(Controller::referer()=="/")? Router::url('/admin/gallery_manager/galleries',true) :Controller::referer();
		}
		
				
		$this->set('referer_url',$referer_url);
		
		
		$this->set('gallery_images',$gallery_images);
		$this->set('id',$id);
		if($popup==1){
			self::__popup_admin_add();
		}
	}
	
	public function get_record(){
		$home_galleries=$this->GalleryImage->find('all',array('conditions'=>array('GalleryImage.gallery_id'=>$this->request->pass['id']))); // Load Galleries
		return $home_galleries;
	} 
	private function __image_edit_validation(){
		if(!empty($this->request->data['GalleryImage']['form'])){
			$this->GalleryImage->setValidation($this->request->data['GalleryImage']['form']);
		}
		$this->GalleryImage->set($this->request->data);
		
		if($this->request->is('ajax')){
			$this->autoRender = false;
			$result = array();
			if($this->GalleryImage->validates()){
				return true;
			}else{
				$result['error'] = 1;
				$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
			}
			$errors = array();
			$result['errors'] = $this->GalleryImage->validationErrors;
			foreach($result['errors'] as $field => $data){
			  $errors['Page'.Inflector::camelize($field)] = array_pop($data);
			}
			$result['errors'] = $errors;
			$view = new View();
			$result['message'] = $view->element('admin/message');
			echo json_encode($result);
			return;
		}
		return $this->GalleryImage->validates();
	}
	
	public function admin_gallery_image_update($gallery_image_id = ''){
		
		

		if($this->request->is('ajax')){
			$this->layout = '';
		}
		
		$this->loadModel('GalleryManager.GalleryImage');
		$gallery_image = array();
		$gallery_image = $this->GalleryImage->read(null,$gallery_image_id);
		if(!empty($this->request->data) && self::__image_edit_validation()){
			$db = $this->GalleryImage->getDataSource();
			$title = $db->value($this->request->data['GalleryImage']['title'], 'string');
			$description = $db->value($this->request->data['GalleryImage']['description'], 'string');
			//$featured = $db->value($this->request->data['GalleryImage']['featured']);
			$featured = null;
			//echo $featured;die;
			
			$this->GalleryImage->updateAll(
				array('GalleryImage.title' => $title,'GalleryImage.description'=>$description,'GalleryImage.featured'=>$featured),
				array('GalleryImage.id' => $this->request->data['GalleryImage']['id'])
			);
			
			if(!empty($this->request->data['GalleryImage']['featured'])){
			$imageid= $this->request->data['GalleryImage']['id'];
			$gallerylId=$this->GalleryImage->find('all',array('conditions'=> array('GalleryImage.id' => $imageid)));
			foreach($gallerylId as $glid){

			$galleryid=$glid['GalleryImage']['gallery_id'];  
			}
			$alreadyfeatured=$this->GalleryImage->find('all', array('GalleryImage.gallery_id'=>$galleryid,'featured'=>1));
			if(!empty($alreadyfeatured)){
			$this->GalleryImage->updateAll(array('featured'=>0), array('GalleryImage.gallery_id'=>$galleryid));
			}
			$galleryUpdate=$this->GalleryImage->updateAll(array('featured'=>1), array('GalleryImage.gallery_id'=>$galleryid,'GalleryImage.id'=>$imageid));
		    }
			$this->Session->setFlash(__('Image properties has been updated successfully'));
			
			if($this->request->is('ajax')){
				$this->autoRender = false;
				$result = array(
					'error'=>0,
					'errors'=>array(),
					'success'=>1,
					'data'=>array(),
					'message'=>''
				);
				
				$view = new View();
				$result['message'] = $view->element('admin/message');
				echo json_encode($result);
				return;
			}
			$this->redirect(array('action'=>'admin_gallery_image_update',$gallery_image_id));
			
			
		}else{
			if(!empty($this->request->data)){
				$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
			}else{
				if($gallery_image_id!=null){
					$this->request->data = $gallery_image;
					if($this->request->is('ajax')){
						$this->request->data['GalleryImage']['return'] = 'json';
					}
				}else{
					$this->request->data = array();
				}
			}
		}
		$this->set('gallery_image',$gallery_image);
		
	}
	
	private function __popup_admin_add(){
	//	array_push(self::$script_for_layout,'dropzone.js');
	//	array_push(self::$css_for_layout,'basic.css','dropzone.css');
		
		$session_images = $this->Session->read('tmp.images');
		if(!empty($session_images)){
				foreach($session_images as $_image){
					if(!empty($_image) && $_image!="" && file_exists(Configure::read('Path.Gallery').$_image)){
						unlink(Configure::read('Path.Gallery').$_image);
					}
				}
		}
		$this->Session->delete('tmp.images');
		$this->render('popup_admin_add');
	}
	public function admin_popup_manage_image($id=null,$popup1=null){		
		if($id==null){
			throw new NotFoundException('404 Error - Page not found');
		}
		$scripts = array(
			'/plugins/dropzone/dropzone.js',
			'/plugins/dropzone/dropzone-amd-module.js',
			'/plugins/jquery-superbox/js/superbox.js'
		);
		$css = array(
			'/plugins/dropzone/css/basic.css',
			'/plugins/dropzone/css/dropzone.css',
			'/plugins/jquery-superbox/css/style.css',
			'//code.jquery.com/ui/1.8.4/themes/smoothness/jquery-ui.css'
		);
		
		$this->System->add_js($scripts);
		$this->System->add_css($css);
		$popup = $this->request->query('popup');
		//echo $closewindow = $popup1;
		$gallery_images = array();
		$this->breadcrumbs[] = array(
		'url'=>Router::url('/admin/home'),
		'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/gallery_manager/galleries'),
				'name'=>'Manage Gallery'
		);
		
		
		
		//$galleries = $this->Gallery->find('all');
		//echo '<pre>';print_r($galleries);die;
		
		if(!empty($this->request->data) && $this->validation()){
				self::__add2();
			if($popup==1){
				$this->redirect(array('action' => 'admin_created',$this->Gallery->id,'?'=>array('popup'=>'1')));
			}
			else{
				$this->redirect(array('controller'=>'galleries','action'=>'admin_manage_image',$id,'?'=>array('back'=>$this->request->data['Gallery']['url_back_redirect'])));
			}
			if($this->request->data['submit']=='Save'){
				$this->redirect(array('plugin'=>'gallery_manager','controller' => 'galleries', 'action' => 'admin_popup_manage_image',$id));
			}else{
				//$this->redirect($this->request->data['Gallery']['redirect']);
				if(isset($this->request->data['save'])){
					//$this->redirect(array('controller'=>'galleries','action'=>'admin_add',$page_id));
				}else{
					//$this->redirect(array('controller'=>'galleries','action'=>'admin_index',$page_id));
				}
			}
		}
		else{
			if($id!=null){
				$this->Gallery->bindModel(
					array('hasMany' => array(
							'GalleryImage' => array(
								'className' => 'GalleryImage',
								'order' => array('GalleryImage.reorder'=>'ASC','GalleryImage.id'=>'DESC')
							)
						)
					)
				);
			$this->GalleryImage->bindModel(
			array('belongsTo' => array(
					'Gallery' => array(
						'className' => 'Gallery'
					)
				)
			)
		);
				$this->request->data = $this->Gallery->read(null,$id);
				
				//$this->request->data['Gallery']['slug_url'] = $this->Gallery->get_uri('Gallery',$id);
				$gallery_images=$this->request->data;
			}else{
				$this->request->data = array();
			}
		} 
		
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/gallery_manager/galleries/manage_image/'.$id),
				'name'=>sprintf("Manage Images (%s)",$this->request->data['Gallery']['name'])
		);
		$this->heading =  array("Manage","Images ".sprintf("(%s)",$this->request->data['Gallery']['name']));
		$referer_url = $this->request->query('back');
		if(!empty($referer_url)){
			$referer_url= $this->request->query('back');
		}else{
			$referer_url=(Controller::referer()=="/")? Router::url('/admin/gallery_manager/galleries',true) :Controller::referer();
		}
		
				
		$this->set('referer_url',$referer_url);
		
		
		$this->set('gallery_images',$gallery_images);
		$this->set('id',$id);
		if($popup==1){
			self::__popup_admin_add();
		}
	}
		
		
	private function __manage_image($image = array()) {
		if ($image['error'] > 0) {
			return null;
		}else{
			$destination = Configure::read('Path.Gallery');
			return $this->System->Image->upload(array('destination'=>$destination,'image'=>$image));
		}
	}
	
	function admin_ajax_add_gallery_image(){
		$this->autoRender = false;
		sleep(5);
	}
	
	
	function admin_upload(){
		Configure::write('debug',0);
		$this->autoRender = false;
		$images = array();
		$session_images = $this->Session->read('tmp.images');
		if(!empty($_POST) && $_POST['action']=="add_new"){
			
			if(!empty($_FILES)){
				foreach($_FILES as $_file){
					
					$images[] = $session_images[] = self::__manage_image($_file);
				}
			}
			$this->Session->write('tmp.images',$session_images);
			echo json_encode($images);
		}
		
		if(!empty($_POST) && $_POST['action']=="delete"){
			if(!empty($_POST['image']) && $_POST['image']!="" && file_exists(Configure::read('Path.Gallery').$_POST['image'])){
				unlink(Configure::read('Path.Gallery').$_POST['image']);
			}
			$session_images = $this->Session->read('tmp.images');
			$_session_images = array();
			foreach($session_images as $_image){
				if($_POST['image']==$_image){
					continue;
				}
				$_session_images[] = $_image;
			}
			$this->Session->write('tmp.images',$_session_images);
		}
		if(!empty($_POST) && $_POST['action']=="delete_session_images"){
			$session_images = $this->Session->read('tmp.images');
			foreach($session_images as $_image){
				if(!empty($_image) && $_image!="" && file_exists(Configure::read('Path.Gallery').$_image)){
					unlink(Configure::read('Path.Gallery').$_image);
				}
			}
			$this->Session->delete('tmp.images');
		}
		return;
	}
	function admin_ajax_upload(){
		$this->autoRender = false;
		$images = array();
		$session_images = $this->Session->read('tmp.images');
		if(!empty($_POST) && $_POST['action']=="add_new"){
			if(!empty($_FILES)){
				foreach($_FILES as $_file){
					$images[] = $session_images[] = self::__manage_image($_file);
				}
			}
			$this->Session->write('tmp.images',$session_images);
			echo json_encode($images);
		}
		
		if(!empty($_POST) && $_POST['action']=="delete"){
			if(!empty($_POST['image']) && $_POST['image']!="" && file_exists(Configure::read('Path.Gallery').$_POST['image'])){
				unlink(Configure::read('Path.Gallery').$_POST['image']);
			}
			$session_images = $this->Session->read('tmp.images');
			$_session_images = array();
			foreach($session_images as $_image){
				if($_POST['image']==$_image){
					continue;
				}
				$_session_images[] = $_image;
			}
			$this->Session->write('tmp.images',$_session_images);
		}
		if(!empty($_POST) && $_POST['action']=="delete_session_images"){
			$session_images = $this->Session->read('tmp.images');
			foreach($session_images as $_image){
				if(!empty($_image) && $_image!="" && file_exists(Configure::read('Path.Gallery').$_image)){
					unlink(Configure::read('Path.Gallery').$_image);
				}
			}
			$this->Session->delete('tmp.images');
		}
		return;
	}
	function ajax_sort(){
		$this->autoRender = false;
		//echo "<pre>";print_r($_POST['sort']);die;
		foreach($_POST['sort'] as $order => $id){
			$gallery= array();
			$gallery['Gallery']['id'] = $id;
			$gallery['Gallery']['reorder'] = $order;
			$this->Gallery->create();
			$this->Gallery->save($gallery);
		}    
	}
	
	function gallery_ajax_sort(){
		$this->autoRender = false;
		//echo "<pre>";print_r($_POST['sort']);die;
		foreach($_POST['sort'] as $order => $id){
			$gallery_image= array();
			$gallery_image['GalleryImage']['id'] = $id;
			$gallery_image['GalleryImage']['reorder'] = $order;
			$this->GalleryImage->create();
			$this->GalleryImage->save($gallery_image);
		}    
	}
	
		function delete_images(){
		$this->autoRender = false;
		if(!empty($this->request->data)){
			$imagesid=$this->request->data['allimgIds'];
			$isFeatured = $this->GalleryImage->find('all',array('conditions'=>array('GalleryImage.featured'=>1,'GalleryImage.id IN('.$imagesid.')')));
			if(!empty($isFeatured)){
				echo json_encode("Featured Selected");die;
			}
			$this->GalleryImage->deleteAll(array('GalleryImage.id IN('.$imagesid.')'), false);
			echo json_encode("DELETED");die;
		}
	}
	function image_featured(){
		$this->autoRender = false;
		if(!empty($this->request->data)){
			$imageid=$this->request->data['imageid'];
			$galleryid=$this->request->data['galleryid'];
			$alreadyfeatured=$this->GalleryImage->find('all', array('GalleryImage.gallery_id'=>$galleryid,'featured'=>1));
			if(!empty($alreadyfeatured)){
				$this->GalleryImage->updateAll(array('featured'=>0), array('GalleryImage.gallery_id'=>$galleryid));
			}
			$galleryUpdate=$this->GalleryImage->updateAll(array('featured'=>1), array('GalleryImage.gallery_id'=>$galleryid,'GalleryImage.id'=>$imageid));
			if($galleryUpdate){
				echo json_encode("DONE");
			}
		}
	}
	

	function admin_add($id=null, $popup1=null){	

		$scripts = array(
			'/plugins/dropzone/dropzone.js',
			'/plugins/dropzone/dropzone-amd-module.js',
			'/plugins/jquery-superbox/js/superbox.js'
		);
		$css = array(
			'/plugins/dropzone/css/basic.css',
			'/plugins/dropzone/css/dropzone.css',
			'/plugins/jquery-superbox/css/style.css',
			'//code.jquery.com/ui/1.8.4/themes/smoothness/jquery-ui.css'
		);
		
		$this->System->add_js($scripts);
		$this->System->add_css($css);
		$popup = $this->request->query('popup');
		//echo $closewindow = $popup1;
		$gallery_images = array();
		$this->breadcrumbs[] = array(
		'url'=>Router::url('/admin/home'),
		'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/gallery_manager/galleries'),
				'name'=>'Manage Gallery'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/gallery_manager/galleries/add'),
				'name'=>($id==null)?'Add Gallery':'Update gallery'
		);
		if($id==null){
			$this->heading =  array("Add","Gallery");
		}else{
			$this->heading =  array("Update","Gallery");
		}
		if(!empty($this->request->data) && $this->validation()){
		
			/* ADMIN DELETE IMAGES FORM */
			if(!empty($this->request->data['Gallery']['action'])){
				
			$data=$this->request->data['Gallery']['image'];
			$action = $this->request->data['Gallery']['action'];
			$ans="0";
			foreach($data as $value){
				if($value!='0'){
					if($action=='Publish'){
						$gallery['GalleryImage']['id'] = $value;
						$gallery['GalleryImage']['status']=1;
						$this->GalleryImage->create();
						$this->GalleryImage->save($gallery);
						$ans="1";
					}
					if($action=='Unpublish'){
						$gallery_img = $this->GalleryImage->find('first',array('conditions'=>array('GalleryImage.id'=>$value)));
						if($gallery_img['GalleryImage']['featured']==1){
							$ans="3";
							}else{
						$gallery['GalleryImage']['id'] = $value;
						$gallery['GalleryImage']['status']=0;
						$this->GalleryImage->create();
						$this->GalleryImage->save($gallery);
						$ans="1";
					}
					}
					if($action=='Delete'){
						$gallery_img = $this->GalleryImage->find('first',array('conditions'=>array('GalleryImage.id'=>$value)));
						if($gallery_img['GalleryImage']['featured']==1){
							$ans="3";
							}else{
								$destination = Configure::read('Path.Gallery').$gallery_img['GalleryImage']['image'];
								if(file_exists($destination)) {
									unlink($destination);		
								}
								$this->GalleryImage->deleteAll(array('GalleryImage.id' => $value), false);
								$ans="2";
							}
					}
				}
			}
		if($ans=="1"){
			$this->Session->setFlash(__('Gallery image has been '.strtolower($this->data['Gallery']['action']).'ed successfully', true));
		}
		else if($ans=="2"){
			$this->Session->setFlash(__('Gallery image has been '.strtolower($this->data['Gallery']['action']).'d successfully', true));
		}else if($ans=="3"){
			$this->Session->setFlash(__('Featured image can not '.strtolower($this->data['Gallery']['action']).' Firstly choose a different featured image', true),'default','','error');
			//$this->Session->setFlash(__('').'. Firstly choose a different featured image', true));
		}else{
			$this->Session->setFlash(__('Please Select image for '.strtolower($this->data['Gallery']['action']).' ', true),'default','','error');
		}
		//$redirect_url=(Controller::referer()=="/")? '/admin/gallery_manager/galleries/':Controller::referer();
		//$this->redirect($redirect_url);
	}
					
			/*END OF ADMIN DELETE IMAGES FORM */
          unset($this->request->data['Gallery']['image']);
				self::__add();
			if($popup==1){
				$this->redirect(array('action' => 'admin_created',$this->Gallery->id,'?'=>array('popup'=>'1')));
			}
			else{
				$this->redirect(array('controller'=>'galleries','action'=>'admin_add',$this->Gallery->id,'?'=>array('back'=>$this->request->data['Gallery']['url_back_redirect'])));
			}
			if($this->request->data['submit']=='Save'){
				$this->redirect(array('plugin'=>'gallery_manager','controller' => 'galleries', 'action' => 'admin_add',$id));
			}else{
				//$this->redirect($this->request->data['Gallery']['redirect']);
				if(isset($this->request->data['save'])){
					//$this->redirect(array('controller'=>'galleries','action'=>'admin_add',$page_id));
				}else{
					//$this->redirect(array('controller'=>'galleries','action'=>'admin_index',$page_id));
				}
			}
		}
		else{
			if($id!=null){
				$this->Gallery->bindModel(
					array('hasMany' => array(
							'GalleryImage' => array(
								'className' => 'GalleryImage',
								'order' => 'GalleryImage.reorder ASC'
							)
						)
					)
				);
			$this->GalleryImage->bindModel(
			array('belongsTo' => array(
					'Gallery' => array(
						'className' => 'Gallery'
					)
				)
			)
		);
				//$this->request->data = $this->Gallery->read(null,$id);
				$this->request->data=$this->Gallery->read(null,$id);
				$this->request->data['Gallery']['slug_url'] = $this->Gallery->get_uri('Gallery',$id);
				$gallery_images=$this->request->data;
				
			}else{
				$this->request->data = array();
			}
		} 
		
		$referer_url = $this->request->query('back');
		if(!empty($referer_url)){
			$referer_url= $this->request->query('back');
		}else{
			$referer_url=(Controller::referer()=="/")? Router::url('/admin/gallery_manager/galleries',true) :Controller::referer();
		}
		
		
		$this->set('referer_url',$referer_url);
		$this->set('gallery_images',$gallery_images);
		$this->set('id',$id);
		//$this->set('GalleryIde',$Gallery);
		if($popup==1){
			self::__popup_admin_add();
		}
	}
	
	
	public function slideshow($gallery_id= null){
		$options = array();
		$options['conditions'] = array('Gallery.id'=>$gallery_id,'Gallery.status'=>1);
		$options['order']=array('Gallery.reorder'=>'ASC','Gallery.id'=>'DESC');
		
		$this->Gallery->bindModel(
			array('hasMany' => array(
					'GalleryImage' => array(
						'className' => 'GalleryImage',
						'limit'=>5
					)
				)
			)
		);
		$gallery_list = $this->Gallery->find('first',$options);
		if(empty($gallery_list) || empty($gallery_list['GalleryImage'])){
			$this->autoRender = false;
		}
		$this->set('galleries',$gallery_list);
	}
	
	protected function __add(){
		if(empty($this->request->data['Gallery']['id'])){
			$this->request->data['Gallery']['status']=1;
			$this->request->data['Gallery']['created_at']=date('Y-m-d H:i:s');
			$this->Session->setFlash(__('Gallery has been added successfully'));
		}else{
			$this->request->data['Gallery']['updated_at']=date('Y-m-d H:i:s');
			$this->Session->setFlash(__('Gallery has been updated successfully'));
		}
		$this->Gallery->create();
		$this->Gallery->save($this->request->data);
		
		$gallery_id = $this->Gallery->id;
		if(!empty($this->request->data['GalleryImage'])){
			foreach($this->request->data['GalleryImage'] as $_image){
				$gallery_images = array();
				$gallery_images['GalleryImage']['id'] = "";
				$gallery_images['GalleryImage']['gallery_id'] = $gallery_id;
				$gallery_images['GalleryImage']['image'] = $_image;
				$gallery_images['GalleryImage']['status'] = 1;
				$gallery_images['GalleryImage']['created_at'] = date('Y-m-d H:i:s');
				$this->GalleryImage->create();
				$this->GalleryImage->save($gallery_images);
			}
		$this->Session->delete('tmp.images');
		}
		
		/* Slug URL Logic Start*/
		$slug_url = '';
		if(Configure::read('Section.seo')){
			if(empty($this->request->data['Gallery']['id'])){
				if(empty($this->request->data['Gallery']['slug_url'])){
					$string = strtolower($this->request->data['Gallery']['name']);
					$slug_url = Inflector::slug($string, '-');
					
				}else if($this->request->data['Gallery']['slug_url']==''){
						$string = strtolower($this->request->data['Gallery']['name']);
						$slug_url = Inflector::slug($string, '-');
					}else{
						$slug_url = $this->request->data['Gallery']['slug_url'];		
					}
			}else{
				$slug_url = $this->request->data['Gallery']['slug_url'];
			}
		}
		/* Slug URL Logic END*/	
		if(!empty($slug_url)){
			$route = array();
			$route['request_uri'] = trim($slug_url);
			$route['object'] = 'Gallery';
			$route['object_id'] = $gallery_id;
			$route['object_name'] = $this->request->data['Gallery']['name'];
			$route['values'] = json_encode(array('plugin'=>'gallery_manager','controller'=>'galleries','action'=>'index','id'=>$gallery_id));
			$this->Gallery->save_routes($route);
		}
	}
	private function __add2(){
		if(empty($this->request->data['Gallery']['id'])){
			$this->request->data['Gallery']['status']=1;
			$this->request->data['Gallery']['created_at']=date('Y-m-d H:i:s');
			$this->Session->setFlash(__('Gallery has been added successfully'));
		}else{
			$this->request->data['Gallery']['updated_at']=date('Y-m-d H:i:s');
			$this->Session->setFlash(__('Gallery has been updated successfully'));
		}
		$this->Gallery->create();
		$this->Gallery->save($this->request->data);
		
		$gallery_id = $this->Gallery->id;
		if(!empty($this->request->data['GalleryImage'])){
			foreach($this->request->data['GalleryImage'] as $_image){
				$gallery_images = array();
				$gallery_images['GalleryImage']['id'] = "";
				$gallery_images['GalleryImage']['gallery_id'] = $gallery_id;
				$gallery_images['GalleryImage']['image'] = $_image;
				$gallery_images['GalleryImage']['status'] = 1;
				$gallery_images['GalleryImage']['created_at'] = date('Y-m-d H:i:s');
				$this->GalleryImage->create();
				$this->GalleryImage->save($gallery_images);
			}
		$this->Session->delete('tmp.images');
		}
		
		
	}
	
	function admin_gallery(){
		$galleries = $this->Gallery->find('all',array('fields'=>array('id','name')));
		$this->set(compact('galleries'));
	}
	function admin_created($gallery_id=null){
		
		$this->set('gallery_id',$gallery_id);
		$this->set('gallery',$this->Gallery->read(null,$gallery_id));
	}
	function validation(){
		$result = array(
			'error'=>1,
			'errors'=>array(),
			'success'=>0,
			'data'=>array(),
			'message'=>''
		);
		if(!empty($this->request->data)){
			$this->Gallery->set($this->request->data);
			if ($this->Gallery->validates()) {
				$result['success'] = 1;
				$result['error'] = 0;
			}else{
				$result['errors'] = $this->Gallery->validationErrors;
				$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
			}
		}
		$_errors = array();
		if(!empty($result['errors'])){
			foreach($result['errors'] as $field => $data){
				$_errors['Gallery'.Inflector::camelize($field)] = array_pop($data);
			}
		}
		$result['errors'] = $_errors;

		if($this->request->is('ajax')){
			$this->autoRender = false;
			if($result['error']==1){
				$view = new View();
				$result['error_message'] = $view->element('admin/message');
			}
			echo json_encode($result);
			return;
		}
		return $result['success']; 
	}
	function admin_view($id=null){
		$this->layout = '';
		$gallery = $this->Gallery->read(null,$id);
		$this->set('gallery',$gallery);
	}
	function admin_delete($id=null){
			$data=$this->request->data['Gallery']['id'];
			$action = $this->request->data['Gallery']['action'];
			$ans="0";
			foreach($data as $value){
				if($value!='0'){
					if($action=='Publish'){
						$gallery['Gallery']['id'] = $value;
						$gallery['Gallery']['status']=1;
						$this->Gallery->create();
						$this->Gallery->save($gallery);
						$ans="1";
					}
					if($action=='Unpublish'){
						$gallery['Gallery']['id'] = $value;
						$gallery['Gallery']['status']=0;
						$this->Gallery->create();
						$this->Gallery->save($gallery);
						$ans="1";
					}
					if($action=='Delete'){
						$gallery_img = $this->GalleryImage->find('all',array('conditions'=>array('GalleryImage.gallery_id'=>$value)));
						foreach($gallery_img as $img){
							$destination = WWW_ROOT . "img/gallery/".$img['GalleryImage']['image'];
							if(file_exists($destination)) {
								unlink($destination);

							}
						}
					$this->Gallery->delete($value);
					$this->GalleryImage->deleteAll(array('GalleryImage.gallery_id' => $value), false);
					$this->Gallery->delete_routes($value,'Gallery');
						$options = array(
						'ref_id'=>$value,
						'module'=>'Gallery',
						);
						$this->Gallery->delete_menu($options);
						
						$this->loadModel('Link');	
						$this->Link->query("Delete FROM`links` WHERE `ref_id`=\"$value\" AND module=\"Gallery\"");
						
						
					$ans="2";
					
					
					
					
					
					
					
					}
				}
			}
		if($ans=="1"){
			$this->Session->setFlash(__('Gallery has been '.strtolower($this->data['Gallery']['action']).'ed successfully', true));
		}
		else if($ans=="2"){
			$this->Session->setFlash(__('Gallery has been '.strtolower($this->data['Gallery']['action']).'d successfully', true));
		}else{
			$this->Session->setFlash(__('Please Select any Gallery', true),'default','','error');
		}
		$redirect_url=(Controller::referer()=="/")? '/admin/gallery_manager/galleries/':Controller::referer();
		$this->redirect($redirect_url);
	}
	
	function admin_delete_image($id=null){
		
			$data=$this->request->data['id'];
			$action = $this->request->data['action'];
			$ans="0";
			foreach($data as $value){
				if($value!='0'){
					if($action=='Publish'){
						$gallery['GalleryImage']['id'] = $value;
						$gallery['GalleryImage']['status']=1;
						$this->GalleryImage->create();
						$this->GalleryImage->save($gallery);
						$ans="1";
					}
					if($action=='Unpublish'){
						$gallery_img = $this->GalleryImage->find('first',array('conditions'=>array('GalleryImage.id'=>$value)));
						if($gallery_img['GalleryImage']['featured']==1){
							$ans="3";
							}else{
						$gallery['GalleryImage']['id'] = $value;
						$gallery['GalleryImage']['status']=0;
						$this->GalleryImage->create();
						$this->GalleryImage->save($gallery);
						$ans="1";
					}
					}
					
					if($action=='Delete'){
						$gallery_img = $this->GalleryImage->find('first',array('conditions'=>array('GalleryImage.id'=>$value)));
						if($gallery_img['GalleryImage']['featured']==1){
							$ans="3";
							}else{
								$destination = Configure::read('Path.Gallery').$gallery_img['GalleryImage']['image'];
								if(file_exists($destination)) {
									unlink($destination);		
								}
								$this->GalleryImage->deleteAll(array('GalleryImage.id' => $value), false);
								$ans="2";
							}
					}
				}
			}
		if($ans=="1"){
			$this->Session->setFlash(__('Gallery image has been '.strtolower($this->data['action']).'ed successfully', true));
		}
		else if($ans=="2"){
			$this->Session->setFlash(__('Gallery image has been '.strtolower($this->data['action']).'d successfully', true));
		}else if($ans=="3"){
			$this->Session->setFlash(__('Featured image can not '.strtolower($this->data['action']).' Firstly choose a different featured image', true),'default','','error');
			//$this->Session->setFlash(__('').'. Firstly choose a different featured image', true));
		}else{
			$this->Session->setFlash(__('Please Select any Gallery', true),'default','','error');
		}
		$redirect_url=(Controller::referer()=="/")? '/admin/gallery_manager/galleries/':Controller::referer();
		$this->redirect($redirect_url);
	}
	function admin_gallery_delete($id=null){
		$GalleryImage = $this->GalleryImage->read(null,$id);
		
		$destination = WWW_ROOT . "img/gallery/".$GalleryImage['GalleryImage']['image'];
		if(file_exists($destination)) {
			unlink($destination);

		}
		$this->GalleryImage->delete($GalleryImage['GalleryImage']['id']);
		$this->Session->setFlash(__('Gallery image has been deleted successfully'));
		$this->redirect(array('controller'=>'galleries','action'=>'admin_manage_image',$GalleryImage['GalleryImage']['gallery_id']));
	}
	function gallery_banner(){
		App::uses('HtmlHelper', 'View/Helper');
		$Html = new HtmlHelper(new View());
		$data ='<div class="inner-banner">';
		$data .='<div class="inn_img">'.$Html->image('inner-banner-2.jpg').'</div>';
		$data .='<div class="shadows"></div>';
		$data .='<div class="wrapper">';
		$data .='<div class="nav_hd">';
		$data .='<h3>Infrastructure</h3>';
		$data .='</div>';
		$data .='<div class="clear"></div>';
		$data .='</div>';
		$data .='</div>';
		return $data;
	}
	function index($id=null){
		$options = array();
		$options['conditions'] = array('Gallery.id'=>$id,'Gallery.status'=>1);
		$gallery = $this->Gallery->find('first',$options);
		$this->paginate = array();
		if(empty($gallery)){
			throw new NotFoundException('404 Error - Page not found');
		}
		$is_ajax = 0;
		if($this->request->query('type')=='ajax'){
			$this->layout='';
			$is_ajax =1;
		}
		 
		if(!empty($this->request->data)){
			if(!empty($this->request->data['page'])){
				$this->paginate['page'] = $this->request->data['page'];
				//echo 'test';
			}
		}

        $conditions = array();
        $this->paginate['limit']=4;
         //$this->paginate['page']=2;
        $conditions['GalleryImage.status']=1;
        $conditions['GalleryImage.gallery_id']=$id;
        $this->paginate['order']=array('GalleryImage.reorder'=>'ASC','GalleryImage.id'=>'DESC');		        
        $gallery_list=$this->paginate("GalleryImage", $conditions);	
		//$this->System->get_setting('page','banner_image');
		$this->System->set_data('banner_image',$this->System->get_setting('page','banner_image'));
		$this->set('gallery_images',$gallery_list);
		$this->set('gallery',$gallery);
		$this->set('is_ajax',$is_ajax);
		
		$this->current_id = $id;
		$this->System->set_seo('site_title',$gallery['Gallery']['title']);
		$this->System->set_seo('site_metakeyword',$gallery['Gallery']['metakeyword']);
		$this->System->set_seo('site_metadescription',$gallery['Gallery']['metadescription']);
	}
	
}?>