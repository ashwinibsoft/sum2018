<?php
Class QuestionCategoriesController extends QuestionManagerAppController{
	public $uses = array('QuestionManager.QuestionCategorie');
	public $helpers = array('Form','ImageResize');
	public $components=array('Email','RequestHandler','Image');
	public $paginate = array();
	public $id = null;
	
	function admin_index($search=null,$limit=10){
		$this->paginate = array();
		$condition = null;
		if($search=="_blank"){
			$search=null;
		}
		$this->paginate['limit']=$limit;
		if($this->request->is('post')){
			if(!empty($this->request->data['search'])){
				$search = $this->request->data['search'];
			}else{
				$search = '_blank';
			}
			
			if(!empty($this->request->data['limit'])){
				$limit = $this->request->data['limit'];
			}else{
				$limit = '10';
			}
			$this->redirect(array('plugin'=>'question_manager','controller'=>'question_categories','action'=>'index' ,$search,$limit));
		}
		$this->paginate['order']=array('QuestionCategorie.id'=>'DESC');		
		
		if($search!=null){
			$search = urldecode($search);
			$condition['QuestionCategorie.name like'] = '%'.$search.'%';
		}
	//	print_r($condition);die;
		$categories=$this->paginate("QuestionCategorie", $condition);		 
		
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/home'),
			'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/question_manager/questioncategories'),
			'name'=>'Manage Question Groups'
		);
		$this->heading =  array("Manage","Question Groups");
		$this->set('categories', $categories);
		$this->set('search',$search);
		$this->set('url','/'.$this->params->url);
		$this->set('limit',$limit);
	}

	function show(){
		//$slider = Cache::read('slides');
		//if(empty($slider)){
			$slider=$this->Slide->find('all',array('conditions'=>array('Slide.status'=>'1', 'OR'=>array('Slide.theme'=>$this->System->get_theme(),'Slide.theme IS NULL')),'order'=>array('Slide.reorder'=>'ASC')));
			//Cache::write('slides',$slider);
		//}
		$this->set('slider',$slider);
		$this->set('id',1);
	}
	
	function admin_add_category($id=null){
		$cat_list = $this->QuestionCategorie->find('list',array('fields'=>array('id','name'),'order'=>array('QuestionCategorie.id'=>'DESC')));
		$this->breadcrumbs[] = array(
		'url'=>Router::url('/admin/home'),
		'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/question_manager/question_categories'),
				'name'=>'Manage Category'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/question_manager/question_categories/add_category'),
				'name'=>($id==null)?'Add Category':'Update Category'
		);
		if($id==null){
			$this->heading =  array("Add","Category");
		}else{
			$this->heading =  array("Update","Category");
		}
		
		if(!empty($this->request->data) && $this->validation()){
			
			
			if(!$id){
				$this->request->data['QuestionCategorie']['created_at']=date('Y-m-d H:i:s');
				$this->request->data['QuestionCategorie']['status']=1;
			}else{
				
				$this->request->data['QuestionCategorie']['updated_at']=date('Y-m-d H:i:s');
			}
			$this->QuestionCategorie->create();
			//print_r($this->request->data);die;
			$this->QuestionCategorie->save($this->request->data,array('validate'=>false));
			$id = $this->QuestionCategorie->id;	
			Cache::delete('questioncat');
			if ($this->request->data['QuestionCategorie']['id']) {
				$this->Session->setFlash(__('Group has been updated successfully'));
			} 
			else {
				$this->Session->setFlash(__('Group has been added successfully'));
			}
			if(isset($this->request->data['save'])){
				$this->redirect(array('controller' => 'question_categories', 'action' => 'admin_add_category',$id));
			
			}else{
				$this->redirect(array('controller' => 'question_categories','action'=>'admin_index'));
			}
		}
		else{
			if($id!=null){
				$this->request->data = $this->QuestionCategorie->read(null,$id);
			}else{
				$this->request->data = array();
			   
			}
		} 
		$this->set('url',Controller::referer());
		$referer_url = $this->request->query('back');
		
		if(!empty($referer_url)){
			$referer_url= $this->request->query('back');
		}else{
			$referer_url=(Controller::referer()=="/")? Router::url('/admin/question_manager/questioncategories/add_actegory/'.$id,true) :Controller::referer();
			
		}
		$this->set('referer_url',$referer_url);
		$this->set('cat_list',$cat_list);
		
	}
	
	function admin_default_image_crop($id=null){
		$path  = $this->webroot;
		$this->Image = $this->Components->load('Image');
		$this->Image->startup($this);
		$cat_image = $this->EventCategorie->find('first',array('fields'=>array('QuestionCategorie.cat_image'),'conditions'=>array('QuestionCategorie.id'=>$id)));
		if($this->request->is('post')){
			
			$org_image_breaks = explode('.',$cat_image['QuestionCategorie']['cat_image']);
			$ext = array_pop($org_image_breaks);
			$origFile = $cat_image['QuestionCategorie']['cat_image'];

			$src = Configure::read('Path.Cat').$cat_image['QuestionCategorie']['cat_image'];
			$old_slide = Configure::read('Path.cat').$cat_image['QuestionCategorie']['cat_image'];
			$org_image_breaks = implode('.',$org_image_breaks);
			$org_image_breaks = explode('_',$org_image_breaks);
			array_pop($org_image_breaks);
			$org_image_breaks = implode('_',$org_image_breaks);
			$new_name =$org_image_breaks.'_'.time().'.'.$ext;
			$dst =  Configure::read('Path.Cat').$new_name;
			
			$start_width = $this->data['x'];
			$start_height = $this->data['y'];
			$width = $this->data['width'];
			$height = $this->data['height'];
			$key = 'cat_image';
			$thumb = $this->Image->crop($src,$dst,$width,$height,$start_width,$start_height,$this->data['scale']);
			$cat_data = array();
			$cat_data['QuestionCategorie']['id'] = $id;
			$cat_data['QuestionCategorie']['cat_image'] = $new_name;
			
			$_options = array(
						'destination'=>Configure::read('Path.Cat'),
						);
			if($this->QuestionCategorie->save($cat_data,array('validate'=>false))){
				if($cat_image['QuestionCategorie']['cat_image']!='' && file_exists($old_slide)){
					unlink($old_slide);
				}
				$this->Session->setFlash('Image cropped and saved.');
				$this->redirect(array('controller' => 'question_categories', 'action' => 'admin_add_category',$id));
			}
			Cache::delete('site');
			$this->redirect(array('action'=>'admin_add_category',$id));
		}
		$this->set('cat_image',$cat_image);
	}
	
	function admin_delete($id=null){
		$this->autoRender = false;
		$destination = Configure::read('Path.Cat');
	  
		$data=$this->request->data['QuestionCategorie']['id'];
		$action = $this->request->data['QuestionCategorie']['action'];
		$ans="0";
		if(!empty($data)){
			foreach($data as $value){
				if($value!='0'){
					if($action=='Publish'){
						$cat['QuestionCategorie']['id'] = $value;
						$cat['QuestionCategorie']['status']=1;
						$this->QuestionCategorie->create();
						$this->QuestionCategorie->save($cat);
						$ans="1";
					}
					if($action=='Unpublish'){
						$cat['QuestionCategorie']['id'] = $value;
						$cat['QuestionCategorie']['status']=0;
						$this->QuestionCategorie->create();
						$this->QuestionCategorie->save($cat);
						$ans="1";
					}
					if($action=='Delete'){
						$cat = $this->QuestionCategorie->find('first', array('conditions'=> array('QuestionCategorie.id' => $value),'fields' => array('QuestionCategorie.cat_image')));
						if (!empty($cat['QuestionCategorie']['cat_image'])){
						   @unlink($destination. $cat['QuestionCategorie']['cat_image']);
						}
							
						$this->QuestionCategorie->delete($value);
						$ans="2";
					}
				}
			}
			if($ans=="1"){
				$this->Session->setFlash(__('Group has been '.strtolower($this->data['QuestionCategorie']['action']).'ed successfully', true));
			}
			else if($ans=="2"){
				$this->Session->setFlash(__('Group has been '.strtolower($this->data['QuestionCategorie']['action']).'d successfully', true));
			}else{
				$this->Session->setFlash(__('Please Select any Group', true),'default','','error');
			}
			
			$this->redirect($this->request->data['QuestionCategorie']['redirect']);
		}
		
			 
	}
	function validation(){
		if(!empty($this->request->data['QuestionCategorie']['cat_add'])){
			$this->QuestionCategorie->setValidation($this->request->data['QuestionCategorie']['cat_add']);
		}
		$this->QuestionCategorie->set($this->request->data);
		if($this->QuestionCategorie->validates()){
			return true;
		}else{
			$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
			return false;
		}
	}
	public function ajax_validation($returnType = 'json'){
		
		$this->autoRender = false;
		if(!empty($this->request->data)){
			//print_r($this->request->data);die;
			if(!empty($this->request->data['QuestionCategorie']['cat_add'])){
				$this->QuestionCategorie->setValidation($this->request->data['QuestionCategorie']['cat_add']);
			}
			$this->QuestionCategorie->set($this->request->data);
			$result = array();
			if($this->QuestionCategorie->validates()){
					$result['error'] = 0;
			}else{
				$result['error'] = 1;
				$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
			}
			$errors = array();
			$result['errors'] = $this->QuestionCategorie->validationErrors;
			foreach($result['errors'] as $field => $data){
			  $errors['QuestionCategorie'.Inflector::camelize($field)] = array_pop($data);
			}
			$result['errors'] = $errors;
			$view = new View();
			
			$result['error_message'] = $view->element('admin/message');
			echo json_encode($result);
			return;
		}
		echo json_encode(array());
	}

	

	
}
?>