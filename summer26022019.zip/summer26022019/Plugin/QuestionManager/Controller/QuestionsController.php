<?php Class QuestionsController extends QuestionManagerAppController{
	public $uses = array('QuestionManager.Question','QuestionManager.QuestionCategorie');
	public $components=array('Email','RequestHandler','Image','ExportXls');
	var $helpers = array('Captcha','Csv','Xls');
	public $paginate = array();
	public $id = null;
	public $template=null;
	
	
	public function admin_index($group_id=null,$search=null,$limit=10){
		$this->Question->bindModel(array('belongsTo' => array('QuestionCategorie' => array('foreignKey' => false,'conditions' => array('Question.category_id = QuestionCategorie.id')))));
		$this->paginate = array();
		$condition = null;
		if($search=="_blank"){
			$search=null;
		}
		$this->paginate['limit']=$limit;
		if($this->request->is('post')){
			//print_r($this->request->data); die;
			if(!empty($this->request->data['search'])){
				$search = $this->request->data['search'];
			}else{
				$search = '_blank';
			}
			/*if(!empty($this->request->data['is_descriptive'])){
				$is_descriptive = $this->request->data['is_descriptive'];
			}else{
				$is_descriptive = '_blank';
			}*/
			if(!empty($this->request->data['group_id'])){
				$group_id = $this->request->data['group_id'];
			}else{
				$group_id = 0;
			}
			if(!empty($this->request->data['limit'])){
				$limit = $this->request->data['limit'];
			}else{
				$limit = '10';
			}
			$this->redirect(array('plugin'=>'question_manager','controller'=>'questions','action'=>'index',$group_id,$search,$limit));
			
		}
	//	echo 11;die;
		if($search!=null){
			$search = urldecode($search);
			$condition['Question.question like'] = '%'.$search.'%';
		}
		
		if($group_id!=null && $group_id!=0){
			$group_id = urldecode($group_id);
			$condition['Question.category_id'] = $group_id;
		}
		
		/*if($is_descriptive!=null){
			$is_descriptive = urldecode($is_descriptive);
			$condition['Question.is_descriptive'] = $is_descriptive;
		}*/
		
		//print_r($condition);die;
		$pages = array();
		
		$this->paginate['order']=array('Question.id'=>'DESC');
		$results=$this->paginate("Question", $condition);
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/home'),
			'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/question_manager/events'),
			'name'=>'Manage Question'
		);		
		$this->heading =  array("Manage","Question");	
		
		$groups = $this->QuestionCategorie->find('list',array('fields'=>array('QuestionCategorie.name'),'conditions'=>array('QuestionCategorie.status'=>1)));
			
		//echo '<pre>';print_r($groups);die;
		$this->set('questions',$results);
		$this->set('limit',$limit);		
		$this->set('groups',$groups);
		//$this->set('is_descriptive',$is_descriptive);
		$this->set('group_id',$group_id);
		$this->set('search',$search);
		$this->set('url','/'.$this->params->url);
	}
	
	
 	function admin_export(){
		//var $helpers = array('xls');
		$this->layout = null;
		$this->autoLayout = false;
		Configure::write('debug','2');		
		$this->Question->bindModel(array('belongsTo' => array('QuestionCategorie' => array('foreignKey' => false,'conditions' => array('Question.category_id = QuestionCategorie.id')))));
		$condition = array();			
												
		//$options['fields']    = array('Client.*','ClientPlan.*','Plan.*','Payment.*');
		//$options['group']=array('Question.id');
		$options['order']= array('Question.category_id'=>'DESC');
		$questionInfos = $this->Question->find('all',$options);
		if(empty($questionInfos)){
			$this->Session->setFlash(__('No data found to export!', true),'default','','error');
			$this->redirect(array('plugin'=>'question_manager','controller'=>'questions','action'=>'index'));
		}
		
		//$this->set('questionInfos', $questionInfos);
		
		 $currntdate=date('d/m/Y-H:i:s'); 
		$fileName='question_list-'.$currntdate.'.xls';
		//$fileName = "bookreport_".date("d-m-y:h:s").".xls";
		$headerRow = array("S.No.","Group Name","Question","Is Descriptive?","Options","Status");
		//$data = array();
		$data='';
		$i = 0;
		foreach($questionInfos as $questionInfo){
			$i++;
			$newd=array();
			$status = ($questionInfo['Question']['status']==1) ? 'Active' : 'Inactive';
			$action = ($questionInfo['Question']['is_descriptive']==1) ? 'Yes' : 'No';
			$name=$questionInfo['QuestionCategorie']['name'];
			$question=$questionInfo['Question']['question'];
			//$options=json_encode($questionInfo['Question']['options']);
			$options=json_decode($questionInfo['Question']['options']);
			$k=1;
			$st='';
			foreach($options as $option){
				$st.=$k.'-'.$option.' ';
				$k++;
			}
			$newd=array($i,$name,$question,$action,$st,$status);
			$data[]=$newd;
			
		}
		//echo '<pre>';print_r($data);die;
	/*	$data = array(
				   array('Book Title1', '1111111111', 'Rohit Kumar-1'),
				   array('Book Title2', '2222222222', 'Rohit Kumar-2'),
				   array('Book Title3', '3333333333', 'Rohit Kumar-3'),
				   array('Book Title4', '4444444444', 'Rohit Kumar-4') 
				  );*/
		  $this->ExportXls->export($fileName, $headerRow, $data);
		
	}
	
	public function admin_create_pdf(){
        //$cat_list = $this->QuestionCategorie->find('all',array('order'=>array('QuestionCategorie.id'=>'DESC')));
        $this->Question->bindModel(array('belongsTo' => array('QuestionCategorie' => array('foreignKey' => false,'conditions' => array('Question.category_id = QuestionCategorie.id')))));
		$condition = array();			
		$options['group']=array('Question.id');
		$options['order']= array('Question.category_id'=>'ASC');
		$questionInfos = $this->Question->find('all',$options);
		
		if(empty($questionInfos)){
			$this->Session->setFlash(__('No data found to export!', true),'default','','error');
			$this->redirect(array('plugin'=>'question_manager','controller'=>'questions','action'=>'index'));
		}
		$cat_list = array();
		foreach($questionInfos as $ques){
			if(!in_array($ques['Question']['category_id'],$cat_list)){
				$cat_list[] = $ques['Question']['category_id'];
			}
		}						
		
		$cat = $this->QuestionCategorie->find('all',array('conditions'=>array('QuestionCategorie.id'=>$cat_list),'order'=>array('QuestionCategorie.name'=>'ASC')));
		$this->set('questionInfos', $questionInfos);
		$this->set('cat_list', $cat);
		$this->layout = null;
		$this->autoLayout = false;
		Configure::write('debug','2');
		
		$currntdate=date('d-m-Y'); 
		$this->set('currntdate',$currntdate);
		$this->layout = '/pdf/default';
	
	}
	
	function admin_add_question($id=null){
		$path  = $this->webroot;
		$galleries = array();
		$this->loadModel('QuestionManager.QuestionCategorie');
		$cat_list = $this->QuestionCategorie->find('list',array('fields'=>array('id','name'),'order'=>array('QuestionCategorie.id'=>'DESC')));
		
		$this->breadcrumbs[] = array(
		'url'=>Router::url('/admin/home'),
		'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/question_manager/questions'),
				'name'=>'Manage Question'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/question_manager/questions/add_question/'.$id),
				'name'=>($id==null)?'Add Question':'Update Question'
		);
		if($id==null){
			$this->heading =  array("Add","Question");
		}else{
			$this->heading =  array("Update","Question");
		}
		
		if(!empty($this->request->data) && $this->validation()){
			//print_r($this->request->data);die;
			if(!$id){
				$this->request->data['Question']['created']=date('Y-m-d H:i:s');
				}else{
				$this->request->data['Question']['updated']=date('Y-m-d H:i:s');
				}
			if(empty($this->request->data['Question']['id'])){
				if(isset($this->request->data['save']) && $this->request->data['save']=='Save'){
					$this->request->data['Question']['status'] = 2;
				}else{
					$this->request->data['Question']['status'] = 1;
				}
				//print_r($this->request->data['Question']['options']); die;
			}
			$options = array(
				'1' => $this->request->data['Question']['scale_text1'],
				'2' => $this->request->data['Question']['scale_text2'],
				'3' => $this->request->data['Question']['scale_text3'],
				'4' => $this->request->data['Question']['scale_text4'],
				'5' => $this->request->data['Question']['scale_text5'],
				'6' => $this->request->data['Question']['scale_text6']
			);
			$this->request->data['Question']['options'] = json_encode($options);
			$this->Question->create();
			$this->Question->save($this->request->data,array('validate'=>false));
		/*
				if($id){
						$max=$id;
				}else{
						$max=$this->Question->find('all',array('fields'=>array('MAX(Question.id) AS maxid')));
						$max=$max[0][0]['maxid'];
						$max=$max;
				}	
			
			$id = $this->Question->id;		
			//Slug URL Logic Start
			$slug_url = '';
			if(empty($this->request->data['Question']['id'])){
				if($this->request->data['Question']['slug_url']==''){
					$string = strtolower($this->request->data['Question']['question']);
					$slug_url = Inflector::slug($string, '-');
				}else{
					$slug_url = $this->request->data['Question']['slug_url'];
				}
			}else{
				$slug_url = $this->request->data['Question']['slug_url'];
			}
			//Slug URL Logic END
			
			$route = array();
			$route['request_uri'] = trim($slug_url);
			$route['object'] = 'Question';
			$route['object_id'] = $this->Question->id;
			$route['object_name'] = $this->request->data['Question']['question_name'];
			$route['values'] = json_encode(array('plugin'=>'question_manager','controller'=>'questions','action'=>'view','id'=>$this->Question->id));
			
			$this->Question->save_routes($route);
			*/
			if ($this->request->data['Question']['id']) {
				$this->Session->setFlash(__('Record has been updated successfully'));
			} 
			else{
				$this->Session->setFlash(__('Record has been added successfully'));
			}
			$this->redirect(array('action'=>'add_question',$id,'?'=>array('back'=>$this->request->data['Question']['url_back_redirect'])));
		}
		else{
			if(!empty($this->request->data)){
				$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
			}
			
			if($id!=null){
				$this->request->data = $this->Question->read(null,$id);	
				$this->request->data['Question']['category_id']=	json_decode($this->request->data['Question']['category_id'], true);	
				$options = json_decode($this->request->data['Question']['options'],true);
				$this->request->data['Question']['scale_text1'] = $options['1'];
				$this->request->data['Question']['scale_text2'] = $options['2'];
				$this->request->data['Question']['scale_text3'] = $options['3'];
				$this->request->data['Question']['scale_text4'] = $options['4'];
				$this->request->data['Question']['scale_text5'] = $options['5'];
				if(isset($options['6'])){$this->request->data['Question']['scale_text6'] = $options['6'];}
				
				//print_r($this->request->data);die;
				//print_r($options);die;
			}else{
				$this->request->data = array();
			}
		}
		
		$referer_url = $this->request->query('back');
		if(!empty($referer_url)){
			$referer_url= $this->request->query('back');
		}else{
			$referer_url=(Controller::referer()=="/")? Router::url('/admin/question_manager/questions',true) :Controller::referer();		
		}
		
		$this->set('referer_url',$referer_url);
		$this->set('cat_list',$cat_list);
		$this->set('question_id',$id);
	}
	
	
	public function admin_one_delete($question_id = null){
		$this->autoRender = false;
		if($question_id==null){
			$this->redirect(Controller::referer());
		}
		$question = $this->Question->find('first', array('conditions'=> array('Question.id' => $question_id)));
		if (!empty($question['Question']['feature_image'])) {
			   @unlink(WWW_ROOT."img/questionimage/". $question['Question']['feature_image']);
		}
		$this->Question->delete($question_id);
		//$this->QuestionLocation->deleteAll(array('QuestionLocation.question_id' => $question_id));
		$this->Session->setFlash(__('Question has been deleted successfully'));
		$redirect_url = $this->request->query('back');
		if(!empty($redirect_url)){
			$this->redirect($redirect_url);
		}else{
			$this->redirect(array('action'=>'admin_index'));
		}
		
		
		
	}
	
	function admin_delete($id=null){
		$this->autoRender = false;
		$data=$this->request->data['Question']['id'];
		$action = $this->request->data['Question']['action'];
		$ans="0";
	
		foreach($data as $value){
			
			if($value!='0'){
				$question = $this->Question->find('first', array('conditions'=> array('Question.id' => $value)));
				if((int)$question['Question']['status']==2){
					continue;
				}
				
				if($action=='Publish'){
					//print_r($question);die;
					$question['Question']['id'] = $value;
					$question['Question']['status']=1;
					//print_r($question);die;
					$this->Question->create();
					$this->Question->save($question);
					$ans="1";
				}
				if($action=='Unpublish'){
					$question['Question']['id'] = $value;
					$question['Question']['status']=0;
					$this->Question->create();
					$this->Question->save($question);
					$ans="1";
				}
				if($action=='Delete'){
					if (!empty($question['Question']['question_image'])) {
						   @unlink(WWW_ROOT."img/questionimage/". $question['Question']['feature_image']);
					}
					$this->Question->delete($value);
					//$this->EventLocation->deleteAll(array('EventLocation.event_id' => $value));
					$ans="2";
				}
			}
		}
		if($ans=="1"){
			$this->Session->setFlash(__('Question has been '.strtolower($this->data['Question']['action']).'ed successfully', true));
		}
		else if($ans=="2"){
			$this->Session->setFlash(__('Question has been '.strtolower($this->data['Question']['action']).'d successfully', true));
		}else{
			$this->Session->setFlash(__('Please select questions', true),'default','','error');
		}
		$this->redirect($this->request->data['Question']['redirect']);
                 
	}

	
		function validation(){
		if(!empty($this->request->data['Question']['add_question'])){
			$this->Question->setValidation($this->request->data['Question']['add_question']);
		}
		$this->Question->set($this->request->data);
		if($this->Question->validates()){
			return true;
		}else{
			$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
			return false;
		}
	}
	
	public function ajax_validation($returnType = 'json'){
		
		$this->autoRender = false;
		if(!empty($this->request->data)){
			//print_r($this->request->data);die;
			
			if(!empty($this->request->data['Question']['add_question'])){
				$this->Question->setValidation($this->request->data['Question']['add_question']);
			}
			$this->Question->set($this->request->data);
			$result = array();
			if($this->Question->validates()){
					$result['error'] = 0;
			}else{
				$result['error'] = 1;
				$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
			}
			$errors = array();
			$result['errors'] = $this->Question->validationErrors;
			foreach($result['errors'] as $field => $data){
			  $errors['Question'.Inflector::camelize($field)] = array_pop($data);
			}
			$result['errors'] = $errors;
			$view = new View();
			
			$result['error_message'] = $view->element('admin/message');
			echo json_encode($result);
			return;
		}
		echo json_encode(array());
	}
	
	
	private function __load_page($id=null){
		
		$this->loadModel('ContentManager.Page');
		$page = $this->Page->find('first',array('conditions'=>array('Page.id'=>$id,'Page.status'=>1)));
		if (empty($page)) {
		throw new NotFoundException('404 Error - Page not found');
		}
		$this->System->set_seo('site_title',$page['Page']['page_title']);
		$this->System->set_seo('site_metakeyword',$page['Page']['page_metakeyword']);
		$this->System->set_seo('site_metadescription',$page['Page']['page_metadescription']);
		if((int)Configure::read('Section.default_banner_image') && ($page['Page']['use_default_image'] || $this->System->get_setting('page','override_banner_image'))){
			$page['Page']['banner_image'] = $this->System->get_setting('page','banner_image');
		}
		$this->System->set_data('banner_image',$page['Page']['banner_image']);
		
		return $page;
	}
	
	/*public function index(){
		
		$page = $this->__load_page(57);
		$this->set('page', $page);
		$ud = $this->Session->read('Auth');
		$cat_list = $this->QuestionCategorie->find('all',array('fields'=>array('id','name'),'order'=>array('QuestionCategorie.id'=>'DESC'),'conditions'=>array('QuestionCategorie.status' =>1)));
		
		$questions = $this->Question->find('all',array('conditions'=>array('Question.status'=>1)));
		//$profile_questions = $this->NewBuyerQuestion->find('list',array('fields'=>array('id','question_id'),'conditions'=>array('NewBuyerQuestion.new_buyer_id'=>)));
		$this->set('cat_list',$cat_list);
		$this->set('questions',$questions);
		//print_r($questions); die;
		
	}*/
	
}
?>