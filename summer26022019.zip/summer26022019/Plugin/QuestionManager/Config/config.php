<?php
$config = array();
$config['Name']['Plugin'] = "Question Manager";
$config['Menu']['Left'] = array(
					array(
					'position'=>2,
					'icon'=>'fa fa-calendar',
					'title'=>'Questions Manager',
					'url'=>array('plugin'=>'question_manager','controller'=>'questions','action'=>'admin_index','admin'=>true),
					'sub_menus'=> array(
						array(
							'title'=>'Manage Questions',
							'url'=>array('plugin'=>'question_manager','controller'=>'questions','action'=>'admin_index','admin'=>true),
							),
						array(
							'title'=>'Question Categories/Groups',
							'url'=>array('plugin'=>'question_manager','controller'=>'question_categories','action'=>'admin_index','admin'=>true)
							),
						/*array(
							'title'=>'Manage Event Gallery',
							'url'=>array('plugin'=>'gallery_manager','controller'=>'galleries','action'=>'admin_index','admin'=>true)
							),	
						array(
							'title'=>'Event Settings',
							'url'=>array('plugin'=>'event_manager','controller'=>'events','action'=>'admin_settings','admin'=>true)
							)*/
						)
					)
				);
//$config['Settings']['event_location']=true;
//$config['Settings']['event_gallery']=true;
$config['Settings']['question_repeat']=true;
$config['Settings']['question_category']=true;
$config['Settings']['question_image']=true;

$config['Folder']['Question'] = "question";
$config['Path']['Question'] =  WWW_ROOT.'img'.DS.$config['Folder']['Question'].DS;

$config['Folder']['question_image'] = "questionimage";
$config['Path']['question_image'] =  WWW_ROOT.'img'.DS.$config['Folder']['question_image'].DS;
$config['Path']['NoImage'] =  WWW_ROOT.'img'.DS.'site'.DS.'noimage.jpg';
$config['Path']['CatFolder'] =  'questioncat';
$config['Path']['Cat'] =  WWW_ROOT.'img'.DS.$config['Path']['CatFolder'].DS;
$config['Admin']['Limit'] = 20;

$config['Path']['FolderName'] =  'files';
$config['Path']['Assisted'] =  WWW_ROOT.'img'.DS.$config['Path']['FolderName'].DS;
/***These below code is used  for admin purpose*/
$config['image_list_width'] = "80";
$config['image_list_height'] = "80";
$config['image_edit_width'] = "290";
$config['image_edit_height'] = "240";
$config['image_front_width'] = "220";
$config['image_front_height'] = "200";

$config['image_front_list_width'] = "211";
$config['image_front_list_height'] = "156";

$config['image_admin_edit_width'] = "80";
$config['image_admin_edit_height'] = "80";


$config['default_feature_thumb_width'] = "625";
$config['default_feature_thumb_height'] = "350";
$config['image_front_gallery_slideshow_width'] = "310";
$config['image_front_gallery_slideshow_height'] = "190";
/**Belowe code is used for front banner image on front**/
$config['feature_image_width']="1400";
$config['feature_image_height']="350";
$config['feature_image_height']="550";
$config['image_crop_ratio']='4:3';
$config['cat_image_width']="1400"; //Use to set category image width that shows on front side

$config['cat_image_height']="470"; //Use to set category image height that shows on front side

$config['Question']['templates'] = array(
'two_page_template' =>'Two Page Template',
'template2' =>'Template2',
'template3' => 'Template3'
);






?>
