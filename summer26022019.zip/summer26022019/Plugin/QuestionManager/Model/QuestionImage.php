<?php App::uses('CakeTime', 'Utility');
Class ProjectImage extends ProjectManagerAppModel {
	public $name = "ProjectImage";
	public $actsAs = array('Multivalidatable');
	public $validation = array(
	
	'title'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Plaese enter Location name.'),
				array('rule' => array('maxLength', 255),'message' => 'Location Name should be less than 255 charcter(s).')
			),
	
	);
	public $validationSets = array(
	
	'title'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Plaese enter Location name.'),
				array('rule' => array('maxLength', 255),'message' => 'Location Name should be less than 255 charcter(s).')
			),
	
	);
	
	
	
	

}
?>
