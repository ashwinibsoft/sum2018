<?php
Class QuestionManagerAppModel extends AppModel {
}
?>
