<?php
Class Question extends QuestionManagerAppModel {
	public $name = "Question";
	public $belongsTo = array(
		'QuestionCategorie' => array(				
			 'foreignKey' => false,
			 'conditions' => array('Question.category_id=QuestionCategorie.id'),
		)
	);
	public $validate = array(
	
	'question' => array(
            'rule1' =>
            array(
                'rule' => array('maxLength', 500),
                'message' => 'Question Name should be less than 500 character(s).'
            ),
            array(
                'rule' => 'notEmpty',
                'message' => 'Please enter Question.'
            ) 
        ),
		'category_id' =>array(
				'rule' => 'multiple',
				'message' => 'Please Select Question Group.'
			),
		
	    
    );
	
}
?>
