<?php
Class QuestionCategorie extends QuestionManagerAppModel {
	public $name = "QuestionCategorie";
	public $validate = array(
	'name'=>array(
				'rule1' => 
				array('rule' => 'notEmpty','message' => 'Plaese enter Group name.'),
				array('rule' => array('maxLength', 255),'message' => 'Group Name should be less than 255 charcter(s).')
			),
		
	);
	
	

}
?>
