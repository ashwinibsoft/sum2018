<?php
Class Cookie extends SupplierManagerAppModel {
	public $name = "Cookie";
	public $actsAs = array('Multivalidatable');
	public $belongsTo = array('Supplier' => array('foreignKey' => false,'conditions' => array('Cookie.user_id=Supplier.id')));
}
?>