<?php
Class SupplierManagerAppModel extends AppModel {
}
?>