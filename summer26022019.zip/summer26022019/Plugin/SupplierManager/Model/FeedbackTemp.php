<?php Class FeedbackTemp extends SupplierManagerAppModel {
	public $name = "FeedbackTemp";
	//public $actsAs = array('Multivalidatable');
	
/*	public $belongsTo = array(
		'Supplier' => array(
			'className' => 'Supplier',
			'foreignKey' =>'supplier_id',
		)
	);
	*/
}
?>