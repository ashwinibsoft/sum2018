<?php

Class FacebookApiAppController extends AppController{
		
		function beforeFilter() {
			parent::beforeFilter();	
		Configure::load('FacebookApi.config');
		 
		}
	
	}

?>