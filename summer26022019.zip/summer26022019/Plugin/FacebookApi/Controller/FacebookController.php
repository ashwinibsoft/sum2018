<?php
Class FacebookController extends FacebookApiAppController{
	//public $uses = array('Facebook');
	public $components=array('Email');
	public $paginate = array();
	public $id = null;
	
	function admin_index(){
		$this->loadModel('Setting');
		if(!empty($this->request->data) && !$this->admin_validation()){
			//echo "<pre>";print_r($this->request->data);die;
			foreach($this->request->data['Facebook'] as $key => $value){
				
				if(is_array($value)){
					if($value['error']==0){
						$ext = explode(".",$value['name']);
						$name = explode("_",$key);
						
					}else{
						continue;
						////	$value;
					}
				}
				if($this->Setting->find('count',array('conditions'=>array('Setting.key'=>$key,'Setting.module'=>Configure::read('Module.name'))))){
					$module = Configure::read('Module.name');

					$this->Setting->query("UPDATE `settings` SET `values`=\"$value\" , `module`=\"$module\" WHERE `key`=\"$key\"");
				
				} else{
					$this->Setting->query("INSERT `settings` SET `values`=\"$value\"  , `key`=\"$key\" , module=\"$module\"");
				}
				
				$this->Session->setFlash(__('Data has been Saved Successfully'));
			}
			Cache::delete('facebookapi');
			$this->redirect(array('action'=>'admin_index'));
		}
		if(empty($this->request->data)){
			$this->request->data['Facebook'] = $this->Setting->find('list',array('fields'=>array('Setting.key','Setting.values')));
			
		}else{
			$data = $this->Setting->find('list',array('fields'=>array('Setting.key','Setting.values')));
			
			$this->request->data['Facebook']['app_id'] = $data['app_id'];
			$this->request->data['Facebook']['app_secret'] = $data['app_secret'];
		}

		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/home'),
			'name'=>'Home'
		);
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/facebook_api/facebook/admin_index'),
			'name'=>'Facebook Api Setting'
		);
	}
	function admin_validation(){
		$this->autoRender = false;
		
		$this->Facebook->set($this->request->data);
		
		$result = array();
		if ($this->Facebook->validates()) {
			$result['error'] = 0;
		}else{
			$result['error'] = 1;
		}
			$result['errors'] = $this->Facebook->validationErrors;
			$errors = array();
		 
		foreach($result['errors'] as $field => $data){
			$errors['Facebook'.Inflector::camelize($field)] = array_pop($data);
		}
		 
		$result['errors'] = $errors;
		if($this->request->is('ajax')){
			echo json_encode($result);
			return;
		} 
	}
	
	
}

?>