<?php

$config['Module']['name'] =  'facebookapi';

?>
