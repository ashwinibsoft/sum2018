<?php
Class FacebookApiAppModel extends AppModel {
}
?>