<?php
class Facebook extends FacebookApiAppModel {
   var $useTable = false;
    public $validate = 
    array(
		'app_id' =>
			array(
				'rule1' =>
				array(
					'rule' => 'notEmpty',
					'message' => 'Please enter facebook app id.'
				), 
			),
			
		'app_secret' =>
			array(
				'rule1' =>
				array(
					'rule' => 'notEmpty',
					'message' => 'Please enter facebook app secret.'
				), 
	),	
									
    
          
    );
 }?>