<?php
$config = array();
$config['Name']['Plugin'] = "Faq Manager";

$config['Menu']['Left'] = array(
					array(
					'position'=>6,
					'icon'=>'fa-chain',
					'title'=>'FAQ Manager',
					'url'=>array('plugin'=>'faq_manager','controller'=>'faqs','action'=>'admin_index','admin'=>true),
					'sub_menus'=> array(
						array(
							'title'=>'Manage FAQ',
							'url'=>array('plugin'=>'faq_manager','controller'=>'faqs','action'=>'admin_index','admin'=>true)
							),
						array(
							'title'=>'Manage Category',
							'url'=>array('plugin'=>'faq_manager','controller'=>'faqs','action'=>'admin_faqcategory','admin'=>true)
							)
						)
				
					)
				);

$config['Folder']['TeamImage'] = "teamimage";
$config['Path']['TeamImage'] =  WWW_ROOT.'img'.DS.$config['Folder']['TeamImage'].DS;
$config['Path']['Gallery'] =  WWW_ROOT.'img'.DS.'gallery'.DS;
$config['Path']['NoImage'] =  WWW_ROOT.'img'.DS.'site'.DS.'noimage.jpg';
$config['Admin']['Limit'] = 20;

$config['Path']['FolderName'] =  'files';
$config['Path']['Assisted'] =  WWW_ROOT.'img'.DS.$config['Path']['FolderName'].DS;
/***These below code is used  for admin purpose*/
$config['image_edit_width'] = "100";
$config['image_edit_height'] = "100";

/*Front side Team image dimension*/
$config['front_list_width'] = "500";
$config['front_list_height'] = "500";

$config['Team']['templates'] = array(
'2_page_template' =>'2 Page Template',
'template2' =>'Template2',
'template3' => 'Template3'
);






?>
