<?php
Class Faqcategory extends FaqManagerAppModel {
	public $name = "Faqcategory";
	public $actsAs = array('Multivalidatable');
	//public $useTable = 'faqcategories';
	public $team_action = "";
	public $validationSets = array(
	'faqcategory_add'=>array(
				'category'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Plaese enter question.'),
				),
			),

	);
}
?>