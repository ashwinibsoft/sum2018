<?php
Class Faq extends FaqManagerAppModel {
	public $name = "Faq";
	public $actsAs = array('Multivalidatable');
	//public $useTable = 'categories';
	public $team_action = "";
    public $belongsTo = array(
		'Faqcategory' => array(				
			 'foreignKey' => false,
			 'conditions' => array('Faqcategory.id=Faq.cat_id'),
		)
	);
	public $validationSets = array(
	'faq_add'=>array(
				'question'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Plaese enter question.'),
				),
				'answer'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Plaese enter answer.'),
				),
				'cat_id'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Plaese enter category.'),
		        ),
			),

	);
	
	public function afterSavee($created , $options = array()) {
		App::import('model','ShortLink');
		$ShortLink = new ShortLink();
		if(!$ShortLink->find('count',array('conditions'=>array('ShortLink.object_id'=>$this->id,'ShortLink.module'=>'Faq')))){
			$shortlink['ShortLink']['short_code'] = "{".$this->data['Faq']['url_key']."}";
			$shortlink['ShortLink']['object_id'] = $this->id;
			$shortlink['ShortLink']['module'] = "Faq";
			$ShortLink->save($shortlink);
		}
		Cache::delete('cake_faq_routing');
	}
	
	public function afterDelete(){
		App::import('model','ShortLink');
		$ShortLink = new ShortLink();
		$ShortLink->deleteAll(array('ShortLink.object_id'=>$this->id,'ShortLink.module'=>'Faq'),false);
		Cache::delete('cake_faq_routing');
	}
	 
 
	public function chkImageExtension($data) {
		if($data['image']['name'] != ''){
				$fileData= pathinfo($data['image']['name']);
				$ext=$fileData['extension'];
				$allowExtension=array('gif', 'jpeg', 'png', 'jpg','JPG');
				if(in_array($ext, $allowExtension)) {
					$return = true; 
				} else {
					$return = false;
				}
			} else{
			
				$return = true; 
			}
			return $return;
		}



	public function uploadFile( $check ) {
		$uploadData = array_shift($check);
		if ( $uploadData['size'] == 0 || $uploadData['error'] !== 0) {
			return false;
		}
		return true;
	}
}
?>