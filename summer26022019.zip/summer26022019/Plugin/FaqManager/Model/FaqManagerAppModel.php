<?php
Class FaqManagerAppModel extends AppModel {
}
?>