<?php
Class FaqsController extends FaqManagerAppController{
	public $uses = array('FaqManager.Faq','ContentManager.Page','FaqManager.Faqcategory');
	public $components=array('Email','RequestHandler','Image');
	public $paginate = array();
	public $id = null;
	public $template=null;
	function admin_index($search=null,$limit=10){
		$this->paginate = array();
		$condition = null;
		if($search=="_blank"){
			$search=null;
		}
		$this->paginate['limit']=$limit;
		if($this->request->is('post')){
			if(!empty($this->request->data['search'])){
				$search = $this->request->data['search'];
			}else{
				$search = '_blank';
			}
			if(!empty($this->request->data['limit'])){
				$limit = $this->request->data['limit'];
			}else{
				$limit = '10';
			}
			$this->redirect(array('plugin'=>'faq_manager','controller'=>'faqs','action'=>'index',$search,$limit));
		}
		if($search!=null){
			$search = urldecode($search);	
			$condition['OR'][]=array('Faq.question like'=>'%'.$search.'%');
			$condition['OR'][]=array('Faq.answer like'=>'%'.$search.'%');
		}
		
		
		$faqs = array();
		$this->paginate['fields'] = array('Faq.id','Faq.question','Faq.answer','Faq.status','Faq.created_at');
		
		$this->paginate['order']=array('Faq.faq_order'=>'ASC','Faq.id'=>'DESC');
		$faqs= $results=$this->paginate("Faq", $condition);
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/home'),
			'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/faq_manager/faqs'),
			'name'=>'Manage FAQ'
		);
		
		$this->heading =  array("Manage","FAQ");

		//$this->set('parent_id',$parent_id);
		$this->set('faqs',$faqs);
		$this->set('limit',$limit);
		$this->set('search',$search);
		$this->set('url','/'.$this->params->url);
		
	}
	function admin_faqcategory($search=null,$limit=10){
		//print_r($this->request->data);exit;
		$this->paginate = array();
		$condition = null;
		if($search=="_blank"){
			$search=null;
		}
		$this->paginate['limit']=$limit;
		if($this->request->is('post')){
			if(!empty($this->request->data['search'])){
				$search = $this->request->data['search'];
			}else{
				$search = '_blank';
			}
			if(!empty($this->request->data['limit'])){
				$limit = $this->request->data['limit'];
			}else{
				$limit = '10';
			}
			$this->redirect(array('plugin'=>'faq_manager','controller'=>'faqs','action'=>'admin_faqcategory',$search,$limit));
		}
		if($search!=null){
			//$search = urldecode($search);	
			$condition=array('Faqcategory.category like'=>'%'.$search.'%');
			//$condition['OR'][]=array('Faqcategory.answer like'=>'%'.$search.'%');
		}
		
		
		$faqscat = array();
		$this->paginate['fields'] = array('Faqcategory.id','Faqcategory.category');
		
		$this->paginate['order']=array('Faqcategory.faq_order'=>'ASC','Faqcategory.id'=>'DESC');
		$faqscat= $results=$this->paginate("Faqcategory", $condition);
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/home'),
			'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/faq_manager/faqcategory'),
			'name'=>'Manage FAQ Category'
		);
		
		$this->heading =  array("Manage","FAQ Category");

		//$this->set('parent_id',$parent_id);
		$this->set('faqscat',$faqscat);
		$this->set('limit',$limit);
		$this->set('search',$search);
		$this->set('url','/'.$this->params->url);
		
		}
	
	function admin_add($id=null){
		$this->breadcrumbs[] = array(
		'url'=>Router::url('/admin/home'),
		'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/faq_manager/faqs'),
				'name'=>'Manage FAQ'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/faq_manager/faqs/add/'.$id),
				'name'=>($id==null)?'Add FAQ':'Update FAQ'
		);
		if($id==null){
			$this->heading =  array("Add","FAQ");
		}else{
			$this->heading =  array("Update","FAQ");
		}
	
		if(!empty($this->request->data) && $this->validation()){
			
			if(!$id){
				$this->request->data['Faq']['created_at']=date('Y-m-d H:i:s');
				
			}else{
				$this->request->data['Faq']['updated_at']=date('Y-m-d H:i:s');
			}
			$this->Faq->create();
			$this->Faq->save($this->request->data,array('validate'=>false));
			Cache::delete('faqs');
			$id = $this->Faq->id;
			
			if ($this->request->data['Faq']['id']) {
				$this->Session->setFlash(__('Record has been updated successfully'));
			} 
			else{
				$this->Session->setFlash(__('Record has been added successfully'));
			}
			$this->redirect(array('action'=>'add',$id,'?'=>array('back'=>$this->request->data['Faq']['url_back_redirect'])));
		}
		else{
			if(!empty($this->request->data)){
				$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
			}
			
			if($id!=null){
				$this->request->data = $this->Faq->read(null,$id);
			}else{
				$this->request->data = array();
			}
		}
		$faqcat = $this->Faqcategory->find('all');
        //print_r($faqcat);exit;
		//$options = array('conditions' => array('User.id' => 1), 'fields' => array('User.mobile'));
        
        //$number = $data['User']['mobile'];
		$referer_url = $this->request->query('back');
		if(!empty($referer_url)){
			$referer_url= $this->request->query('back');
		}else{
			$referer_url=(Controller::referer()=="/")? Router::url('/admin/faq_manager/faqs',true) :Controller::referer();
		
		}
		$this->set('referer_url',$referer_url);
		$this->set('faq_id',$id);
		$this->set('faqcat',$faqcat);
		
	}
	function admin_faqcategory_add($id=null){
		//print_r($id);exit;
		$this->breadcrumbs[] = array(
		'url'=>Router::url('/admin/home'),
		'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/faq_manager/faqs/faqcategory'),
				'name'=>'Manage FAQ Category'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/faq_manager/faqs/faqcategory_add/'.$id),
				'name'=>($id==null)?'Add FAQ Category':'Update FAQ Category'
		);
		if($id==null){
			$this->heading =  array("Add","FAQ Category");
		}else{
			$this->heading =  array("Update","FAQ Category");
		}
		if(!empty($this->request->data)){
			
			/*if(!$id){
				$this->request->data['Faqcategory']['created_at']=date('Y-m-d H:i:s');
				
			}else{
				$this->request->data['Faqcategory']['updated_at']=date('Y-m-d H:i:s');
			}*/
			
			$this->Faqcategory->create();
			$this->Faqcategory->save($this->request->data,array('validate'=>false));
			Cache::delete('faqcategories');
			$id = $this->Faqcategory->id;
			
			if ($this->request->data['Faqcategory']['id']) {
				$this->Session->setFlash(__('Record has been updated successfully'));
			} 
			else{
				$this->Session->setFlash(__('Record has been added successfully'));
			}
			$this->redirect(array('action'=>'faqcategory_add',$id,'?'=>array('back'=>$this->request->data['Faqcategory']['url_back_redirect'])));
		}
		else{
			if(!empty($this->request->data)){
				$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
			}
			
			if($id!=null){
				$this->request->data = $this->Faqcategory->read(null,$id);
			}else{
				$this->request->data = array();
			}
		}
		
		$referer_url = $this->request->query('back');
		if(!empty($referer_url)){
			$referer_url= $this->request->query('back');
		}else{
			$referer_url=(Controller::referer()=="/")? Router::url('/admin/faq_manager/faqs/faqcategory',true) :Controller::referer();
		
		}
		
		$this->set('referer_url',$referer_url);
		$this->set('faq_id',$id);

		}
	function index($id = null){
		$this->paginate = array();
		$condition = array('Faq.status'=>1);
		$this->paginate['limit']=10;
		$news_articles = array();
		$this->paginate['order']=array('Faq.faq_order'=>'ASC','Faq.id'=>'DESC');
		$faqs= $results=$this->paginate("Faq", $condition);
		//$this->Faq->bindModel(array('belongsTo' => array('Faqcategory' => array('foreignKey' => false,'conditions' => array('Faq.cat_id = Faqcategory.id')))));
		$page=$this->Page->find('first',array('conditions'=>array('Page.id'=>40,'Page.status'=>1)));
		$faqByCategory = array();
		foreach($faqs as $value){
			$faqByCategory[$value['Faqcategory']['category']][]=$value;
		}
		//$faqcat = $this->Faqcategory->find('all');
		
		//print_r($faqByCategory);
		$this->set('faqs', $faqByCategory);
		$this->set('faqcat', $faqcat);
		if(!empty($page)){
			$this->System->set_data('banner_image',$page['Page']['banner_image']);
			$this->System->set_seo('site_title',$page['Page']['page_title']);
			$this->System->set_seo('site_metakeyword',$page['Page']['page_metakeyword']);
			$this->System->set_seo('site_metadescription',$page['Page']['page_metadescription']);
		}
	}

	function ajax_sort(){
		Cache::delete('faqs'); 
		$this->autoRender = false;
		foreach($_POST['sort'] as $order => $id){
			$slide= array();
			$slide['Faq']['id'] = $id;
			$slide['Faq']['faq_order'] = $order;
		  
			$this->Faq->create();
			$this->Faq->save($slide);
		}
	}
	function admin_delete($id=null){
		$this->autoRender = false;
		//print_r($this->request->data);exit;
		$data=$this->request->data['Faq']['id'];
		$action = $this->request->data['Faq']['action'];
		$ans="0";
		//print_r($data);exit;
		foreach($data as $value){
//print_r($value);exit;
			if($value!='0'){
				echo $value;
				if($action=='Publish'){
					$faq['Faq']['id'] = $value;
					$faq['Faq']['status']=1;
					$this->Faq->create();
					$this->Faq->save($faq);
					$ans="1";
				}
				if($action=='Unpublish'){
					$faq['Faq']['id'] = $value;
					$faq['Faq']['status']=0;
					$this->Faq->create();
					$this->Faq->save($faq);
					$ans="1";
				}
				if($action=='Delete'){
					//echo $value;
					$this->Faq->delete($value);
					//$this->Faq->delete_routes($value,'Faq');
					$ans="2";
				}
			}
		}
		Cache::delete('faqs');
		if($ans=="1"){
			$this->Session->setFlash(__('FAQ has been '.strtolower($this->data['Faq']['action']).'ed successfully', true));
		}
		else if($ans=="2"){
			$this->Session->setFlash(__('FAQ has been '.strtolower($this->data['Faq']['action']).'d successfully', true));
		}else{
			$this->Session->setFlash(__('Please Select any FAQ', true),'default','','error');
		}
		$this->redirect($this->request->data['Faq']['redirect']);
                 
	}
	function admin_delete_category($id=null){
		
		$this->autoRender = false;
		$data=$this->request->data['Faqcategory']['id'];
		$action = $this->request->data['Faqcategory']['action'];
		foreach($data as $value){
           if($value!='0'){
			   //$value = 1;
			 // print_r($value);
				if($action=='Delete'){
					$this->Faqcategory->delete($value);
					//$this->Faqcategory->delete_routes($value,'Faqcategory');
				}
			}
		}
		Cache::delete('Faqcategories');
		$this->Session->setFlash(__('FAQ category has been '.strtolower($this->data['Faqcategory']['action']).'d successfully', true));
		$this->redirect($this->request->data['Faqcategory']['redirect']);
                 
	}
	function validation(){
		if($this->request->data['Faq']['form']=="faq_add"){
		if(!empty($this->request->data['Faq']['form'])){
			if($this->request->data['Faq']['form']=="faq_add" && $this->request->data['Faq']['status']==2){
				return true;
			}
			$this->Faq->setValidation($this->request->data['Faq']['form']);
		}else{
			throw new NotFoundException('404 Error - Faq not found');
		}
		$this->Faq->set($this->request->data);
		return $this->Faq->validates();
	    }else{
		  if(!empty($this->request->data['Faqcategory']['form'])){
			if($this->request->data['Faqcategory']['form']=="faqcategory_add"){
				return true;
			}
			$this->Faqcategory->setValidation($this->request->data['Faqcategory']['form']);
		}else{
			throw new NotFoundException('404 Error - Faq not found');
		}
		$this->Faqcategory->set($this->request->data);
		return $this->Faqcategory->validates();
		}
	}
	public function ajax_validation($returnType = 'json'){
		//print_r($this->request->data);exit;
		$this->autoRender = false;
		if(!empty($this->request->data)){
			if(!empty($this->request->data['Faq']['form'])){
				$this->Faq->setValidation($this->request->data['Faq']['form']);
				//print_r($this->Faq->setValidation($this->request->data['Faq']['form']));exit;
			}
			$this->Faq->set($this->request->data);
			//print_r($this->Faq->set($this->request->data));exit;
			$result = array();
			if($this->request->data['Faq']['form']=="faq_add" && $this->request->data['Faq']['status']==2){
				$result['error'] = 0;
			}else{
				if($this->Faq->validates()){
					$result['error'] = 0;
				}else{
					$result['error'] = 1;
					$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
				}
			}
			$errors = array();
			$result['errors'] = $this->Faq->validationErrors;
			foreach($result['errors'] as $field => $data){
			  $errors['Faq'.Inflector::camelize($field)] = array_pop($data);
			}
			$result['errors'] = $errors;
			$view = new View();
			
			$result['error_message'] = $view->element('admin/message');
			echo json_encode($result);
			return;
		}
		echo json_encode(array());
	}
	public function ajax_validation_forcategory($returnType = 'json'){
		
	     $this->autoRender = false;
		if(!empty($this->request->data)){
			if(!empty($this->request->data['Faqcategory']['form'])){
				$this->Faqcategory->setValidation($this->request->data['Faqcategory']['form']);
				
			}
			$this->Faqcategory->set($this->request->data);
			//print_r($this->Faqcategory->set($this->request->data));exit;
			$result = array();
			if($this->request->data['Faqcategory']['form']=="faqcategory_add" && $this->request->data['Faqcategory']['status']==2){
				$result['error'] = 0;
			}else{
				if($this->Faqcategory->validates()){
					$result['error'] = 0;
				}else{
					$result['error'] = 1;
					$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
				}
			}
			$errors = array();
			$result['errors'] = $this->Faqcategory->validationErrors;
			foreach($result['errors'] as $field => $data){
			  $errors['Faqcategory'.Inflector::camelize($field)] = array_pop($data);
			}
			$result['errors'] = $errors;
			$view = new View();
			
			$result['error_message'] = $view->element('admin/message');
			echo json_encode($result);
			return;
		}
		echo json_encode(array());	
	}
	
	
}
?>