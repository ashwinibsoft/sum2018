<?php
class FaqManagerAppController extends AppController{
	public $page = array();
	function beforeFilter() {
		parent::beforeFilter();	
		Configure::load('FaqManager.config');
	}
}
?>