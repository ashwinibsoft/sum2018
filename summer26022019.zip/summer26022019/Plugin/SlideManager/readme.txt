/*********************************** Slide Manager VERSION *************************************/
VERSION Cake1.2

/*********************************** Burgeon Base VERSION Compatible *************************************/
VERSION 1.0
VERSION 1.1

/**********************************CAKEPHP VERSION *********************************************/
cakephp version 2.3.0


/********************************LAST UPDATED ON **********************************************/
last updated on 14-September -2013 15:22 pm


/*****************************USED IN FOLLOWING PROJECTS ***************************************/
Used on following projects:
Steve Organics


/***************************Features ****************************************************/
Ajax pagination on listing page (ADMIN).
Numberic Pagination on Disable Javascript.
Dyanamic load ck editor on admin.
navigation controls on admin.
Flexi Slider Script
Full Module - Admin + Front

//*****************************Front Request Function **********************************************/
$this->SlideManager->show();

