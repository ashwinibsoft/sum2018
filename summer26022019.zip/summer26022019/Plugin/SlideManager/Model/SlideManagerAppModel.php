<?php
Class SlideManagerAppModel extends AppModel {
}
?>