<?php
Class Search extends ContentManagerAppModel {
	public $name = "Search";
	public function paginate($conditions, $fields, $order, $limit, $page = 1, $recursive = null, $extra = array()) {    
        $recursive = -1;
        
        // Mandatory to have
        $this->useTable = false;
        $sql = '';
       
        $sql .= "SELECT news_articles.id,news_articles.news_name,news_articles.short_description,1 FROM news_articles WHERE news_articles.news_name LIKE '%$conditions%' OR news_articles.short_description LIKE '%$conditions%' OR news_articles.description LIKE '%$conditions%' UNION SELECT faqs.id,faqs.question,faqs.answer,2 FROM faqs WHERE faqs.question LIKE '%$conditions%' OR faqs.answer LIKE '%$conditions%' LIMIT ";
        
        // Adding LIMIT Clause
        $sql .= (($page - 1) * $limit) . ', ' . $limit;
        
        $results = $this->query($sql);
        
        return $results;
    }
    public function paginateCount($conditions = null, $recursive = 0, $extra = array()) {
        
        $sql = '';
        
        $sql .= "SELECT news_articles.id,news_articles.news_name,news_articles.short_description,1 FROM news_articles WHERE news_articles.news_name LIKE '%$conditions%' OR news_articles.short_description LIKE '%$conditions%' OR news_articles.description LIKE '%$conditions%' UNION SELECT faqs.id,faqs.question,faqs.answer,2 FROM faqs WHERE faqs.question LIKE '%$conditions%' OR faqs.answer LIKE '%$conditions%'";
            
        $this->recursive = $recursive;
        
        $results = $this->query($sql);
        
        return count($results);
    }
}
?>
