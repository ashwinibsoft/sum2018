<?php
Class Page extends ContentManagerAppModel {
	public $name = "Page";
	public $actsAs = array('Multivalidatable');
	//public $useTable = 'categories';
	public $page_action = "";
	public $validationSets = array(
	'page_add'=>array(
			'name'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Plaese enter page name.'),
				'rule2' => array('rule' => array('maxLength', 255),'message' => 'Name should be less than 255 charcter(s).')
				),
			'banner_image' => array(
					
					'rule1'=>array(
							'rule' => array('chkImageExtension'),
							'message' => 'Please Upload Valid Image.'
						),
					/*'rule2'=>array(
							'rule' => array('check_size'),
							'message' => 'Only png, gif, jpg, jpeg images are allowed. Please upload 1000x500 dimension of image for better resolution.'
						),*/
				),
			'slug_url'=>array(
					'rule1'=>array(
									'rule' => 'is_valid_url',
									'message' => 'Please enter text in lower case without any space.'),
					'rule2'=>array(
									'rule' => 'check_slug_url',
									'message' => 'This slug url is already associated with other page or module')
				)
			),
		'contact_foot'=>array(
			'name'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Please enter name.'),
				'rule2' => array('rule' => array('maxLength', 255),'message' => 'Name should be less than 255 charcter(s).')
				),
			'email'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Please enter email address.'),
				'rule2' => array('rule' => 'email','message' => 'Please enter valid email address')
				)
		),
		'contact'=>array(
			'name'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Please enter name.'),
				'rule2' => array('rule' => array('maxLength', 255),'message' => 'Name should be less than 255 charcter(s).')
				),
			
			'email'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Please enter email address.'),
				'rule2' => array('rule' => 'email','message' => 'Please enter valid email address')
				),
			/*'phone'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Please enter phone number.'),
				/*'rule2' => array('rule' => array('phone','/^[(]{0,1}[0-9]{3}[)]{0,1}[-\s.]{0,1}[0-9]{3}[-\s.]{0,1}[0-9]{4}$/','all'),'message' => 'Please enter valid phone number') */
			//	)
			
			/*'phone'=>array(
			
			'rule1'=>array('rule' => 'notEmpty','message' => 'Please enter phone number.'),
			'rule2'=> array('rule' => array('isValidUSPhoneFormat'),
						'message' => 'Please enter a valid contact number.'
							)
				),*/
				
			'phone'=>array(
			
			'rule1'=>array('rule' => 'notEmpty','message' => 'Please enter phone number.'),
			'rule2'=> array('rule' =>'numeric',
						'message' => 'Please enter number only.',
						'allowEmpty' => false
					),
				),	
				
				
			'captchamatch'=>array(
					'rule1' =>array('rule' => 'notEmpty','message' => 'Please enter security code.'),
					'rule2' =>array('rule' => 'matchCaptcha','message' => 'Failed validating human check.')								
				)
		/*	'area_code'=>array(	
				'rule1' => array('rule' => 'notEmpty','message' => 'Please enter valid area code.'),
				'rule2' => array('rule' => 'area_code','message' => 'Enter valid area code.')
				
				),
			'country_code'=>array(	
				'rule1' => array('rule' => 'notEmpty','message' => 'Please enter valid country code.'),
				'rule2' => array('rule' => 'country_code','message' => 'Enter valid country code.'),
				),
		*/
		
		),
			
		'page_settings' =>array(
			'banner_image' => array(
					
					'rule1'=>array(
							'rule' => array('validate_image'),
							'message' => 'Please Upload Valid Image.'
						),
					/*'rule2'=>array(
							'rule' => array('check_size'),
							'message' => 'Only png, gif, jpg, jpeg images are allowed. Please upload 1000x500 dimension of image for better resolution.'
						),*/
				)
		)
	);
	
	public function afterSavee($created , $options = array()) {
		App::import('model','ShortLink');
		$ShortLink = new ShortLink();
		if(!$ShortLink->find('count',array('conditions'=>array('ShortLink.object_id'=>$this->id,'ShortLink.module'=>'Page')))){
			$shortlink['ShortLink']['short_code'] = "{".$this->data['Page']['url_key']."}";
			$shortlink['ShortLink']['object_id'] = $this->id;
			$shortlink['ShortLink']['module'] = "Page";
			$ShortLink->save($shortlink);
		}
		Cache::delete('cake_page_routing');
	}
	public function afterDelete(){
		App::import('model','ShortLink');
		$ShortLink = new ShortLink();
		$ShortLink->deleteAll(array('ShortLink.object_id'=>$this->id,'ShortLink.module'=>'Page'),false);
		Cache::delete('cake_page_routing');
	}
    public function urlkeycheck($check){
        // $data array is passed using the form field name as the key
        // have to extract the value to make the function generic
        $value = array_values($check);
        $value = $value[0];
        return preg_match('|^[a-zA-Z-_.]+$|', $value);
    }
    function matchCaptcha($nputValue)  {
		App::import('Component', 'Session');
		$Captch = CakeSession::read('security_code');
		if($Captch != $this->data['Page']['captchamatch']){
			return false;
		}
		return true;
	}
	
	function isValidUSPhoneFormat($phone){
		$phone=$this->data['Page']['phone'];
		$errors = array();
			if(empty($phone)) {
			   $errors [] = "Please enter phone number";
			}
			else if (!preg_match('/^\+?[0-9 \-]+$/', $phone)) {
				$errors [] = "Please enter valid phone number.";
			} 
			if (!empty($errors)){
			return false;   //implode("\n", $errors);
		}
			return true;
	}
	
	function validate_image(){
		if((!empty($this->data['Page']['id'])) && $this->data['Page']['banner_image']['name']=='') {
			return true;
		}else{
			if(!empty($this->data['Page']['banner_image']['name'])) {
				$file_part = explode('.',$this->data['Page']['banner_image']['name']);
				$ext = array_pop($file_part);		
				if(!in_array(strtolower($ext),array('gif', 'jpeg', 'png', 'jpg'))) {
					return false;
				}
			}
		return true;
		}
	}
	public function chkImageExtension($data) {
		if(!empty($data['banner_image']['name'])){
				$fileData= pathinfo($data['banner_image']['name']);
				$ext=$fileData['extension'];
				$allowExtension=array('gif', 'jpeg', 'png', 'jpg','JPG');
				if(in_array($ext, $allowExtension)) {
					$return = true; 
				} else {
					$return = false;
				}
			} else{
			
				$return = true; 
			}
			return $return;
		}


	public function check_size(){
		if($this->data['Page']['banner_image']['tmp_name']=='') {
			return true;
		}else{
			if($this->data['Page']['banner_image']['error'] < 1){
				$imgSize = @getImageSize($this->data['Page']['banner_image']['tmp_name']);
				if(($imgSize[0]>=1000 ) && ($imgSize[1]>=500 ))
				{
					return true;
				}
			}
			return false;
		}
	}
	public function uploadFile( $check ) {
		$uploadData = array_shift($check);
		if ( $uploadData['size'] == 0 || $uploadData['error'] !== 0) {
			return false;
		}
		return true;
	}
	function check_slug_url(){
		if((!empty($this->data['Page']['id'])) && !empty($this->data['Page']['slug_url'])) {
			if($this->_check_uri_exist_on_other($this->data['Page']['slug_url'],'Page',$this->data['Page']['id'])){
				return false;
			}else{
				return true;
			}
		}
		return true;
	}
	function is_valid_url(){
		if((!empty($this->data['Page']['id'])) && !empty($this->data['Page']['slug_url'])) {
			return preg_match('|[a-z-.]+$|', $this->data['Page']['slug_url']);
		}
		return true;
	}
	
	function country_code() {  
		if(!empty($this->data['Page']['country_code'])) {
			$country_code=$this->data['Page']['country_code'];
			if(!preg_match('/^[+]{1}[0-9]{1,6}$/', $country_code)){
				return false; 
			}
		    return true;
		}
        return false; 
	}
	
	 function area_code() {  
		if(!empty($this->data['Page']['area_code'])) {
			$country_code=$this->data['Page']['area_code'];
			if(!preg_match('/^[0-9]{2,6}$/', $country_code)){
				return false; 
			}
		    return true;
		}
        return false; 
	}
}
?>
