<?php
Class ContentManagerAppModel extends AppModel {
}
?>