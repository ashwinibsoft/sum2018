<?php
Class NewBuyerManagerAppModel extends AppModel {
}
?>
