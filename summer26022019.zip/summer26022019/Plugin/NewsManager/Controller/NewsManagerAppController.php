<?php
class NewsManagerAppController extends AppController{
	public $post = array();
	function beforeFilter() {
		parent::beforeFilter();	
		Configure::load('NewsManager.config');
	}
}
?>