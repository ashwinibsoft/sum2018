<?php
Class NewsArticlesController extends NewsManagerAppController{
	public $uses = array('NewsManager.NewsArticle','NewsManager.NCategoryLink','ContentManager.Page',);
	public $components=array('Email','RequestHandler','Image');
	public $paginate = array();
	public $id = null;
	public $template=null;
	
	public function admin_index($search=null,$limit=10,$category=0){
		$this->paginate = array();
		$condition = null;
		if($search=="_blank"){
			$search=null;
		}
		$this->paginate['limit']=$limit;
		if($this->request->is('post')){
			if(!empty($this->request->data['category'])){
				$category = $this->request->data['category'];
			}else{
				$category = 0;
			}
			if(!empty($this->request->data['search'])){
				$search = $this->request->data['search'];
			}else{
				$search = '_blank';
			}
			if(!empty($this->request->data['limit'])){
				$limit = $this->request->data['limit'];
			}else{
				$limit = '10';
			}
			$this->redirect(array('plugin'=>'news_manager','controller'=>'news_articles','action'=>'index',$search,$limit,$category));
		}
		if($search!=null){
			$search = urldecode($search);
			$condition['NewsArticle.news_name like'] = '%'.$search.'%';
		}
		if($category!=0){
			$condition['NewsArticle.n_categorie_id like'] ='%'.$category.'%';
		}
		$news_articles = array();
		$this->paginate['fields'] = 
		array('NewsArticle.id','NewsArticle.news_name','NewsArticle.event_date','NewsArticle.start_time','NewsArticle.end_time','NewsArticle.status','NewsArticle.created_at','NewsArticle.feature_image','NewsArticle.n_categorie_id');
		
		$this->paginate['order']=array('NewsArticle.id'=>'DESC');
		$news_articles= $results=$this->paginate("NewsArticle", $condition);
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/home'),
			'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/news_manager/news_articles'),
			'name'=>'Manage News & Events'
		);
		
		$this->heading =  array("Manage","News & Events");
		$this->loadModel('NewsManager.NCategorie');
		$cat_list = $this->NCategorie->find('list',array('fields'=>array('id','cat_name'),'order'=>array('NCategorie.id'=>'DESC')));
		$this->set('cat_list',$cat_list);
		$this->set('category',$category);
		$this->set('news_articles',$news_articles);
		$this->set('limit',$limit);
		$this->set('search',$search);
		$this->set('url','/'.$this->params->url);
	
	}
	
	function admin_default_image_crop($news_id=null){
		$path  = $this->webroot;
		$this->Image = $this->Components->load('Image');
		$this->Image->startup($this);
		$news_detail = $this->NewsArticle->find('first', array('conditions' => array('NewsArticle.id' => $news_id)));
		if($this->request->is('post')){
			
			$org_image_breaks = explode('.',$news_detail['NewsArticle']['feature_image']);
			$ext = array_pop($org_image_breaks);
			$origFile = $news_detail['NewsArticle']['feature_image'];

			$src = Configure::read('Path.News').$news_detail['NewsArticle']['feature_image'];
			$old_banner = Configure::read('Path.News').$news_detail['NewsArticle']['feature_image'];
			$org_image_breaks = implode('.',$org_image_breaks);
			$org_image_breaks = explode('_',$org_image_breaks);
			array_pop($org_image_breaks);
			$org_image_breaks = implode('_',$org_image_breaks);
			$new_name =$org_image_breaks.'_'.time().'.'.$ext;
			$dst =  Configure::read('Path.News').$new_name;
			
			$start_width = $this->data[
'x'];
			$start_height = $this->data['y'];
			$width = $this->data['width'];
			$height = $this->data['height'];
			$key = 'feature_image';
			$thumb = $this->Image->crop($src,$dst,$width,$height,$start_width,$start_height,$this->data['scale']);
			$news_data = array();
			$news_data['NewsArticle']['id'] = $news_id;
			$news_data['NewsArticle']['feature_image'] = $new_name;
			$news_data['NewsArticle']['is_cropped'] = 1;
			
			$_options = array(
						'destination'=>Configure::read('Path.NewsArticle'),
						); 
			if($this->NewsArticle->save($news_data,array('validate'=>false))){
				if($news_detail['NewsArticle']['feature_image']!='' && file_exists($old_banner)){
					unlink($old_banner);
				}
				$this->Session->setFlash('Image cropped and saved.');
				//$this->redirect(array('action'=>'admin_crop_success',$news_id));
				$this->redirect(array('controller' => 'news_articles', 'action' => 'admin_add',$news_id));
			}
			Cache::delete('site');
			$this->redirect(array('action'=>'admin_add',$news_id));
		}
		$this->set('news_detail',$news_detail);
		$this->set('news_id',$news_id);
	}
	
	
	function admin_crop_success($news_id=null){
		$news_detail = $this->NewsArticle->find('first', array(
			'conditions' => array('NewsArticle.id' => $news_id)
		));
		$this->set('news_detail',$news_detail);
		$this->set('news_id',$news_id);
	}
	
	
	function admin_add($id=null){
		//echo "<pre>";print_r($this->request->data);die;
		$path  = $this->webroot;
		$galleries = array();
		if($this->_is_active_plugins('GalleryManager')){
			$this->loadModel('GalleryManager.Gallery');
			$galleries = $this->Gallery->find('list',array('fields'=>array('id','name'),'order'=>array('Gallery.id'=>'DESC')));
		}
		$this->loadModel('NewsManager.NCategorie');
		$cat_list = $this->NCategorie->find('list',array('fields'=>array('id','cat_name'),'conditions'=>array('NCategorie.status'=>'1'),'order'=>array('NCategorie.id'=>'DESC')));
		
		$this->breadcrumbs[] = array(
		'url'=>Router::url('/admin/home'),
		'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/news_manager/news_articles'),
				'name'=>'Manage News & Events'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/news_manager/news_articles/add/'.$id),
				'name'=>($id==null)?'Add Content':'Update News & Events'
		);
		if($id==null){
			$this->heading =  array("Add","News & Events");
		}else{
			$this->heading =  array("Update","News & Events");
		}
		
		
		
		if(!empty($this->request->data) && $this->validation()){
			$existing_image='';
			//print_r($this->request->data); die;
			if($this->request->data['NewsArticle']['id']){
				$news_image = $this->NewsArticle->find('first',array('fields'=>array('NewsArticle.feature_image'),'conditions'=>array('NewsArticle.id'=>$this->request->data['NewsArticle']['id'])));
				$existing_image = $news_image['NewsArticle']['feature_image'];
			}
			
			$_options = array(
			'destination'=>Configure::read('Path.News'),
			'image'=>$this->request->data['NewsArticle']['feature_image']
			);
			if($this->request->data['NewsArticle']['feature_image']['error'] > 0 && !empty($this->request->data['NewsArticle']['id'])){
				$this->request->data['NewsArticle']['feature_image'] = $existing_image;
			}else{
				if($this->request->data['NewsArticle']['feature_image']['error'] < 1){
				$this->request->data['NewsArticle']['feature_image'] = $this->System->Image->upload($_options);
				$this->request->data['NewsArticle']['is_cropped'] = 0;
				}else{
					$this->request->data['NewsArticle']['feature_image'] = "";
				}
			}
			 if($this->request->data['NewsArticle']['event_date']) 
                { 
					$var =$this->request->data['NewsArticle']['event_date'];
					$event_date=date("Y-m-d", strtotime($var));
					$this->request->data['NewsArticle']['event_date']=$event_date;
					$this->request->data['NewsArticle']['start_time']=date("H:i:s", strtotime($this->request->data['NewsArticle']['start_time']));
					$this->request->data['NewsArticle']['end_time']=date("H:i:s", strtotime($this->request->data['NewsArticle']['end_time']));
					
					
				}
			if(!$id){
				$this->request->data['NewsArticle']['created_at']=date('Y-m-d H:i:s');
				
				//$this->request->data['NewsArticle']['status'] = 1;
			}else{
				$this->request->data['NewsArticle']['updated_at']=date('Y-m-d H:i:s');
			}
			if(empty($this->request->data['NewsArticle']['id'])){
				if(isset($this->request->data['save']) && $this->request->data['save']=='Save'){
					$this->request->data['NewsArticle']['status'] = 2;
				}else{
					$this->request->data['NewsArticle']['status'] = 1;
				}
			}
			if(!empty($this->request->data['NewsArticle']['n_categorie_id']))
			{
				$pcat=$this->request->data['NewsArticle']['n_categorie_id'];
				$this->request->data['NewsArticle']['n_categorie_id']=json_encode($this->request->data['NewsArticle']['n_categorie_id']);
				}
				else
				{
				$this->request->data['NewsArticle']['n_categorie_id']="";
					}
			
			
					
			$this->NewsArticle->create();
			$this->NewsArticle->save($this->request->data,array('validate'=>false));
			$id = $this->NewsArticle->id;
			
			$catid = $this->NewsArticle->id;
			$this->NCategoryLink->deleteAll(array('NCategoryLink.news_article_id' => $id));
			if(!empty($pcat))
			{
			foreach($pcat as $pcatg){
							$datas['news_article_id']=$catid;
							$datas['n_categorie_id']=$pcatg;
							$this->NCategoryLink->create();
							$this->NCategoryLink->save($datas,array('validate'=>false));
					}
				}
			/* Slug URL Logic Start*/
			$slug_url = '';
			if(empty($this->request->data['NewsArticle']['id'])){
				if($this->request->data['NewsArticle']['slug_url']==''){
					$string = strtolower($this->request->data['NewsArticle']['news_name']);
					$slug_url = Inflector::slug($string, '-');
				}else{
					$slug_url = $this->request->data['NewsArticle']['slug_url'];
				}
			}else{
				$slug_url = $this->request->data['NewsArticle']['slug_url'];
			}
			/* Slug URL Logic END*/
			
			$route = array();
			$route['request_uri'] = trim($slug_url);
			$route['object'] = 'NewsArticle';
			$route['object_id'] = $this->NewsArticle->id;
			$route['object_name'] = $this->request->data['NewsArticle']['news_name'];
			$route['values'] = json_encode(array('plugin'=>'news_manager','controller'=>'news_articles','action'=>'view','id'=>$this->NewsArticle->id));
			
			$this->NewsArticle->save_routes($route);
			
			
			if ($this->request->data['NewsArticle']['id']) {
				$this->Session->setFlash(__('News & Events has been updated successfully'));
			} 
			else{
				$this->Session->setFlash(__('News & Events has been added successfully'));
			}
			$this->redirect(array('action'=>'add',$id,'?'=>array('back'=>$this->request->data['NewsArticle']['url_back_redirect'])));
		}
		else{
			if(!empty($this->request->data)){
				$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
			}
		if($id!=null){
				$this->request->data = $this->NewsArticle->read(null,$id);	
				//print_r($this->request->data); die;
				$this->request->data['NewsArticle']['n_categorie_id']=json_decode($this->request->data['NewsArticle']['n_categorie_id'], true);
				$this->request->data['NewsArticle']['slug_url'] = $this->NewsArticle->get_uri('NewsArticle',$id);
					
				//print_r($this->request->data);die;
			}else{
				$this->request->data = array();
			}	
			
				
			
		}
		
		$referer_url = $this->request->query('back');
		if(!empty($referer_url)){
			$referer_url= $this->request->query('back');
		}else{
			$referer_url=(Controller::referer()=="/")? Router::url('/admin/news_manager/news_articles',true) :Controller::referer();
		
		}
		//echo $start_time; die;
		$this->set('referer_url',$referer_url);
		$this->set('galleries',$galleries);
		$this->set('cat_list',$cat_list);
		$this->set('news_id',$id);
		
	}
	public function admin_one_delete($news_id = null){
		$this->autoRender = false;
		if($news_id==null){
			$this->redirect(Controller::referer());
		}
		$news = $this->NewsArticle->find('first', array('conditions'=> array('NewsArticle.id' => $news_id)));
		if (!empty($news['NewsArticle']['news_image'])) {
			   @unlink(WWW_ROOT."img/news/". $news['NewsArticle']['news_image']);
		}
		$this->NewsArticle->delete($news_id);
		$this->NewsArticle->delete_routes($news_id,'NewsArticle');
		$options = array(
		'ref_id'=>$news_id,
		'module'=>'NewsArticle',
		);
		$this->NewsArticle->delete_menu($options);
		$this->Session->setFlash(__('News & Event has been deleted successfully'));
		$redirect_url = $this->request->query('back');
		if(!empty($redirect_url)){
			$this->redirect($redirect_url);
		}else{
			$this->redirect(array('action'=>'admin_index'));
		}
		
		
		
	}
	function admin_delete_default_news_image(){
		$this->Session->write('delete_default_feature_image',1);
		/*
		$this->autoRender = false;
		$this->loadModel('Setting');
		$image = $this->System->get_setting('page','banner_image');
		$new_name = '';
		$key = 'banner_image';
		$this->Setting->query("UPDATE `settings` SET `values`=\"$new_name\" WHERE `key`=\"$key\" and module=\"page\"");
		$this->Setting->query("UPDATE `settings` SET `values`=0 WHERE `key`=\"override_banner_image\" and module=\"page\"");
		$old_banner = Configure::read('Path.Banner').$image;
		Cache::delete('site');
		if(file_exists($old_banner)){
			unlink($old_banner);
		}
		*/
	}
	
	private function __admin_delete_default_news_image(){
		//$this->autoRender = false;
		$this->loadModel('Setting');
		$image = $this->System->get_setting('news_manager','feature_image');
		$new_name = '';
		$key = 'feature_image';
		
		$this->Setting->query("UPDATE `settings` SET `values`=\"\" WHERE `key`=\"$key\"");
		$this->Setting->query("UPDATE `settings` SET `values`= \"0\" WHERE `key`=\"override_news_image\"");
		$old_banner = Configure::read('Path.News').$image;
		//Cache::delete('site');
		if(file_exists($old_banner)){
			unlink($old_banner);
		}
	}
	public function admin_settings(){
		$this->UserLib->add_authorize_action(array('admin_settings'));
		$this->UserLib->add_authenticate_action(array('admin_settings'));
		$this->UserLib->check_authenticate($this);
		$this->UserLib->check_authorize($this);
		
		
		$news_list = $this->NewsArticle->find('threaded',array('fields'=>array('NewsArticle.id','NewsArticle.news_name')));
		
		$this->loadModel('Setting');
		if(!empty($this->request->data)){
			if($this->Session->check('delete_default_feature_image')){
				$action = (int)$this->Session->read('delete_default_feature_image');
				if($action){
					self::__admin_delete_default_news_image();
				}
			}
			
			foreach($this->request->data['NewsArticle'] as $key => $value){
				if($key == 'url_back_redirect' || $key == 'form' ){
					continue;
				}
				if(is_array($value)){
					
					if($key=='feature_image'){
						
						$_options = array(
										'destination'=>Configure::read('Path.News'),
										'image'=>$value,
									);
						$_file = $this->System->get_setting('news_manager',$key);
						if(!empty($_file) && !empty($value['name'])){
							if(file_exists(Configure::read('Path.News').$this->System->get_setting('news_manager',$key))){
								unlink(Configure::read('Path.News').$this->System->get_setting('news_manager',$key));
							}
						}
						if($value['error'] > 0){
							$value=$_file;
						}else{
							//$value = $this->Upload->move_uploaded_file($value,$_options);
							$value = $this->System->Image->upload($_options);
						}
					}else if ($key=='home_news_blocks'){
						$value = json_encode($value);
					}else{
						continue;
					}
				}
				$value = addslashes($value);
				
				if($this->Setting->find('count',array('conditions'=>array('Setting.key'=>$key,'Setting.module'=>'news_manager')))){
					$this->Setting->query("UPDATE `settings` SET `values`=\"$value\" , module=\"news_manager\" WHERE `key`=\"$key\"");
				} else{
					$this->Setting->query("INSERT `settings` SET `values`=\"$value\"  , `key`=\"$key\" , module=\"news_manager\"");
				}
				$this->Session->setFlash(__('NewsArticle Setting(s) has been saved successfully'));
			}
			$this->redirect(array('action'=>'settings','?'=>array('back'=>$this->request->data['NewsArticle']['url_back_redirect'])));
		}
		$this->Session->delete('delete_default_feature_image');
		Cache::delete('site');
		$this->request->data['NewsArticle'] = $this->Setting->find('list',array('fields'=>array('Setting.key','Setting.values'),'conditions'=>array('Setting.module'=>'news_manager')));
		$referer_url = $this->request->query('back');
		if(!empty($referer_url)){
			$referer_url= $this->request->query('back');
		}else{
			$referer_url=(Controller::referer()=="/")? Router::url('/admin/news_manager/settings',true) :Controller::referer();
		
		} 
		$this->breadcrumbs[] = array(
		'url'=>Router::url('/admin/home'),
		'name'=>'Dashboard'
		);
			$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/news_manager/settings'),
				'name'=>'News Manager Settings'
		);
		$this->heading =  array("Manage","News Manager Settings");
		$this->set('referer_url',$referer_url);
		$this->set('news_list',$news_list);
	}
	
	
	function admin_delete_news_image($id= null){
		$this->news = $this->NewsArticle->read(null,$id);
		$this->NewsArticle->updateAll(
				array('NewsArticle.feature_image' => null),
				array('NewsArticle.id'=>$id)
			);
		self::__delete_news_image();
		if ($this->request->is('ajax')) {
			$this->autoRender = false;
		}else{
			$this->redirect(array('action'=>'add',$id));
		}
	}
	
	
	private function __delete_news_image(){
		App::uses('ImageResizeHelper', 'View/Helper');
		$ImageResize = new ImageResizeHelper();
		$imgArr = array('source_path'=>Configure::read('Path.News'),'img_name'=>$this->news['NewsArticle']['feature_image'],'width'=>Configure::read('image_edit_width'),'height'=>Configure::read('image_edit_height'));
		$ImageResize->deleteThumbImage($imgArr);
		
		$imgArr = array('source_path'=>Configure::read('Path.News'),'img_name'=>$this->news['NewsArticle']['feature_image'],'width'=>Configure::read('news_article_image_width'),'height'=>Configure::read('news_article_image_height'));
		$ImageResize->deleteThumbImage($imgArr);
		
		@unlink(Configure::read('Path.News'). $this->news['NewsArticle']['feature_image']);
		
	}
	
	
	function admin_delete($id=null){
		$this->autoRender = false;
		$data=$this->request->data['NewsArticle']['id'];
		$action = $this->request->data['NewsArticle']['action'];
		$ans="0";
		foreach($data as $value){
			
			if($value!='0'){
				$news = $this->NewsArticle->find('first', array('conditions'=> array('NewsArticle.id' => $value)));
				if((int)$news['NewsArticle']['status']==2){
					continue;
				}
				
				if($action=='Publish'){
					$news['NewsArticle']['id'] = $value;
					$news['NewsArticle']['status']=1;
					$this->NewsArticle->create();
					$this->NewsArticle->save($news);
					$ans="1";
				}
				if($action=='Unpublish'){
					$news['NewsArticle']['id'] = $value;
					$news['NewsArticle']['status']=0;
					$this->NewsArticle->create();
					$this->NewsArticle->save($news);
					$ans="1";
				}
				if($action=='Delete'){
					if (!empty($news['NewsArticle']['news_image'])) {
						   @unlink(WWW_ROOT."img/news/". $news['NewsArticle']['news_image']);
					}
					$this->NewsArticle->delete($value);
					$this->NewsArticle->delete_routes($value,'NewsArticle');
					$options = array(
					'ref_id'=>$value,
					'module'=>'NewsArticle',
					);
					$this->NewsArticle->delete_menu($options);
					
					
					$ans="2";
				}
			}
		}
		if($ans=="1"){
			$this->Session->setFlash(__('News & Events has been '.strtolower($this->data['NewsArticle']['action']).'ed successfully', true));
		}
		else if($ans=="2"){
			$this->Session->setFlash(__('News & Events has been '.strtolower($this->data['NewsArticle']['action']).'d successfully', true));
		}else{
			$this->Session->setFlash(__('Please select News & Events ', true),'default','','error');
		}
		$this->redirect($this->request->data['NewsArticle']['redirect']);
                 
	}
	private function __load_page($id = null){
		
		
		$news =  array();
		$news = $this->NewsArticle->find('first',array('conditions'=>array('NewsArticle.id'=>$id,'NewsArticle.status'=>1)));
		if(empty($news)){
			return null;
		}
		$this->current_id = $id;
		if((int)Configure::read('Section.default_news_image') && ($this->System->get_setting('news_manager','override_news_image'))){
			$page['NewsArticle']['feature_image'] = $this->System->get_setting('news_manager','feature_image');
		}
		$this->System->set_data('feature_image',$news['NewsArticle']['feature_image']);
		$news['Gallery'] = array();
		if((int)Configure::read('Section.gallery') && (int)$this->_is_active_plugins('GalleryManager')){
			
			$this->loadModel('GalleryManager.Gallery');
			if($news['NewsArticle']['news_gallery']!=""){	
				$this->Gallery->bindModel(
					array('hasMany' => array(
							'GalleryImage'
						)
					)
				);
				$gallery=$this->Gallery->find('first',array('conditions'=>array('Gallery.id'=>$news['NewsArticle']['news_gallery'],'Gallery.status'=>1)));
				$news = array_merge($news,$gallery);
			}
		}else{
			$news['NewsArticle']['gallery'] = null;
		}
		
		return $news;
	}
	function home(){
		
		$news = self::__load_page((int)$this->System->get_setting('news','default_home_news'));
		if (empty($news)) {
			throw new NotFoundException('404 Error - NewsArticle not found');
		}
		
		//print_r($news);die;
		$this->System->set_seo('site_title',$news['NewsArticle']['news_title']);
		$this->System->set_seo('site_metakeyword',$news['NewsArticle']['news_metakeyword']);
		$this->System->set_seo('site_metadescription',$news['NewsArticle']['news_metadescription']);
		$this->set('news',$news);
	}
	public function get($id = null){
		$this->autoRender = false;
		$news=$this->NewsArticle->find('first',array('conditions'=>array('NewsArticle.id'=>(int)$id,'NewsArticle.status'=>1)));
		return $news;
	}
	
	public function view($id=null){
		$news = $this->NewsArticle->find('first',array('conditions'=>array('NewsArticle.id'=>$id,'NewsArticle.status'=>1)));
		$page=$this->Page->find('first',array('conditions'=>array('Page.id'=>41,'Page.status'=>1)));
		$this->set('id', $id);
		$this->set('news', $news);
		if(!empty($page)){
			$this->System->set_data('banner_image',$page['Page']['banner_image']);
		}
		$this->System->set_seo('site_title',$news['NewsArticle']['news_title']);
		$this->System->set_seo('site_metakeyword',$news['NewsArticle']['news_metakeyword']);
		$this->System->set_seo('site_metadescription',$news['NewsArticle']['news_metadescription']);
		
	}
	public function index(){
		$this->paginate = array();
		$condition = array('NewsArticle.status'=>1);
		$this->paginate['limit']=10;
		$news_articles = array();
		//$this->paginate['fields'] = 
		//array('NewsArticle.id','NewsArticle.news_name','NewsArticle.short_description','NewsArticle.event_date','NewsArticle.start_time','NewsArticle.end_time','NewsArticle.status','NewsArticle.created_at','NewsArticle.feature_image','NewsArticle.n_categorie_id');
		
		$this->paginate['order']=array('NewsArticle.id'=>'DESC');
		$news_articles= $results=$this->paginate("NewsArticle", $condition);
		
		$page=$this->Page->find('first',array('conditions'=>array('Page.id'=>41,'Page.status'=>1)));
		$this->current_id = 41;
		$this->set('news_articles', $news_articles);
		if(!empty($page)){
			$this->System->set_data('banner_image',$page['Page']['banner_image']);
			$this->System->set_seo('site_title',$page['Page']['page_title']);
			$this->System->set_seo('site_metakeyword',$page['Page']['page_metakeyword']);
			$this->System->set_seo('site_metadescription',$page['Page']['page_metadescription']);
		}

	}
	
	
	function validation(){
		
		if(!empty($this->request->data['NewsArticle']['form'])){
			if($this->request->data['NewsArticle']['form']=="news_add" && $this->request->data['NewsArticle']['status']==2){
				return true;
			}
			$this->NewsArticle->setValidation($this->request->data['NewsArticle']['form']);
		}else{
			throw new NotFoundException('404 Error - NewsArticle not found');
		}
		$this->NewsArticle->set($this->request->data);
		return $this->NewsArticle->validates();
	}
	public function ajax_validation($returnType = 'json'){
		//print_r($this->request->data);die;
		$this->autoRender = false;
		if(!empty($this->request->data)){
			if(!empty($this->request->data['NewsArticle']['form'])){
				$this->NewsArticle->setValidation($this->request->data['NewsArticle']['form']);
			}
			$this->NewsArticle->set($this->request->data);
			$result = array();
			if($this->request->data['NewsArticle']['form']=="news_add" && $this->request->data['NewsArticle']['status']==2){
				$result['error'] = 0;
			}else{
				if($this->NewsArticle->validates()){
					$result['error'] = 0;
				}else{
					$result['error'] = 1;
					$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
				}
			}
			$errors = array();
			$result['errors'] = $this->NewsArticle->validationErrors;
			foreach($result['errors'] as $field => $data){
			  $errors['NewsArticle'.Inflector::camelize($field)] = array_pop($data);
			}
			$result['errors'] = $errors;
			$view = new View();
			
			$result['error_message'] = $view->element('admin/message');
			echo json_encode($result);
			return;
		}
		echo json_encode(array());
	}
	public function admin_dashboard(){
		$news_articles=$this->NewsArticle->find('all',array('limit'=>5,'order'=>array('NewsArticle.system_news'=>'ASC','NewsArticle.id'=>'desc')));
		$this->set('news_articles',$news_articles);
	}
}
?>