<?php
Class NCategoryLink extends NewsManagerAppModel {
	public $name = "NCategoryLink";
	
}
?>
