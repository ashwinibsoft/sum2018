<?php
Class NComment extends NewsManagerAppModel {
	public $name = "NComment";
	
}
?>
