<?php
Class NewsManagerAppModel extends AppModel {
}
?>
