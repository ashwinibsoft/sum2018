<?php
Class NewsArticle extends NewsManagerAppModel {
	public $name = "NewsArticle";
	public $actsAs = array('Multivalidatable');
	//public $useTable = 'categories';
	public $news_article_action = "";
	public $validationSets = array(
	'news_add'=>array(
			'news_name'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Please enter news title.'),
				'rule2' => array('rule' => array('maxLength', 255),'message' => 'Name should be less than 255 charcter(s).')
				),
			'short_description'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Please enter short description.'),
				),		
			'description'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Please enter long description.'),
				),	
			'event_date' =>
				array(
					'rule1' =>
					array(
							'rule'    => 'notEmpty',
							'message'  => 'Please enter news & event date.'
							),
					array(
						'rule' => array('date', 'mdy'),
							'message' => 'You must provide news & event date in MM/DD/YY format.',
					),
					
				),
				
				'start_time' =>
				array(
					'rule1' =>
					 array(
							'rule'    => 'notEmpty',
							'message'  => 'Please enter news & event start time.'
							),
					array(
						'rule' => array('time', 'H:M'),
							'message' => 'You must provide news & event start time in HH:MM format.',
					),
				   
				),
				'end_time' =>
				array(
					'rule1' =>
					 array(
							'rule'    => 'notEmpty',
							'message'  => 'Please enter news & event end time.'
							),
					array(
						'rule' => array('time', 'H:M'),
							'message' => 'You must provide news & event end time in HH:MM format.',
					),
					
				   
				),
			'feature_image' => array(
					
					'rule1'=>array(
							'rule' => array('chkImageExtension'),
							'message' => 'Please Upload Valid Image.'
						),
					/*'rule2'=>array(
							'rule' => array('check_size'),
							'message' => 'Only png, gif, jpg, jpeg images are allowed. Please upload 1000x500 dimension of image for better resolution.'
						),*/
				),
			'slug_url'=>array(
					'rule1'=>array(
									'rule' => 'is_valid_url',
									'message' => 'Please enter text in lower case without any space.'),
					'rule2'=>array(
									'rule' => 'check_slug_url',
									'message' => 'This slug url is already associated with other page or module.')
				)
			),
		'news_settings' =>array(
			'news_image' => array(
					
					'rule1'=>array(
							'rule' => array('validate_image'),
							'message' => 'Please Upload Valid Image.'
						),
					/*'rule2'=>array(
							'rule' => array('check_size'),
							'message' => 'Only png, gif, jpg, jpeg images are allowed. Please upload 1000x500 dimension of image for better resolution.'
						),*/
				)
		
		)
	);
	
	
    
	
	function validate_image(){
		if((!empty($this->data['NewsArticle']['id'])) && $this->data['NewsArticle']['feature_image']['name']=='') {
			return true;
		}else{
			if(!empty($this->data['NewsArticle']['feature_image']['name'])) {
				$file_part = explode('.',$this->data['NewsArticle']['feature_image']['name']);
				$ext = array_pop($file_part);		
				if(!in_array(strtolower($ext),array('gif', 'jpeg', 'png', 'jpg'))) {
					return false;
				}
			}
		return true;
		}
	}
	public function chkImageExtension($data) {
		if($data['feature_image']['name'] != ''){
				$fileData= pathinfo($data['feature_image']['name']);
				$ext=$fileData['extension'];
				$allowExtension=array('gif', 'jpeg', 'png', 'jpg','JPG');
				if(in_array($ext, $allowExtension)) {
					$return = true; 
				} else {
					$return = false;
				}
			} else{
			
				$return = true; 
			}
			return $return;
		}


	public function check_size(){
		if($this->data['NewsArticle']['feature_image']['tmp_name']=='') {
			return true;
		}else{
			if($this->data['NewsArticle']['feature_image']['error'] < 1){
				$imgSize = @getImageSize($this->data['NewsArticle']['feature_image']['tmp_name']);
				if(($imgSize[0]>=1000 ) && ($imgSize[1]>=500 ))
				{
					return true;
				}
			}
			return false;
		}
	}
	public function uploadFile( $check ) {
		$uploadData = array_shift($check);
		if ( $uploadData['size'] == 0 || $uploadData['error'] !== 0) {
			return false;
		}
		return true;
	}


	function check_slug_url(){
		if((!empty($this->data['NewsArticle']['id'])) && !empty($this->data['NewsArticle']['slug_url'])) {
			if($this->_check_uri_exist_on_other($this->data['NewsArticle']['slug_url'],'NewsArticle',$this->data['NewsArticle']['id'])){
				return false;
			}else{
				return true;
			}
		}
		return true;
	}
	function is_valid_url(){
		if((!empty($this->data['NewsArticle']['id'])) && !empty($this->data['NewsArticle']['slug_url'])) {
			return preg_match('|[a-z-.]+$|', $this->data['NewsArticle']['slug_url']);
		}
		return true;
	}
	
	

}
?>
