<?php
App::uses('Folder', 'Utility');
if(!file_exists(CACHE . 'news')) {
	mkdir(CACHE . 'news', 0777);
	$dir = new Folder();
	$dir->chmod(CACHE . 'news', 0777, true, array());	
}


$prefix = "news_";
$engine = "File";
$duration = '+999 days';
if (Configure::read('debug') > 0) {
	//$duration = '+10 seconds';
}
Cache::config('news_admin_elements', array(
	'engine' => $engine,
	'prefix' => $prefix, // not working in this version
	'path' => CACHE . 'news' . DS, //not working in this version
	'serialize' => ($engine === 'File'), 
	'duration' => $duration
));

?>
