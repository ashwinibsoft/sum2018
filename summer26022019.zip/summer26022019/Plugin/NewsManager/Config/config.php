<?php
$config = array();
$config['Name']['Plugin'] = "News Manager";
$config['Menu']['Left'] = array(
					array(
					'position'=>12,
					'icon'=>'fa fa-bars',
					'title'=>'News & Event Manager',
					'url'=>array('plugin'=>'news_manager','controller'=>'news_articles','action'=>'admin_index','admin'=>true),
					/*'sub_menus'=> array(
						array(
							'title'=>'Manage News Articles',
							'url'=>array('plugin'=>'news_manager','controller'=>'news_articles','action'=>'admin_index','admin'=>true),
							'right'=>array('title'=>'Add New News Article','url'=>array('plugin'=>'news_manager','controller'=>'news_articles','action'=>'admin_add','admin'=>true))
							),
						array(
							'title'=>'Manage Category',
							'url'=>array('plugin'=>'news_manager','controller'=>'n_categories','action'=>'admin_index','admin'=>true)
							),
						array(
							'title'=>'Manage Comments',
							'url'=>array('plugin'=>'news_manager','controller'=>'n_comments','action'=>'admin_index','admin'=>true)
							),	
						array(
							'title'=>'News Settings',
							'url'=>array('plugin'=>'news_manager','controller'=>'news_articles','action'=>'admin_settings','admin'=>true)
							)
						)*/
					)
				);
$config['Settings']['news_gallery']=false;
$config['Settings']['news_category']=false;
$config['Settings']['feature_image']=false;
$config['Settings']['news_seo']=true;
$config['Settings']['news_attribute']=true;


$config['Folder']['News'] = "news";
$config['Path']['News'] =  WWW_ROOT.'img'.DS.$config['Folder']['News'].DS;
$config['Folder']['NewsCategory'] = "newscategory";
$config['Path']['NewsCategory'] =  WWW_ROOT.'img'.DS.$config['Folder']['NewsCategory'].DS;
$config['Path']['Gallery'] =  WWW_ROOT.'img'.DS.'gallery'.DS;
$config['Folder']['Profile'] = "user";
$config['Path']['Profile'] =  WWW_ROOT.'img'.DS.$config['Folder']['Profile'].DS;
$config['Path']['NoImage'] =  WWW_ROOT.'img'.DS.'site'.DS.'noimage.jpg';
$config['Path']['NoProfile'] =  WWW_ROOT.'img'.DS.'site'.DS.'noprofile.jpg';
$config['Admin']['Limit'] = 20;
/***These below code is used  for admin purpose*/
$config['image_list_width'] = "140";
$config['image_list_height'] = "130";
$config['image_edit_width'] = "290";
$config['image_edit_height'] = "240";
$config['image_front_width'] = "220";
$config['image_front_height'] = "200";

$config['image_front_list_width'] = "211";
$config['image_front_list_height'] = "156";

$config['image_admin_edit_width'] = "80";
$config['image_admin_edit_height'] = "80";


$config['default_news_thumb_width'] = "625";
$config['default_news_thumb_height'] = "350";

/**Belowe code is used for front post image on front**/
$config['news_article_image_width']="1400";
$config['news_article_image_height']="550";
$config['image_crop_ratio']='4:3';

$config['default_newscategory_thumb_width'] = "625";
$config['default_newscategory_thumb_height'] = "350";

/**Belowe code is used for front post image on front**/
$config['newscategory_image_width']="1400";
$config['newscategory_image_height']="550";
$config['News']['templates'] = array(
'full_width' =>'Full Width',
'left_side_bar' =>'Left Side Bar',
'right_side_bar' => 'Right Side Bar'
);
$config['Section'] = array(
	'default_news_image'=>false,  //Default Post Image
	'gallery'=>false, /*Manage Gallery Drop down on pages add/edit form*/
	'tempalte_settings' =>true, //Special Page

);


?>
