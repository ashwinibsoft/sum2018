<?php
Class BlogCategoryLink extends BlogManagerAppModel {
	public $name = "BlogCategoryLink";
	
}
?>