<?php
Class BlogManagerAppModel extends AppModel {
}
?>