<?php
Class Comment extends BlogManagerAppModel {
	public $name = "Comment";
	
}
?>