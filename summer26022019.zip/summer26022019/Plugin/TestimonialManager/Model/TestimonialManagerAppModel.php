<?php
Class TestimonialManagerAppModel extends AppModel {
}
?>