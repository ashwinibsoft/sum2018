<?php
Class Testimonial extends TestimonialManagerAppModel {
	public $name = "Testimonial";
	
	public $validate = array(
	
	'author' =>
        array(
            'rule1' =>
            array(
                'rule' => array('maxLength', 255),
                'message' => 'Author name should be less than 255 charcter(s)'
            ),
            array(
                'rule' => 'notEmpty',
                'message' => 'Please enter author name'
            ) 
        ),
          'description' =>
        array(
            'rule1' =>
          
            array(
                'rule' => 'notEmpty',
                'message' => 'Please enter Description'
            ) 
        ),
        /*
        'created_at'=>
        array(
        'rule1'=>
		 array(
        
         'created_at' => 'CURRENT_TIMESTAMP'
			)
          ),
          */
    );
   
}
?>