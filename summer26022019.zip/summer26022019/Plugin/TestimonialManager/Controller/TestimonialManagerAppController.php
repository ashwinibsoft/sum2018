<?php

Class TestimonialManagerAppController extends AppController{
	
	
	}


?>