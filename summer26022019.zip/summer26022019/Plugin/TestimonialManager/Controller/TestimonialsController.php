<?php
	Class TestimonialsController extends TestimonialManagerAppController{
		public $uses = array('TestimonialManager.Testimonial');
		public $paginate = array();
		public $id = null;
		
		function admin_index($search=null){
			$this->paginate = array();
			$condition = null;
			$this->paginate['limit']=20;
			if($this->request->is('post')){
				$this->redirect(array('plugin'=>'testimonial_manager','controller'=>'testimonials','action'=>'index' ,$this->request->data['search']));
			}
			$this->paginate['order']=array('Testimonial.ordering'=>'ASC','.id'=>'DESC');		
			
			if($search!=null){
				$search = urldecode($search);
				$condition['Testimonial.author like'] = '%'.$search.'%';
			}
			
			$testimonials=$this->paginate("Testimonial", $condition);	
		   // echo "<pre>";print_r($pages);die;
			
			$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/home'),
				'name'=>'Dashboard'
			);
			$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/testimonial_manager/testimonials'),
				'name'=>'Manage Testimonial'
			);
			$this->heading =  array("Manage","Testimonial");
			$this->set('testimonials',$testimonials);
			$this->set('search',$search);
			$this->set('url','/'.$this->params->url);
			if($this->request->is('ajax')){
				$this->layout = '';
				$this -> Render('ajax_admin_index');
			   
			}
				   
		}
			
			
		function ajax_sort(){
			$this->autoRender = false;
			foreach($_POST['sort'] as $order => $id){
				$testimonial= array();
				$testimonial['Testimonial']['id'] = $id;
				$testimonial['Testimonial']['ordering'] = $order;
				$this->Testimonial->create();
				$this->Testimonial->save($testimonial);
			}
		   
		}
		   
			 
		function admin_add($id=null){
			
			$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/home'),
			'name'=>'Dashboard');
			$this->breadcrumbs[] = array(
					'url'=>Router::url('/admin/testimonial_manager/testimonials'),
					'name'=>'Manage Testimonial'
			);
			$this->breadcrumbs[] = array(
					'url'=>Router::url('/admin/testimonial_manager/testimonials/add'),
					'name'=>($id==null)?'Add Testimonial':'Update Testimonial'
			);
			if($id==null){
			$this->heading =  array("Add","Testimonial");
		}else{
			$this->heading =  array("Update","Testimonial");
		}
			
			if(!empty($this->request->data)){
				 
				 if(!$id){
				$this->request->data['Testimonial']['created_at']=date('Y-m-d H:i:s');
				}else{
				$this->request->data['Testimonial']['updated_at']=date('Y-m-d H:i:s');
				}	
				
				$this->Testimonial->create();
				$dt=date("Y-m-d H:i:s");
				$this->Testimonial->save($this->request->data);
				if ($this->request->data['Testimonial']['id']) {
					$this->Session->setFlash(__('Testimonial has been updated successfully'));
					} 
					else {
						$this->Session->setFlash(__('Testimonial has been added successfully'));
					}
				if(isset($this->request->data['save']) && $this->request->data['save']=='Save'){
					$this->redirect(array('plugin'=>'testimonial_manager','controller' => 'testimonials', 'action' => 'admin_add',$id));
			
				}else{
					$this->redirect(array('controller'=>'testimonials','action'=>'admin_index'));
				}
				
			}
			else{
				if($id!=null){
					$this->request->data = $this->Testimonial->read(null,$id);
				}else{
					$this->request->data = array();
				}
			}
			
			
			
			$this->set('url',Controller::referer());
		}
			
		function admin_delete($id=null){
			$this->autoRender = false;
		    //print_r($this->request->data);
			$data=$this->request->data['Testimonial']['id'];
			$action = $this->request->data['Testimonial']['action'];
			$ans="0";
			foreach($data as $value){
				if($value!='0'){
					if($action=='Publish'){
						$testimonial['Testimonial']['id'] = $value;
						$testimonial['Testimonial']['status']=1;
						$this->Testimonial->create();
						$this->Testimonial->save($testimonial);
						$ans="1";
					}
					if($action=='Unpublish'){
						$testimonial['Testimonial']['id'] = $value;
						$testimonial['Testimonial']['status']=0;
						$this->Testimonial->create();
						$this->Testimonial->save($testimonial);
						$ans="1";
					}
					if($action=='Delete'){
						$this->Testimonial->delete($value);
						$ans="2";
					}
				}
			}
		if($ans=="1"){
			$this->Session->setFlash(__('Testimonial has been '.$this->data['Testimonial']['action'].'ed successfully', true));
		}
		else if($ans=="2"){
			$this->Session->setFlash(__('Testimonial has been '.$this->data['Testimonial']['action'].'d successfully', true));
		}else{
			$this->Session->setFlash(__('Please Select any Testimonial', true),'default','','error');
		}
		$this->redirect($this->request->data['Testimonial']['redirect']);
				 
	}
		
		
		
		function validation(){
			  $this->autoRender = false;
			 
			  $this->Testimonial->set($this->request->data);
			  $result = array();
			  if ($this->Testimonial->validates()) {
				  $result['error'] = 0;
			  }else{
				  $result['error'] = 1;
			  }
			  $result['errors'] = $this->Testimonial->validationErrors;
			  $errors = array();
			 
			  foreach($result['errors'] as $field => $data){
				  $errors['Testimonial'.Inflector::camelize($field)] = array_pop($data);
			  }
			 
			 $result['errors'] = $errors;
			 
			 if($this->request->is('ajax')) {
				  echo json_encode($result);
				  //<span class="error-message">Inserisci il nome del proprietario</span>
				  return;
			  } 
			  
			  
		  }
		
		function admin_view($id = null) {
		$this->layout = '';
		 
		$criteria = array();
			$criteria['conditions'] = array('Testimonial.id'=>$id);
			$parent_testimonial =  $this->Testimonial->find('first', $criteria);
			$this->set('testimonial', $parent_testimonial);
			 
		  
	  }
		function home_testimonial(){
			//$this->autoRender = false;
			$testimonials = $this->Testimonial->find('all',array('conditions'=>array('Testimonial.status'=>1),'order'=>array('RAND()','Testimonial.ordering'=>'ASC','Testimonial.id'=>'DESC'),'limit'=>10));
			 //return $testimonials;
			$this->set('testimonials', $testimonials);
		}
		function index(){
			$testimonial = $this->Testimonial->find('all',array('conditions'=>array('Testimonial.status'=>1),'order'=>array('Testimonial.ordering'=>'ASC','Testimonial.id'=>'DESC')));
			$this->set('testimonial', $testimonial);
		}
	  
	}


	?>