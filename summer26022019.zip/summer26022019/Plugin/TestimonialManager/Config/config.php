<?php
$config = array();
$config['Name']['Plugin'] = "Testimonial Manager"; 
$config['Menu']['Left'] = array(
					array(
					'position'=>6,
					'icon'=>'fa-envelope-o',
					'title'=>'Testimonial Manager',
					'url'=>Router::url('/admin/testimonial_manager/testimonials/index')
					)
				);
?>
