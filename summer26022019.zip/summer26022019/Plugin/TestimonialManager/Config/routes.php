<?php
Router::connect('/testimonials', array('plugin'=>'testimonial_manager','controller' => 'testimonials', 'action' => 'index'));
