<?php 
$config = array();
$config['Name']['Plugin'] = "User Manager";
$config['Request']['Dashboard'] = array(
								'position'=>4,
								'title'=>'Sub Admin',
								'url'=>array('plugin'=>'user_manager','controller'=>'users','action'=>'admin_dashboard','admin'=>true)
								);
$config['Menu']['Left'] = array(
					array(
					'position'=>3,
					'icon'=>'fa-user',
					'title'=>'User Manager',
					'url'=>array('plugin'=>'user_manager','controller'=>'users','action'=>'admin_index','admin'=>true),
					'sub_menus'=> array(
							array(
								'title'=>'Manage User',
								'url'=>array('plugin'=>'user_manager','controller'=>'users','action'=>'admin_index','admin'=>true)
							),
							array(
								'title'=>'Manage User Groups',
								'url'=>array('plugin'=>'user_manager','controller'=>'user_groups','action'=>'admin_index','admin'=>true)
							)
						)
					)
				);
$config['Dashboard'] = array(
						array(
						'position'=>2,
						'title'=>'Admin User',
						'url'=>array('plugin'=>'user_manager','controller'=>'users','action'=>'admin_dasboard'),
						'return'=>true
					)
				);
?>
