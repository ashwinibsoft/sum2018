<?php
Class UserManagerAppModel extends AppModel {
}
?>