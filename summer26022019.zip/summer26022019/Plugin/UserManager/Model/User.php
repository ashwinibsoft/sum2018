<?php
App::uses('AuthComponent', 'Controller/Component');
class User extends UserManagerAppModel {
	public $name = "User";
	public $belongsTo = array(
		'UserGroups'=>array(
				'className'=>'UserGroups',
				'foreignKey'=>'user_group_id'
				)
		);
	var $actsAs = array('Multivalidatable');
	public $validate = array();
	var $validationSets=array(
							'ResetPassword'=>array(
								'email' =>	
									array(
										'rule1' =>
											array(
												 'rule' => 'notEmpty',
												'message' => 'Please enter email address here.'
											),
											array(
												'rule' => array('email', true),
												'message' => 'Please enter email address in a correct form.'
											),
											array(
												'rule' => array('checkEmail'),
												'message' => 'This email does not exist in our database.'
											)
											 
									)
							),
							'AdminLogin'=>array(
								'username' =>	
									array(
										'rule1' =>
											array(
												 'rule' => 'notEmpty',
												'message' => 'Please enter username.'
											)
								),
								'password' =>	
									array(
										'rule1' =>
											array(
												 'rule' => 'notEmpty',
												'message' => 'Please enter password.'
											)
									),
								'captcha'=>array(
										'rule1' =>
											array(
												 'rule' => 'notEmpty',
												'message' => 'Please enter security code.'
											),
										'rule2' =>
											array(
												 'rule' => 'matchCaptcha',
												'message' => 'Entered security does not match.'
											),	
									
									),
							),
							'NewUserForm'=>array(
									'name' => array(
										'notEmpty' => array(
											'rule' => array('notEmpty'),
											'message' => 'Please enter first name.'
										)
									),
									
								'lname' => array(
										'notEmpty' => array(
											'rule' => array('notEmpty'),
											'message' => 'Please enter last name.'
										)
									),
									'user_group_id' => array(
										'notEmpty' => array(
											'rule' => array('notEmpty'),
											'message' => 'Please enter user group.'
										)
									),
									'email' => array(
											'notEmpty'=>array(
											'rule' =>array('notEmpty'),
											'message'=> 'Please enter email address.'
											),
											'isUnique'=>array(
											'rule'=>array('isUnique'),
											'message'=>'This email has already been registered.'
										), 
									'email'=>array(
										'rule' =>array('email'),
										'message'=> 'Please enter valid email address.'
											)
										),
									'username' => array(
										'notEmpty' => array(
											'rule' => array('notEmpty'),
											'message' => 'Please enter username.'
										),
									'isUnique'=>array(
										'rule'=>array('isUnique'),
										'message'=>'This username has already been registered.'
										)
									),
							),
							'ResetRegistrationPasswordForm'=>array(
								'password'=>  array( 
										array( 
											'rule' =>'notEmpty', 
											'message'=> 'Please enter password.'
											),
											array(
											'rule'    => array('minLength', 5),
											'message' => 'Password should be at least 6 digit long.'
											)
											 
										),
									'password2'=>array( 
										array( 
											'rule' =>'notEmpty', 
											'message'=> 'Confirm your password here.'
											 ),
										array(
											'rule' => 'checkpassword',
											//'required' => true,
											'message' => 'Your password and confirm password does not match.'
											//'on'=>'create'
										)
									)
							),
							'PasswordChangeAdmin'=>array(
								'oldpassword'=>  array( 
										array( 
											'rule' =>'notEmpty', 
											'message'=> 'Please enter old password.'
											),
										array(
											'rule' => 'checkcurrentpasswords',
											'message' => 'Current password is invalid.'
											)	
											
										),
										
								'password'=>array( 
									array( 
										'rule' =>'notEmpty', 
										'message'=> 'Please enter new password.'
										 ),
									array(
										'rule'    => array('minLength', 5),
										'message' => 'Password should be at least 5 digit long.'
										)
								),
								'password2'=>array( 
										array( 
											'rule' =>'notEmpty', 
											'message'=> 'Confirm your password here.'
											 ),
										array(
											'rule' => 'checkpassword',
											//'required' => true,
											'message' => 'Your new password and confirm password does not match.'
											//'on'=>'create'
										)
									)
								
							),
							'UserProfileUpdate'=>array(
								'name'=>  array( 
										array( 
											'rule' =>'notEmpty', 
											'message'=> 'Please enter name.'
											),
										array(
											'rule' => '/^[A-Za-z ]*$/',
											'message' => 'Please enter name in alphabet.'
											)	
										),
								/*'lname'=>array( 
									array( 
										'rule' =>'notEmpty', 
										'message'=> 'Please enter last name.'
										 ),
									 array(
										'rule' => '/^[A-Za-z ]*$/',
										'message' => 'Please enter last name in alphabet.'
									)
								),*/
								'email' => array(
											'notEmpty'=>array(
											'rule' =>array('notEmpty'),
											'message'=> 'Please enter user\'s email address.'
											),
											'isUnique'=>array(
											'rule'=>array('isUnique'),
											'message'=>'This email has already been registered.'
										), 
									'email'=>array(
										'rule' =>array('email'),
										'message'=> 'Please enter valid email address.'
											)
										),
								'image'=>array(
									'image_format'=>array(
										'rule'=>array('validate_image'),
										'message'=>'Pleaser upload valid image.'
										)
									)
								
								
							),
	);
	
	function checkpassword()     // to check pasword and confirm password
	{  
		if(strcmp($this->data['User']['password'],$this->data['User']['password2']) == 0 ) 
		{
		    return true;
		}
        return false; 
	}
	

	
	function checkcurrentpasswords()// to check current password 
	{
		$data = CakeSession::read('Auth');
		$this->id = $data['User']['id'];
		$password = $this->field('password');
		if($password == Security::hash(Configure::read('Security.salt').$this->data['User']['oldpassword'])) {
			return true;
		}
		return false;
	}
	
	function checkEmail(){
		return $this->find('count',array('conditions'=>array('email'=>$this->data['User']['email'])));
	}
	
	public function beforeSave($options = array()) {
		if (isset($this->data[$this->alias]['password'])) {
			$this->data[$this->alias]['password'] = AuthComponent::password($this->data[$this->alias]['password']);
		}
		return true;
	}
	function validate_image(){
		if(!empty($this->data['User']['image']['name']) && $this->data['User']['image']['error'] < 1 ) {
			$file_part = explode('.',$this->data['User']['image']['name']);
			$ext = array_pop($file_part);		
			if(!in_array(strtolower($ext),array('gif', 'jpeg', 'png', 'jpg'))) {
				
				return false;
			}
		}else{
			if(!empty($this->data['User']['image']['name']) && $this->data['User']['image']['error'] > 0){
				return false;
			}
			
		}
		
		
		
		return true;
	}
    
}




?>