<?php
Class UserGroups extends UserManagerAppModel {
    public $name = "UserGroups";
    public $validate = array(
		'name' =>
        array(
            'rule1' =>
            array(
                'rule' => array('maxLength', 25),
                'message' => 'User group name should be less than 25 charcter(s).'
            ),
            array(
                'rule' => 'notEmpty',
                'message' => 'Please enter user group name.'
            ) 
        )

	);
	
    
}
?>