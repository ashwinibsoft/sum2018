<?php
Class UserManagerAppController extends AppController{
	//var $components = array('Email','UserManager.UserLib');
	var $uses = array('UserManager.UserGroups','User');
}
?>