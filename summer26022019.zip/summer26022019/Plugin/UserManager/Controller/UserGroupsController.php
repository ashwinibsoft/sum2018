<?php
// app/Controller/UsersController.php
class UserGroupsController extends UserManagerAppController {
	public $uses = array('UserManager.UserGroups');
	public $paginate = array();
	function admin_index($search=null,$limit=10){
		$condition=null;
		$this->paginate = array();
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/home'),
			'name'=>'Dashboard'
			);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/user_manager/user_groups'),
				'name'=>'Manage User Groups'
		);
		$this->heading =  array("Manage","User Groups");
		
		$search_keyword=array();
		
		//if($keyword!=null){
			//$this->data['User']['keyword']=$keyword;
		//}
		if($search=="_blank"){
			$search=null;
		}
		
		$this->paginate['limit']=$limit;
		
		if($this->request->is('post')){
			//print_r($this->request->data);die;
			
			if(!empty($this->request->data['search'])){
				$search = $this->request->data['search'];
			}else{
				$search = '_blank';
			}
			if(!empty($this->request->data['limit'])){
				$limit = $this->request->data['limit'];
			}else{
				$limit = '10';
			}
			$this->redirect(array('plugin'=>'user_manager','controller'=>'user_groups','action'=>'index',$search,$limit));
		}
		if($search!=null){
			$search = urldecode($search);
			$condition['UserGroups.name like'] = '%'.$search.'%';
		}
		$condition['NOT']['UserGroups.id'] = array('1',$this->Auth->user('user_group_id')); 
		$this->paginate['order']=array('UserGroups.id'=>'DESC');
		
		
		$subQuery = '(SELECT COUNT(*) FROM  `users` AS `User` WHERE `User`.`user_group_id` = `UserGroups`.`id`) as total_users';
		$this->paginate['fields'] = array('UserGroups.id','UserGroups.name',$subQuery,'UserGroups.status');
		//$this->set('usergroup',$usergroup);
		$this->set('limit',$limit);
		$this->set('search',$search);
		$this->set('search_keyword',$search_keyword);
		$this->set('user_groups', $this->paginate("UserGroups",$condition));
	}
	
	function validation(){
		
		//$this->UserGroups->setValidation('AddForm');
		$this->UserGroups->set($this->request->data);
		$result = array();
		if ($this->UserGroups->validates()) {
			$result['error'] = 0;
		}else{
			$result['error'] = 1;
			$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
		}
		if($this->request->is('ajax')) {
			$this->autoRender = false;
			$result['errors'] = $this->UserGroups->validationErrors;
			$errors = array();
			 
			foreach($result['errors'] as $field => $data){
				$errors['UserGroups'.Inflector::camelize($field)] = array_pop($data);
			}
			$result['errors'] = $errors;
			$view = new View();
			$result['error_message'] = $view->element('admin/message');
			echo json_encode($result);
			return;
		  }
		  
		  return (int)($result['error'])?0:1;
	} 
	 
	function admin_add($id=null){
		//$this->layout="";
		
		self::__manageuser($id);
	}
	private function __manageuser($id=null){
		
		$this->breadcrumbs[] = array(
		'url'=>Router::url('/admin/home'),
		'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/user_manager/user_groups'),
				'name'=>'Manage User Group'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/user_manager/user_group/add'),
				'name'=>($id==null)?'Add User Group':'Update User Group'
		);
		
		if($id==null){
			$this->heading =  array("Add","User Group");
		}else{
			$this->heading =  array("Update","User Group");
		}
		if(!empty($id)){
			$mod_view=$this->UserGroups->read(null,$id);
			$mod_view2= json_decode($mod_view['UserGroups']['permissions'],true);
			$this->set('mod_view_data',$mod_view2);
		}
		
		if(!empty($this->request->data) && $this->validation()){
			
			if(!empty($this->request->data['UserGroups']['Permission'])){
			
			
			/*foreach ($this->request->data['UserGroups']['Permission'] as $key => $all_data) {
				if ($all_data == '1') {
					$this->request->data['UserGroups']['access'][]=$key;
				}
				if($all_data == '2'){
					$this->request->data['UserGroups']['modify'][]=$key;
				}
				if($all_data == '0'){
					$this->request->data['UserGroups']['none'][]=$key;
				}
			  } 
			}
			
			if(!empty($this->request->data['UserGroups']['access'])){
				$this->request->data['UserGroups']['permissions']['access'] = $this->request->data['UserGroups']['access'];
			}
			if(!empty($this->request->data['UserGroups']['modify'])){
				$this->request->data['UserGroups']['permissions']['modify'] = $this->request->data['UserGroups']['modify'];
			}
			if(!empty($this->request->data['UserGroups']['none'])){
				$this->request->data['UserGroups']['permissions']['none'] = $this->request->data['UserGroups']['none'];
			}*/
			$this->request->data['UserGroups']['permissions']=$this->request->data['UserGroups']['Permission'];
		}
			if(!empty($this->request->data['UserGroups']['permissions'])){
				
				$this->request->data['UserGroups']['permissions'] = json_encode($this->request->data['UserGroups']['permissions']);
				//print_r($this->request->data['UserGroups']['permissions']);die;
				
			}else{
				$this->request->data['UserGroups']['permissions']='NULL';
			}
			if(empty($this->request->data['UserGroups']['id'])){
				$this->request->data['UserGroups']['status'] = 1;
				$this->request->data['UserGroups']['created_at'] = date("Y-m-d H:i:s");
				$this->Session->setFlash(__('User Group has been added successfully'));
			}else{
				$this->request->data['UserGroups']['updated_at'] = date("Y-m-d H:i:s");
				$this->Session->setFlash(__('User Group has been updated successfully'));
			}
			$this->UserGroups->create();
			$this->UserGroups->save($this->request->data);
			$id = $this->UserGroups->id;
			if(isset($this->request->data['save']) && $this->request->data['save']=='Save'){
				$this->redirect(array('controller' => 'user_groups', 'action' => 'admin_add',$id,'?'=>array('back'=>$this->request->data['UserGroups']['url_back_redirect'])));
			
			}else{
					$this->redirect(array('controller'=>'user_groups','action'=>'admin_index'));
			}
		}
		/*if(!empty($this->request->data)){
			//print_r($this->request->data);die;
			$this->request->data['UserGroups']['permissions']['access'] = $this->request->data['UserGroups']['access'];
			$this->request->data['UserGroups']['permissions']['modify'] = $this->request->data['UserGroups']['modify'];
			$this->request->data['UserGroups']['permissions'] = json_encode($this->request->data['UserGroups']['permissions']);
			if(empty($this->request->data['UserGroups']['id'])){
				$this->request->data['UserGroups']['status'] = 1;
				$this->request->data['UserGroups']['created_at'] = date("Y-m-d H:i:s");
				$this->Session->setFlash(__('User Group has been added successfully'));
			}else{
				$this->request->data['UserGroups']['updated_at'] = date("Y-m-d H:i:s");
				$this->Session->setFlash(__('User Group has been updated successfully'));
			}
			$this->UserGroups->create();
			$this->UserGroups->save($this->request->data);
			if(isset($this->request->data['save']) && $this->request->data['save']=='Save'){
				$this->redirect(array('controller' => 'user_groups', 'action' => 'admin_add',$id));
			
			}else{
					$this->redirect(array('controller'=>'user_groups','action'=>'admin_index'));
			}
		}*/
		
		if(!empty($id)){
			$this->request->data = $this->UserGroups->read(null,$id);
			$this->request->data['UserGroups']['permissions'] = json_decode($this->request->data['UserGroups']['permissions'],true);
			if(!empty($this->request->data['UserGroups']['permissions']['access'])){
			$this->request->data['UserGroups']['access'] = $this->request->data['UserGroups']['permissions']['access'];
		}
		if(!empty($this->request->data['UserGroups']['permissions']['modify'])){
			$this->request->data['UserGroups']['modify'] = $this->request->data['UserGroups']['permissions']['modify'];
		}
		}
		
		$referer_url = $this->request->query('back');
		if(!empty($referer_url)){
			$referer_url= $this->request->query('back');
		}else{
			$referer_url=(Controller::referer()=="/")? Router::url('/admin/users_manager/user_groups',true) :Controller::referer();
		}
		
		
		$this->set('referer_url',$referer_url);
		$this->set('modules',$this->UserLib->get_plugins());
	}
	
	
	
	function admin_delete($id=null){
		
		$data=$this->request->data['UserGroups']['id'];
		//array_splice($data,0,2); 
		
		$ans="0";
		foreach($data as $value)
		{	
			if($value!='0'){
			
				$user_groups=$this->UserGroups->read(null,$value);

				if($this->data['UserGroups']['action']=='Publish'){
					$user_groups['UserGroups']['status']=1;
					if(!empty($user_groups['UserGroups']['id'])){
						$this->UserGroups->create();
						$this->UserGroups->save($user_groups,array('validate'=>false));
					}
					$ans="1";
				}
				if($this->data['UserGroups']['action']=='Unpublish'){
					$user_groups['UserGroups']['status']=0;
					if(!empty($user_groups['UserGroups']['id']))
					{
						$this->UserGroups->create();
						$this->UserGroups->save($user_groups,array('validate'=>false));
					}
				        $ans="1";
				}
				
				
				if($this->data['UserGroups']['action']=='Delete')
				{
					$this->UserGroups->delete($value);
					$ans="2";
				}
				
			}
		}
		
		switch($ans)
		{	
		case 1:
		$this->Session->setFlash(__('User Group(s) has been '.$this->data['UserGroups']['action'].'ed successfully', true));
		break;
	        
		case 2:
		$this->Session->setFlash(__('User Group(s) has been '.$this->data['UserGroups']['action'].'d successfully', true));
		break;
		
		default:
		$this->Session->setFlash(__('User Group(s) Select any user', true),'default','','error');
			
		}
		$this->redirect(array('action'=>'index'));		
	}
	
}
?>