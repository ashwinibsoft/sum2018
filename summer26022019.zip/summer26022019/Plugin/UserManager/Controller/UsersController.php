<?php
// app/Controller/UsersController.php
class UsersController extends UserManagerAppController {
	public $paginate = array();

	function admin_index($keyword=null){
		
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/home'),
			'name'=>'Dashboard'
			);
			$this->breadcrumbs[] = array(
					'url'=>Router::url('/admin/user_manager/users'),
					'name'=>'Manage User'
			);
		$this->paginate['limit']=10;
		$this->heading =  array("Manage","User");
		
		if($this->request->is('post')){
			$this->redirect(array('plugin'=>'user_manager','controller'=>'users','action'=>'index' ,$this->request->data['search']));
		}
		
		
		$search_keyword=array();
		$condition=null;
		$condition['User.id <>'] = $this->Auth->user('id');
		$condition['NOT']['User.id'] = array(1); 

		if(!empty($keyword) and $keyword!='Name,Username or Email')
		{			
			$condition['OR']['User.username like']= '%'.$keyword.'%';
			$condition['OR']['User.email like']= '%'.$keyword.'%';
			$condition['OR']['User.name like']= '%'.$keyword.'%';
			$condition['OR']['User.lname like']= '%'.$keyword.'%';
			$search_keyword=array('url'=>array($keyword));
		}
		$this->User->recursive = 2;
		
		$this->paginate['order']=array('User.created'=>'DESC');
		$this->paginate['fields'] = array('User.id','User.username','CONCAT(User.name, \' \', User.lname) as full_name','User.user_group','User.status','User.email');
		$this->User->virtualFields['user_group'] = "(Select `UserGroups`.`name` From `user_groups` as `UserGroups` where `UserGroups`.`id`=`User`.`user_group_id`)";

		$this->set('search_keyword',$search_keyword);
		$this->set('search',$keyword);
		$users=$this->paginate("User",$condition);
		$this->set('users', $users);
		$this->set('manager', "User");
	}
	function validation($action=null){
		//echo"<pre>";print_r($this->request->data);die;
		
		if($this->request->data['User']['form-name']=='ResetPasswordForm')
		{
			$this->User->setValidation('ResetPassword');
		}
		if($this->request->data['User']['form-name']=='AdminLogin')
		{
			$this->User->setValidation('AdminLogin');
		}
		if($this->request->data['User']['form-name']=='NewUserForm')
		{
			$this->User->setValidation('NewUserForm');
		}
		if($this->request->data['User']['form-name']=='ResetRegistrationPasswordForm')
		{
			$this->User->setValidation('ResetRegistrationPasswordForm');
		}
		if($this->request->data['User']['form-name']=='PasswordChangeAdmin')
		{
			$this->User->setValidation('PasswordChangeAdmin');
		}
		if($this->request->data['User']['form-name']=='UserProfileUpdate')
		{
			$this->User->setValidation('UserProfileUpdate');
		}
			$this->User->set($this->request->data);
			$result = array();
			if ($this->User->validates()) {
				$result['error'] = 0;
			}else{
				$result['error'] = 1;
				$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
			}
			if($this->request->is('ajax')) {
				$this->autoRender = false;
				$result['errors'] = $this->User->validationErrors;
		  
				$errors = array();
			 
				foreach($result['errors'] as $field => $data){
					$errors['User'.Inflector::camelize($field)] = array_pop($data);
				}
			 
				$result['errors'] = $errors;
				$view = new View();
				$result['error_message'] = $view->element('admin/message');
			 
				echo json_encode($result);
				return;
			}
		  
			return (int)($result['error'])?0:1;
		 
	 } 
	function admin_add($id=null){
		self::__manageuser($id);
	}
	private function __manageuser($id=null){
			$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/home'),
			'name'=>'Dashboard'
			);
            $this->breadcrumbs[] = array(
                    'url'=>Router::url('/admin/user_manager/users'),
                    'name'=>'Manage User'
            );
            $this->breadcrumbs[] = array(
                    'url'=>Router::url('/admin/user_manager/users/add'),
                    'name'=>($id==null)?'Add User':'Update User'
            );	
			if($id==null){
				$this->heading =  array("Add","User");
			}else{
				$this->heading =  array("Update","User");
			}
		if(!empty($this->request->data) && $this->validation()){
			if($this->request->data['User']['id']==''){
				$this->request->data['User']['passwordurl'] = md5($this->_randomString());
				$this->request->data['User']['role'] = 'subadmin';
				$this->request->data['User']['status'] = 1;
				
				$modules = array();
				if ($handle = opendir(realpath(dirname(__FILE__)))) {
					 while (false !== ($entry = readdir($handle))) {
						if ($entry != "." && $entry != ".." && $entry!="AppController.php" && $entry!="UsersController.php" && $entry !="Component") {
							$modules[trim($entry,".php")] = "0";
						}
					 }
					 closedir($handle);
				}
			
				if($this->request->data['User']['id']==''){
					$this->request->data['User']['created'] = date('Y-m-d H:i:s');
				}
				else{
					$this->request->data['User']['modified'] = date('Y-m-d H:i:s');
				}
				$this->request->data['User']['permission'] = json_encode($modules);
			}
			$this->User->create();
			$this->User->save($this->request->data,array('validate'=>false));
			$id = $this->User->id;
			if(empty($this->request->data['User']['id'])){
				//$this->__send_mail(5,$this->request->data);//Send mail to New Subadmin
				
				$options = array();
				$options['replacement'] = array('{NAME}'=>$this->request->data['User']['name'].' '.$this->request->data['User']['lname'],'{USERNAME}'=>$this->request->data['User']['username'],'{url}'=>Router::url(array('admin'=>false,'plugin'=>false,'controller'=>'admin','action'=>'passwordurl',$this->request->data['User']['passwordurl']),true));
				$options['to'] = array($this->request->data['User']['email']); //mixed
				//$options['emailFormat'] = "html";
				
				//$options['viewVars'] = array('data'=>'This is test');
				//$options['message'] = "This is message";
				$this->MyMail->SendMail(5,$options);
				
				
				
				
				$this->Session->setFlash('Sub Admin has been added successfully');
			}else{
				$this->Session->setFlash('Sub Admin has been updated successfully');
			}
			
			$this->redirect(array('controller' => 'users', 'action' => 'admin_add',$id,'?'=>array('back'=>$this->request->data['User']['url_back_redirect'])));
		}
		
		if(empty($this->request->data) && $id!=null){
			$this->request->data = $this->User->read(NULL,$id);
		}
		
		$referer_url = $this->request->query('back');
		if(!empty($referer_url)){
			$referer_url= $this->request->query('back');
		}else{
			$referer_url=(Controller::referer()=="/")? Router::url('/admin/user_manager/users/'.$id,true) :Controller::referer();
		
		}
		$this->set('referer_url',$referer_url);
		
		//$this->set('user_groups',$this->UserGroups->find('list',array('fields'=>array('id','name'),'conditions'=>array('status'=>1,'id <>' => 1),'order'=>array('name'=>'ASC'))));
		$this->set('user_groups',$this->UserGroups->find('list',array('fields'=>array('id','name'),'conditions'=>array('status'=>1,'id !=' => array(1,2)),'order'=>array('name'=>'ASC'))));
	}
	function admin_view($id=null){
		$this->layout='';
		$user = $this->User->read(null,$id);
		$this->set('user',$user);
	}
	function admin_permission($id=null){ 
		$this->breadcrumbs[] = array(
		'url'=>Router::url('/admin/home'),
		'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/user_manager/users'),
				'name'=>'Manage User'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/user_manager/users/add'),
				'name'=>'Manage Permission'
		);	
            
		$modules = array();
		$file=array('PagesController','SlidesController');
		foreach($file as $files){
			$modules[] = array('file'=>$files,'name'=>str_replace('Controller',' Manager',$files));
		}

		if(!empty($this->data)){
			$user['User']['id'] = $this->data['User']['user_id'];
		
			if(isset($this->data['content'])){
				$user['User']['permission'] = json_encode($this->data['content']);
			}else{
				$user['User']['permission'] = json_encode(array());
			}
			$this->User->create();
			if($this->User->save($user))
			{
				$this->Session->setFlash('Permission has been saved successfully');
				$this->redirect(array('plugin'=>'user_manager','controller'=>'users', 'action' => 'index'));
			}
		}
	
		$user = $this->User->read(null,$id);
		$this->request->data['content'] = json_decode($user['User']['permission'],true);
		$this->set('user_id',$id);
		$this->set('user_name',$user['User']['name'].' '.$user['User']['lname']);
		$this->set('modules',$modules);
    }
	private function __send_mail($mail_id=null,$user=null){
		$this->loadModel('MailManager.Mail');
		$mail=$this->Mail->read(null,$mail_id);
		$linkmerge=Configure::read('Site.url').'admin/passwordurl/'.$user['User']['passwordurl'];
		$body=str_replace('{NAME}',$user['User']['name'],$mail['Mail']['mail_body']);
		$body=str_replace('{USERNAME}',$user['User']['username'],$body);
		$body=str_replace('{url}',$linkmerge,$body);
		$email = new CakeEmail();
		$email->to(trim($user['User']['email']));
		$email->subject($mail['Mail']['mail_subject']);
		
		$email->from(trim($this->System->get_setting('site','site_contact_email')),trim($mail['Mail']['mail_from']));
		$email->emailFormat('html');
		$email->template('default');
		$email->viewVars(array('data'=>$body,'logo'=>Configure::read('Site.admin_logo'),'url'=>Configure::read('Site.url')));
		$email->send();
    }
	function ajax_sort(){
		$this->autoRender = false;
		foreach($_POST['sort'] as $order => $id){
			$user= array();
			$user['User']['id'] = $id;
			$user['User']['reorder'] = $order;
			$this->User->create();
			$this->User->save($user);
		}
	   
	}
	function admin_delete(){
		
		$ans="0";
		$data=$this->data['User']['id'];
		//array_splice($data,0,2); 
		foreach($data as $value)
		{
			if($value!='0')
			{
			
				if($this->data['User']['action']=='Publish')
				{
					$users=$this->User->read(null,$value);

					$users['User']['status']=1;
					
					if(!empty($users['User']['id']))
					{
					$this->User->updateAll(array('User.status' => 1),array('User.id' => $users['User']['id']));
					//$this->User->create();
					//$this->User->save($users);
					}
					$ans="1";
				}
				if($this->data['User']['action']=='Unpublish')
				{
					
					$users=$this->User->read(null,$value);
					
					$users['User']['status']=0;
					if(!empty($users['User']['id']))
					{
						//echo "<pre>";print_r($users);die;
						$this->User->updateAll(array('User.status' => 0),array('User.id' => $users['User']['id']));
						//$this->User->create();
						//$this->User->save($users,array('validate'=>false));
					}
				        $ans="1";
				}
				
				
				if($this->data['User']['action']=='Delete')
				{
					$this->User->delete($value);
					$ans="2";
				}
				
			}
		}
		
		switch($ans)
		{	
		case 1:
		$this->Session->setFlash(__('User has been '.$this->data['User']['action'].'ed successfully', true));
		break;
	        
		case 2:
		$this->Session->setFlash(__('User has been '.$this->data['User']['action'].'d successfully', true));
		break;
		
		default:
		$this->Session->setFlash(__('User Select any user', true),'default','','error');
			
		}
		$this->redirect(array('action'=>'index'));		
	}
	function RandomString(){
		$characters = '0123456789abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$randstring = '';
		for ($i = 0; $i < 10; $i++) {
			$randstring .= $characters[rand(0, strlen($characters))];
		}
		return $randstring;
	}
	
	public function admin_dashboard(){
		$home_user=$this->User->find('all',array('conditions'=>array('NOT'=>array('User.id'=>array(1,$this->Auth->user('id')))),'limit'=>5,'order'=>array('User.id'=>'desc')));
		$this->set('users',$home_user);
	}


}

?>