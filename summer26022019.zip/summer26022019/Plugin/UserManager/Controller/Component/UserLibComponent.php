<?php
// app/Controller/UsersController.php
App::uses('Component', 'Component');
App::uses('AuthComponent', 'Controller/Component');
class UserLibComponent extends Component {
	public $components = array('Session', 'Auth');
	public $active_user = array();
	public $plugins = array();
	public $options = array(
			'full_permissions'=>array('groups'=>array(1),'users'=>array(1)),
			'allow'=>array()
	);
	private $__authenticate_actions = array( 'admin_index');
	private $__authorize_actions = array( 'admin_add','admin_delete');
	public function __construct(ComponentCollection $collection, $settings = array()){
		$this->options = array_merge($this->options,$settings);
		parent::__construct($collection);
	}
	public function startup(Controller $controller){
		$this->plugins = $this->get_plugins();
		$id =  $this->get_active_user_id('id');
		$sessionKey = AuthComponent::$sessionKey;
		
		//echo '<pre>';print_r($sessionKey);die;
		if($id) {
			$this->active_user = $this->Session->read($sessionKey);
			$user_group_id = $this->get_active_user_group_id();
			if(!$controller->params['admin'] && $controller->params['controller']!="admin"){
				return;
			}
			if(self::__is_allow(array('user'=>$id,'user_group_id'=>$user_group_id,'plugin'=>$controller->params['plugin']))){
				return true;
			}
			
			if(
			(empty($controller->params['plugin']))){
				return true;
			}else{
				self::__check_authenticate($controller);
				self::__check_authorize($controller);
			}
			return parent::startup($controller);
		}
	}
	public function load_active_user(){
		$id =  $this->get_active_user_id('id');
		$sessionKey = AuthComponent::$sessionKey;
		if($id) {
			$this->active_user = $this->Session->read($sessionKey);
		}
	}
	private function __is_allow($options = array()){
		/*check allow permission , full permission of user and user group and return true of match and  false if not
		*/
		if(empty($options['user'])){
			return false;
		}
		if(empty($options['user_group_id'])){
			return false;
		}
		if(empty($options['plugin'])){
			//return false;
		}
		//allow  plugin condition
		if(!empty($this->options['allow']) && in_array(Inflector::camelize($options['plugin']),$this->options['allow'])){
			return true;
		}
		// full permission condition based on user id
		if($this->_is_user_full_permission($options['user'])){
			return true;
		}
		
		// full permission condition based on user id
		if($this->_is_group_full_permission($options['user_group_id'])){
			return true;
		}
		return false;
	}
	private function __check_authenticate($_controller){
		/* Call on Component load only.
		 * Check accesss permission plugin based.
		 * Check admin_index function only and redirect to home if doesn't found.
		*/
		$plugin = Inflector::camelize($_controller->params['plugin']);
		
		if(in_array($_controller->params['action'],$this->__authenticate_actions)){
			if(!$this->check_access_permission($plugin)){
				$this->set_access_error_message();
				$url = $_controller->referer();
				if($url=="/" || empty($url)){
					$url="/admin/home";
				}
				$_controller->redirect($url);
			}
		}
	}
	public function set_access_error_message(){
		$this->Session->setFlash('You don\'t have permission to access that location','default', array(), 'error');
	}

	private function __check_authorize($_controller){
		/* Call on Component load only.
		 * Check modify permission plugin based.
		 * Check admin_add function only and redirect to home if doesn't found.
		*/
		$plugin = Inflector::camelize($_controller->params['plugin']);
		if(in_array($_controller->params['action'],$this->__authorize_actions) ){
			if(!$this->check_modify_permission($plugin)){
				$this->set_modify_error_message();
				$url = $_controller->referer();
				if($url=="/" || empty($url)){
					$url="/admin/home";
				}
				$_controller->redirect($url);
			}
		}
	}
	public function set_modify_error_message(){
		$this->Session->setFlash('You don\'t have permission to modify that location','default', array(), 'error');
	}
	
	public function add_authenticate_action($actions){
		self::__add_authenticate_action($actions);
	}
	private function __add_authenticate_action($actions){
		if(is_string($actions)){
			$this->__authenticate_actions[] = $actions;
			return true;
		}
		
		if(is_array($actions)){
			$this->__authenticate_actions = array_merge($this->__authenticate_actions,$actions);
			return true;
		}
		return;
	}
	public function add_authorize_action($actions){
		self::__add_authorize_action($actions);
	}
	private function __add_authorize_action($actions){
		if(is_string($actions)){
			$this->__authorize_actions[] = $actions;
			return true;
		}
		
		if(is_array($actions)){
			$this->__authorize_actions = array_merge($this->__authorize_actions,$actions);
			return true;
		}
		return;
	}
	
	public function check_authenticate($_controller){
		//pr($_controller);
		self::__check_authenticate($_controller);
	}
	public function check_authorize($_controller){
		//pr($_controller);
		self::__check_authorize($_controller);
	}	
	protected function _is_group_full_permission($group_id){
		if(in_array($group_id,$this->options['full_permissions']['groups'])){
				return true;
		}
		return false;
	}
	public function is_group_full_permission($group_id){
		return $this->_is_group_full_permission($group_id);
	}
	protected function _is_user_full_permission($user_id){
		if(in_array($user_id,$this->options['full_permissions']['users'])){
				return true;
		}
		return false;
	}
	public function is_user_full_permission($user_id){
		return $this->_is_user_full_permission($user_id);
	}
	function get_active_user_group_id(){
		$group_id = null;
		$loguser = $this->Session->read('Auth.Supplier');
		$loguser2 = $this->Session->read('Auth.NewBuyer');	
		if(empty($loguser) && empty($loguser2)){
			if(!empty($this->active_user)){
				$group_id = (int)$this->active_user['user_group_id'] ;
			}
		}
		return $group_id;
	}
	function get_active_user_id(){
		return $this->Auth->user('id');
	}
	function check_access_permission($controller=''){
		$permission = $this->active_user_access_permission();
		
		/*if(!empty($permission['access'])){
			if(in_array($controller,$permission['access'])){
				return true;
			}
		}
		$user_group_id = $this->get_active_user_group_id();
		
		if($user_group_id==19){*/
			if(!empty($permission[$controller]) && $permission[$controller]!=0){
				return true;
			}
		//}
		
		return false;
	}
	function check_modify_permission($controller=''){
		$permission = $this->active_user_access_permission();
		/*if(!empty($permission['modify']) && in_array($controller,$permission['modify'])){
			return true;
		}
		$user_group_id = $this->get_active_user_group_id();
		if($user_group_id==19){*/
			if(!empty($permission[$controller]) && $permission[$controller]==2){
				return true;
			}
		//}
		return false;
	}
	function active_user_access_permission(){
		$permission = array();
		if(!empty($this->active_user)){
			
			$permission = json_decode($this->active_user['UserGroups']['permissions'],true);
		//	print_r($this->active_user);die;
			
		}
		
		return $permission;
	}
	function get_plugins(){
		$plugins = $this->options['plugins'] = Cache::read('plugins');
		if(empty($plugins)){
			App::import('Model', 'Plugin');
			$Plugin = new Plugin();
			$this->options['plugins'] = $plugins = $Plugin->find('all',array('conditions'=>array('Plugin.status'=>1)));
			$modules = array();
			Cache::write('plugins',$plugins);
		}
		$id =  $this->get_active_user_id('id');
		$user_group_id = $this->get_active_user_group_id();
		foreach($plugins as $_plugin){
			if($_plugin['Plugin']['id'] ==4 && !self::__is_allow(array('user'=>$id,'user_group_id'=>$user_group_id)) ){
				continue;
			}
			$path = App::path('Plugin');
			$path = array_pop($path);
			if(empty($_plugin['Plugin']['title'])){
				continue;
			}
			Configure::load($_plugin['Plugin']['title'].'.config');
			if(Configure::check('Name.Plugin')){
				$modules[$_plugin['Plugin']['title']] = Configure::read('Name.Plugin');
				//$modules['plug_id'] = $_plugin['Plugin']['id'];
			}
			Configure::delete('Name.Plugin');
		}
		return $modules;
	}
	public function is_allow($options = array()){
		return self::__is_allow($options);
	}
	
	public function beforeRender(Controller $controller){
		if(!empty($this->active_user)){
			$loguser = $this->Session->read('Auth.Supplier');
			$loguser2 = $this->Session->read('Auth.NewBuyer');	
			if(empty($loguser) && empty($loguser2)){
			$this->options['user_id'] = $this->active_user['id'];
			$this->options['user_group_id'] = $this->active_user['user_group_id'];
			//$this->options['user'] = $this->active_user;
			$this->options['permissions'] = json_decode($this->active_user['UserGroups']['permissions'],true);
			}
		}
		$controller->helpers['Menu'] = $this->options; 
	}
}
?>