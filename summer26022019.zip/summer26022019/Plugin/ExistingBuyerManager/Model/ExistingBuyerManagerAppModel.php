<?php
Class ExistingBuyerManagerAppModel extends AppModel {
}
?>