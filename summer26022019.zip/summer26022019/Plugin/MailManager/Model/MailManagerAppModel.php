<?php
class MailManagerAppModel extends AppModel
{
       
}
 ?>
