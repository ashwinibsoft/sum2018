<?php class MailManagerAppController extends AppController
{
    
}

?>