<?php
Class MailsController extends MailManagerAppController{
	public $uses = array('MailManager.Mail');
	public $paginate = array();
	public $id = null;
	
	function admin_index($search=null,$limit=25){
		$this->paginate = array();
		$condition = null;
		if($search=="_blank"){
			$search=null;
		}
		$this->paginate['limit']=$limit;
		if($this->request->is('post')){
			
			if(!empty($this->request->data['search'])){
				$search = $this->request->data['search'];
			}else{
				$search = '_blank';
			}
			
			if(!empty($this->request->data['limit'])){
				$limit = $this->request->data['limit'];
			}else{
				$limit = '25';
			}
			
			
			$this->redirect(array('plugin'=>'mail_manager','controller'=>'mails','action'=>'index' ,$search,$limit));
		}
		$this->paginate['order']=array('Mail.ordering '=>'ASC','Mail.id'=>'DESC');
		
		if($search!=null){
			$search = urldecode($search);
			$condition['OR']['Mail.mail_title like'] = '%'.$search.'%';
			$condition['OR']['Mail.heading like'] = '%'.$search.'%';
		}
		
		$condition['Mail.status'] = 1;
		
		$mails=$this->paginate("Mail", $condition);	
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/home'),
			'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/mail_manager/mails'),
			'name'=>'Manage Mail Formats'
		);
		$this->heading =  array("Manage","Mail Formats");
		$this->set('mails',$mails);
		$this->set('search',$search);
		$this->set('limit',$limit);
		$this->set('url','/'.$this->params->url);
		if($this->request->is('ajax')){
			$this->layout = '';
			$this -> Render('ajax_admin_index');
		   
		}
		   
	}
	public function admin_preview($id = null){
		$this->autoRender = false;
		
		if(empty($this->request->data)){
			$this->request->data = $this->Mail->read(null,$id);
		}
		//pr($this->request->data);
		//$this->MyMail->from($this->request->data['Mail']['mail_from']);
		$this->MyMail->heading($this->request->data['Mail']['heading']);
		$subject = $this->MyMail->subject($this->request->data['Mail']['mail_subject']);
		$this->MyMail->body($this->request->data['Mail']['mail_body']);
		echo $this->System->excreat($this->MyMail->render());
	
	}

        
	function ajax_sort(){
		$this->autoRender = false;
		foreach($_POST['sort'] as $order => $id){
			$mails= array();
			$mails['Mail']['id'] = $id;
			$mails['Mail']['ordering'] = $order;
			$this->Mail->create();
			$this->Mail->save($mails);
		}
	   
	}
   
 
	function admin_add($id=null){
		
		$this->breadcrumbs[] = array(
		'url'=>Router::url('/admin/home'),
		'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/mail_manager/mails'),
				'name'=>'Manage Mail'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/mail_manager/mail/add'),
				'name'=>($id==null)?'Add Mail format':'Update Mail format'
		);
		
		if($id==null){
			$this->heading =  array("Add","Mail Format");
		}else{
			$this->heading =  array("Update","Mail Format");
		}
		
		if(!empty($this->request->data) && $this->validation()){
			if(!$id){
			$this->request->data['Mail']['created_at']=date('Y-m-d H:i:s');
			$this->request->data['Mail']['status']=1;
			}else{
			$this->request->data['Mail']['updated_at']=date('Y-m-d H:i:s');
			}
			$this->Mail->create();
			$this->Mail->save($this->request->data);
			if ($this->request->data['Mail']['id']) {
				$this->Session->setFlash(__('Mail has been updated successfully'));
				} 
				else {
					$this->Session->setFlash(__('Mail has been added successfully'));
				}
			$this->redirect(array('action'=>'add',$id,'?'=>array('back'=>$this->request->data['Mail']['url_back_redirect'])));
			/*
			if(isset($this->request->data['save'])){
					$this->redirect(array('controller'=>'mails','action'=>'admin_add',$id));
				}else{
					$this->redirect(array('controller'=>'mails','action'=>'admin_index'));
			}
			*/
		}
		else{
			if($id!=null){
				$this->request->data = $this->Mail->read(null,$id);
			}else{
				$this->request->data = array();
			}
		}
		
		$referer_url = $this->request->query('back');
		if(!empty($referer_url)){
			$referer_url= $this->request->query('back');
		}else{
			$referer_url=(Controller::referer()=="/")? Router::url('/admin/mail_manager/mails',true) :Controller::referer();
		
		}
		$this->set('referer_url',$referer_url);
		
		$this->set('url',Controller::referer());
	}
	
        
	function admin_delete($id=null){
		$this->autoRender = false;
		$data=$this->request->data['Mail']['id'];
		$action = $this->request->data['Mail']['action'];
		$ans="0";
		foreach($data as $value){
			if($value!='0'){
				if($action=='Publish'){
					$mail['Mail']['id'] = $value;
					$mail['Mail']['status']=1;
					$this->Mail->create();
					$this->Mail->save($mail);
					$ans="1";
				}
				if($action=='Unpublish'){
					$mail['Mail']['id'] = $value;
					$mail['Mail']['status']=0;
					$this->Mail->create();
					$this->Mail->save($mail);
					$ans="1";
				}
				if($action=='Delete'){
					$this->Mail->delete($value);
					$ans="2";
				}
			}
		}
		if($ans=="1"){
			$this->Session->setFlash(__('Mail(s) has been '.strtolower($this->data['Mail']['action']).'ed successfully', true));
		}
		else if($ans=="2"){
			$this->Session->setFlash(__('Mail(s) has been '.strtolower($this->data['Mail']['action']).'d successfully', true));
		}else{
			$this->Session->setFlash(__('Please Select any Mail', true),'default','','error');
		}
		$this->redirect($this->request->data['Mail']['redirect']);
	}

	
	function validation(){
		if(!empty($this->request->data['Mail']['form'])){
			$this->Mail->setValidation($this->request->data['Mail']['form']);
		}else{
			//throw new NotFoundException('404 Error - Page not found');
		}
		$this->Mail->set($this->request->data);
		return $this->Mail->validates();
	}
	public function ajax_validation($returnType = 'json'){
		
		$this->autoRender = false;
		if(!empty($this->request->data)){
			if(!empty($this->request->data['Mail']['form'])){
				$this->Mail->setValidation($this->request->data['Mail']['form']);
			}
			$this->Mail->set($this->request->data);
			$result = array();
			if($this->Mail->validates()){
					$result['error'] = 0;
			}else{
				$result['error'] = 1;
				$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
			}
			$errors = array();
			$result['errors'] = $this->Mail->validationErrors;
			foreach($result['errors'] as $field => $data){
			  $errors['Mail'.Inflector::camelize($field)] = array_pop($data);
			}
			$result['errors'] = $errors;
			$view = new View();
			
			$result['error_message'] = $view->element('admin/message');
			echo json_encode($result);
			return;
		}
		echo json_encode(array());
	}
	public function admin_dashboard(){
		$home_mails=$this->Mail->find('all',array('limit'=>5,'order'=>array('Mail.ordering '=>'ASC','Mail.id'=>'DESC')));
		$this->set('mails',$home_mails);
	}

}


?>