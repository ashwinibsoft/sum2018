<?php
$config = array();
$config['Name']['Plugin'] = "Mail Manager";
$config['Request']['Dashboard'] = array(
								'position'=>3,
								'title'=>'Mail',
								'url'=>array('plugin'=>'mail_manager','controller'=>'mails','action'=>'admin_dashboard','admin'=>true)
								);
$config['Menu']['Left'] = array(
					array(
					'position'=>1,
					'icon'=>'fa-envelope-o',
					'title'=>'Mail Manager',
					'url'=>Router::url('/admin/mail_manager/mails/index')
					)
				);
?>
