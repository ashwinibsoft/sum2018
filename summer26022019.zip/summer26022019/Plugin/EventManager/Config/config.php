<?php
$config = array();
$config['Name']['Plugin'] = "Event Manager";
$config['Menu']['Left'] = array(
					array(
					'position'=>5,
					'icon'=>'fa fa-calendar',
					'title'=>'Events Manager',
					'url'=>array('plugin'=>'event_manager','controller'=>'events','action'=>'admin_index','admin'=>true),
					'sub_menus'=> array(
						array(
							'title'=>'Manage Events',
							'url'=>array('plugin'=>'event_manager','controller'=>'events','action'=>'admin_index','admin'=>true),
							'right'=>array('title'=>'Add New Event','url'=>array('plugin'=>'event_manager','controller'=>'events','action'=>'admin_add','admin'=>true))
							),
						array(
							'title'=>'Manage Event Categories',
							'url'=>array('plugin'=>'event_manager','controller'=>'e_categories','action'=>'admin_index','admin'=>true)
							),
						array(
							'title'=>'Event Settings',
							'url'=>array('plugin'=>'event_manager','controller'=>'events','action'=>'admin_settings','admin'=>true)
							)
						)
					)
				);
$config['Settings']['event_location']=true;
$config['Settings']['event_gallery']=true;
$config['Settings']['event_repeat']=true;
$config['Settings']['event_category']=true;
$config['Settings']['feature_image']=true;
$config['Settings']['feature_seo']=true;
$config['Settings']['feature_attribute']=true;
$config['Settings']['youtube_event']=true;

$config['Folder']['feature_image'] = "featureimage";
$config['Path']['feature_image'] =  WWW_ROOT.'img'.DS.$config['Folder']['feature_image'].DS;
$config['Path']['NoImage'] =  WWW_ROOT.'img'.DS.'site'.DS.'noimage.jpg';
$config['Path']['CatFoldername'] =  'eventcat';
$config['Path']['Category'] =  WWW_ROOT.'img'.DS.$config['Path']['CatFoldername'].DS;
$config['Admin']['Limit'] = 20;

$config['Path']['FolderName'] =  'files';
$config['Path']['Assisted'] =  WWW_ROOT.'img'.DS.$config['Path']['FolderName'].DS;
/***These below code is used  for admin purpose*/
$config['image_list_width'] = "80";
$config['image_list_height'] = "80";
$config['image_edit_width'] = "290";
$config['image_edit_height'] = "240";
$config['image_front_width'] = "220";
$config['image_front_height'] = "200";

$config['image_front_list_width'] = "211";
$config['image_front_list_height'] = "156";

$config['image_admin_edit_width'] = "80";
$config['image_admin_edit_height'] = "80";


$config['default_feature_thumb_width'] = "625";
$config['default_feature_thumb_height'] = "350";
$config['image_front_gallery_slideshow_width'] = "310";
$config['image_front_gallery_slideshow_height'] = "190";
/**Belowe code is used for front banner image on front**/
$config['feature_image_width']="1400";
$config['feature_image_height']="350";
$config['feature_image_height']="550";
$config['image_crop_ratio']='4:3';
$config['cat_image_width']="1400"; //Use to set category image width that shows on front side

$config['cat_image_height']="470"; //Use to set category image height that shows on front side

$config['Event']['templates'] = array(
'two_page_template' =>'Two Page Template',
'template2' =>'Template2',
'template3' => 'Template3'
);

$config['Event']['country'] = array(
	"Afghanistan"=>"Afghanistan",
	"Albania"=>"Albania",
	"Algeria"=>"Algeria",
	"Algeria"=>"Algeria",
	"Algeria"=>"Algeria",
	"Antigua and Barbuda"=>"Antigua and Barbuda",
	"Argentina"=>"Argentina",
	"Armenia"=>"Armenia",
	"Australia"=>"Australia",
	"Austria"=>"Austria",
	"Azerbaijan"=>"Azerbaijan",
	"Bahamas"=>"Bahamas",
	"Bahrain"=>"Bahrain",
	"Bangladesh"=>"Bangladesh",
	"Barbados"=>"Barbados",
	"Belarus"=>"Belarus",
	"Belgium"=>"Belgium",
	"Belize"=>"Belize",
	"Benin"=>"Benin",
	"Bhutan"=>"Bhutan",
	"Bolivia"=>"Bolivia",
	"Bosnia and Herzegovina"=>"Bosnia and Herzegovina",
	"Botswana"=>"Botswana",
	"Brazil"=>"Brazil",
	"Brunei"=>"Brunei",
	"Bulgaria"=>"Bulgaria",
	"Burkina Faso"=>"Burkina Faso",
	"Burundi"=>"Burundi",
	"Cambodia"=>"Cambodia",
	"Cameroon"=>"Cameroon",
	"Canada"=>"Canada",
	"Cape Verde"=>"Cape Verde",
	"Central African Republic"=>"Central African Republic",
	"Chad"=>"Chad",
	"Chile"=>"Chile",
	"China"=>"China",
	"Colombi"=>"Colombi",
	"Comoros"=>"Comoros",
	"Congo (Brazzaville)"=>"Congo (Brazzaville)",
	"Congo"=>"Congo",
	"Costa Rica"=>"Costa Rica",
	"Cote d'Ivoire"=>"Cote d'Ivoire",
	"Croatia"=>"Croatia",
	"Cuba"=>"Cuba",
	"Cyprus"=>"Cyprus",
	"Czech Republic"=>"Czech Republic",
	"Denmark"=>"Denmark",
	"Djibouti"=>"Djibouti",
	"Dominica"=>"Dominica",
	"Dominican Republic"=>"Dominican Republic",
	"East Timor (Timor Timur)"=>"East Timor (Timor Timur)",
	"Ecuador"=>"Ecuador",
	"Egypt"=>"Egypt",
	"El Salvador"=>"El Salvador",
	"Equatorial Guinea"=>"Equatorial Guinea",
	"Eritrea"=>"Eritrea",
	"Estonia"=>"Estonia",
	"Ethiopia"=>"Ethiopia",
	"Fiji"=>"Fiji",
	"Finland"=>"Finland",
	"France"=>"France",
	"Gabon"=>"Gabon",
	"Gambia, The"=>"Gambia, The",
	"Georgia"=>"Georgia",
	"Germany"=>"Germany",
	"Ghana"=>"Ghana",
	"Greece"=>"Greece",
	"Grenada"=>"Grenada",
	"Guatemala"=>"Guatemala",
	"Guinea"=>"Guinea",
	"Guinea-Bissau"=>"Guinea-Bissau",
	"Guyana"=>"Guyana",
	"Haiti"=>"Haiti",
	"Honduras"=>"Honduras",
	"Hungary"=>"Hungary",
	"Iceland"=>"Iceland",
	"India"=>"India",
	"Indonesia"=>"Indonesia",
	"Iran"=>"Iran",
	"Iraq"=>"Iraq",
	"Ireland"=>"Ireland",
	"Israel"=>"Israel",
	"Italy"=>"Italy",
	"Jamaica"=>"Jamaica",
	"Japan"=>"Japan",
	"Jordan"=>"Jordan",
	"Kazakhstan"=>"Kazakhstan",
	"Kenya"=>"Kenya",
	"Kiribati"=>"Kiribati",
	"Korea, North"=>"Korea, North",
	"Korea, South"=>"Korea, South",
	"Kuwait"=>"Kuwait",
	"Kyrgyzstan"=>"Kyrgyzstan",
	"Laos"=>"Laos",
	"Latvia"=>"Latvia",
	"Lebanon"=>"Lebanon",
	"Lesotho"=>"Lesotho",
	"Liberia"=>"Liberia",
	"Libya"=>"Libya",
	"Liechtenstein"=>"Liechtenstein",
	"Lithuania"=>"Lithuania",
	"Luxembourg"=>"Luxembourg",
	"Macedonia"=>"Macedonia",
	"Madagascar"=>"Madagascar",
	"Malawi"=>"Malawi",
	"Malaysia"=>"Malaysia",
	"Maldives"=>"Maldives",
	"Mali"=>"Mali",
	"Malta"=>"Malta",
	"Marshall Islands"=>"Marshall Islands",
	"Mauritania"=>"Mauritania",
	"Mauritius"=>"Mauritius",
	"Mexico"=>"Mexico",
	"Micronesia"=>"Micronesia",
	"Moldova"=>"Moldova",
	"Monaco"=>"Monaco",
	"Mongolia"=>"Mongolia",
	"Morocco"=>"Morocco",
	"Mozambique"=>"Mozambique",
	"Myanmar"=>"Myanmar",
	"Namibia"=>"Namibia",
	"Nauru"=>"Nauru",
	"Nepa"=>"Nepa",
	"Netherlands"=>"Netherlands",
	"New Zealand"=>"New Zealand",
	"Nicaragua"=>"Nicaragua",
	"Niger"=>"Niger",
	"Nigeria"=>"Nigeria",
	"Norway"=>"Norway",
	"Oman"=>"Oman",
	"Pakistan"=>"Pakistan",
	"Palau"=>"Palau",
	"Panama"=>"Panama",
	"Papua New Guinea"=>"Papua New Guinea",
	"Paraguay"=>"Paraguay",
	"Peru"=>"Peru",
	"Philippines"=>"Philippines",
	"Poland"=>"Poland",
	"Portugal"=>"Portugal",
	"Qatar"=>"Qatar",
	"Romania"=>"Romania",
	"Russia"=>"Russia",
	"Rwanda"=>"Rwanda",
	"Saint Kitts and Nevis"=>"Saint Kitts and Nevis",
	"Saint Lucia"=>"Saint Lucia",
	"Saint Vincent"=>"Saint Vincent",
	"Samoa"=>"Samoa",
	"San Marino"=>"San Marino",
	"Sao Tome and Principe"=>"Sao Tome and Principe",
	"Saudi Arabia"=>"Saudi Arabia",
	"Senegal"=>"Senegal",
	"Serbia and Montenegro"=>"Serbia and Montenegro",
	"Seychelles"=>"Seychelles",
	"Sierra Leone"=>"Sierra Leone",
	"Singapore"=>"Singapore",
	"Slovakia"=>"Slovakia",
	"Slovenia"=>"Slovenia",
	"Solomon Islands"=>"Solomon Islands",
	"Somalia"=>"Somalia",
	"South Africa"=>"South Africa",
	"Spain"=>"Spain",
	"Sri Lanka"=>"Sri Lanka",
	"Sudan"=>"Sudan",
	"Suriname"=>"Suriname",
	"Swaziland"=>"Swaziland",
	"Sweden"=>"Sweden",
	"Switzerland"=>"Switzerland",
	"Syria"=>"Syria",
	"Taiwan"=>"Taiwan",
	"Tajikistan"=>"Tajikistan",
	"Tanzania"=>"Tanzania",
	"Thailand"=>"Thailand",
	"Togo"=>"Togo",
	"Tonga"=>"Tonga",
	"Trinidad and Tobago"=>"Trinidad and Tobago",
	"Tunisia"=>"Tunisia",
	"Turkey"=>"Turkey",
	"Turkmenistan"=>"Turkmenistan",
	"Tuvalu"=>"Tuvalu",
	"Uganda"=>"Uganda",
	"Ukraine"=>"Ukraine",
	"United Arab Emirates"=>"United Arab Emirates",
	"United Kingdom"=>"United Kingdom",
	"United States"=>"United States",
	"Uruguay"=>"Uruguay",
	"Uzbekistan"=>"Uzbekistan",
	"Vanuatu"=>"Vanuatu",
	"Vatican City"=>"Vatican City",
	"Venezuela"=>"Venezuela",
	"Vietnam"=>"Vietnam",
	"Yemen"=>"Yemen",
	"Zambia"=>"Zambia",
	"Zimbabwe"=>"Zimbabwe"
); 




?>
