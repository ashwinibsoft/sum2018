<?php
Class Event extends EventManagerAppModel {
	public $name = "Event";
	public $hasOne = 'EventLocation';
	public $actsAs = array('Multivalidatable');
	public $post_action = "";
	public $validationSets = array(
	'event_add'=>array(
	'event_title' => array(
            'rule1' =>
             array(
                'rule' => 'notEmpty',
                'message' => 'Please enter event title.'
            ),
            array(
                'rule' => array('maxLength', 255),
                'message' => 'Event title should be less than 255 charcter(s).'
            ),
           
        ),

        'event_start_date' =>
        array(
            'rule1' =>
            array(
					'rule'    => 'notEmpty',
					'message'  => 'Please enter event start date'
					),
            array(
                'rule' => array('date', 'mdy'),
					'message' => 'You must provide event start date in MM/DD/YY format.',
            ),
            
        ),
        
        'event_start_time' =>
        array(
            'rule1' =>
             array(
					'rule'    => 'notEmpty',
					'message'  => 'Please enter event start time'
					),
            array(
                'rule' => array('time', 'H:M'),
					'message' => 'You must provide event start time in HH:MM:SS format.',
            ),
           
        ),
        'event_end_date' =>
        array(
            'rule1' =>
            array(
					'rule'    => 'checkempty',
					'required' => true,
					'message'  => 'Please enter event end date'
					),	
            array(
                'rule' => array('date', 'mdy'),
                'allowEmpty' => true,
				'message' => 'You must provide event end date in MM/DD/YY format.',
            ),
            array(
				'rule' => 'dates', 
				'message' => 'The end date must be later than start date'
				),
			
        ),
        'event_end_time' =>
        array(
            'rule1' =>
             array(
					'rule'    => 'checktime',
					'required' => true,
					'message'  => 'Please enter event end time'
					),	 
            array(
                'rule' => array('time', 'H:M'),
                'allowEmpty' => true,
				'message' => 'You must provide a event end time in HH:MM:SS format.',
            )
        ),
        'event_short_des' =>array(
				'rule1' =>
				array(
					'rule' => array('maxLength', 500),
					'message' => 'Description should be less than 500 character(s).'
				),
				array('rule' => 'notEmpty','message' => 'Please enter Description.'),
			),
		'event_gallery' =>array(
				'rule' => 'notEmpty',
				'allowEmpty'=>true, 
				'message' => 'Please Select Event Gallery.'
			),
		'event_category' =>array(
				'rule' => 'notEmpty',
				'message' => 'Please Select Event Category.'
			),
		'event_owner' =>array(
				'rule' => 'notEmpty',
				'message' => 'Please enter event owner name.'
			),
		'location_name'=>array(
				'rule1' => 
				array('rule' => 'notEmpty','message' => 'Plaese Location name.'),
				array('rule' => array('maxLength', 255),'message' => 'Location Name should be less than 255 charcter(s).')
			),
		'address'=>array(
				'rule1' => 
				array('rule' => 'notEmpty','allowEmpty' => true,'message' => 'Please enter Address.'),
				array('rule' => array('maxLength', 255),'message' => 'Address should be less than 255 charcter(s).')
			),
		'city'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Please enter city.'),
				array('rule' => array('maxLength', 200),'message' => 'city name should be less than 255 charcter(s).')
			),
		'phone'=>array(
				 'rule1'=>
				 array('rule'=>array('custom','/([0-9]{1}[0-9]{9})/'),
					'allowEmpty'=>true, 
					'message'=>'Invalid mobile number! mobile number format: eg 0755434434'),
				
			),
		'state'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Please enter state name.'),
				array('rule' => array('maxLength', 200),'message' => 'state name should be less than 255 charcter(s).')
			),
		'pincode' =>  array(
			'rule1'=>
			array('rule' => array('postal', null, 'us'),
			'allowEmpty' => true,
			'message' => 'Your pin code is not in the correct format.',
			),
    	),
		'country'=>array(
				'rule1' => 
				array('rule' => 'notEmpty','message' => 'Please select country name.'),
				 array('rule' => array('maxLength', 255),'message' => 'country name should be less than 255 charcter(s).')
			),
		'feature_image' => array(
					
					'rule1'=>array(
							'rule' => array('validate_image'),
							'message' => 'Please Upload Valid Image.'
						),
					/*'rule2'=>array(
							'rule' => array('check_size'),
							'message' => 'Only png, gif, jpg, jpeg images are allowed. Please upload 1000x500 dimension of image for better resolution.'
						),*/
				)
   
    )
    );
	public function dates(){ 

			if($this->data['Event']['event_end_date'] > $this->data['Event']['event_start_date']){
				return true;
			}
			else{
				return false;
			}

		}
	public function checkempty()
	{
		if($this->data['Event']['event_end_status']){
			if($this->data['Event']['event_end_date']!='')
			{
				return true;
				}
				return false;
			}
			else{
				return true;
			}
		
		}	
	public function checktime()
	{
		if($this->data['Event']['event_end_status']){
			if($this->data['Event']['event_end_time']!='')
			{
				return true;
				}
				return false;
			}
			else{
				return true;
			}
		
		}
	function validate_image(){
		if((!empty($this->data['Event']['id'])) && $this->data['Event']['feature_image']['name']=='') {
			return true;
		}else{
			if(!empty($this->data['Event']['feature_image']['name'])) {
				$file_part = explode('.',$this->data['Event']['feature_image']['name']);
				$ext = array_pop($file_part);		
				if(!in_array(strtolower($ext),array('gif', 'jpeg', 'png', 'jpg'))) {
					return false;
				}
			}
		return true;
		}
	}			

	
}
?>