<?php
App::uses('CakeTime', 'Utility');
Class EventLocation extends EventManagerAppModel {
	public $name = "EventLocation";
	public $validation = array(
	'location_name'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Plaese enter Location name.'),
				array('rule' => array('maxLength', 255),'message' => 'Location Name should be less than 255 charcter(s).')
			),
	'address'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Plaese enter Address.'),
				array('rule' => array('maxLength', 255),'message' => 'Address should be less than 255 charcter(s).')
			),
	'city'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Plaese enter city.'),
				array('rule' => array('maxLength', 200),'message' => 'city name should be less than 255 charcter(s).')
			),
	'state'=>array(
				'rule1' => array('rule' => 'notEmpty','message' => 'Plaese enter state.'),
				array('rule' => array('maxLength', 200),'message' => 'state name should be less than 255 charcter(s).')
			),
	'phone'=>array(
				 'rule' => array('phone', null, 'in'),
				
			),
	'country'=>array(
				'rule1' => 
				array('rule' => 'notEmpty','message' => 'Plaese enter country name.'),
				 array('rule' => array('maxLength', 255),'message' => 'country name should be less than 255 charcter(s).')
			),	
	'pincode'=>array(
				'rule' => array('rule' => array('postal', null, 'in')
			),											
	
	)
	);
	
	
	
	

}
?>