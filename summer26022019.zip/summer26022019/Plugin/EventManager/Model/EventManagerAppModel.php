<?php
Class EventManagerAppModel extends AppModel {
}
?>