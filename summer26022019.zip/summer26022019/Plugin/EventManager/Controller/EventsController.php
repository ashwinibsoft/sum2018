<?php
Class EventsController extends EventManagerAppController{
	public $uses = array('EventManager.Event','EventManager.EventLocation');
	public $components=array('Email','RequestHandler','Image');
	public $paginate = array();
	public $id = null;
	public $template=null;
	public function admin_index($search=null,$limit=10,$category=0){
		$this->paginate = array();
		$condition = null;
		if($search=="_blank"){
			$search=null;
		}
		$this->paginate['limit']=$limit;
		if($this->request->is('post')){
			/*
			if(!empty($this->request->data['location_name'])){
				$location_name = $this->request->data['location_name'];
			}else{
				$location_name = 0;
			}
			*/
			if(!empty($this->request->data['category'])){
				$category = $this->request->data['category'];
			}else{
				$category = 0;
			}
			if(!empty($this->request->data['search'])){
				$search = $this->request->data['search'];
			}else{
				$search = '_blank';
			}
			if(!empty($this->request->data['limit'])){
				$limit = $this->request->data['limit'];
			}else{
				$limit = '10';
			}
			$this->redirect(array('plugin'=>'event_manager','controller'=>'events','action'=>'index',$search,$limit,$category));
		}
		if($search!=null){
			$search = urldecode($search);
			$condition['Event.event_title like'] = '%'.$search.'%';
		}
		/*
		if($location_name!=0){
			$condition['EventLocation.id'] =$location_name;
		}
		*/
		if($category!=0){
			$condition['Event.event_category'] =$category;
		}
		$events = array();
		$this->paginate['order']=array('Event.id'=>'DESC');
		$events=$results=$this->paginate("Event", $condition);
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/home'),
			'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
			'url'=>Router::url('/admin/event_manager/events'),
			'name'=>'Manage Event'
		);
		
		$this->heading =  array("Manage","Event");
		//$location = $this->EventLocation->find('list',array('fields'=>array('id','location_name'),'order'=>array('EventLocation.id'=>'DESC')));
		$this->loadModel('EventManager.ECategorie');
		$cat_list = $this->ECategorie->find('list',array('fields'=>array('id','cat_name'),'order'=>array('ECategorie.id'=>'DESC')));
		$this->set('events',$results);
		$this->set('limit',$limit);
		//$this->set('location',$location);
		//$this->set('location_name',$location_name);
		$this->set('cat_list',$cat_list);
		$this->set('category',$category);
		$this->set('search',$search);
		$this->set('url','/'.$this->params->url);
	}
	
	
	function admin_default_image_crop($id=null){
		$path  = $this->webroot;
		$this->Image = $this->Components->load('Image');
		$this->Image->startup($this);
		$event_image = $this->Event->find('first',array('fields'=>array('Event.feature_image'),'conditions'=>array('Event.id'=>$id)));
		if($this->request->is('post')){
			
			$org_image_breaks = explode('.',$event_image['Event']['feature_image']);
			$ext = array_pop($org_image_breaks);
			$origFile = $event_image['Event']['feature_image'];

			$src = Configure::read('Path.feature_image').$event_image['Event']['feature_image'];
			$old_slide = Configure::read('Path.feature_image').$event_image['Event']['feature_image'];
			$org_image_breaks = implode('.',$org_image_breaks);
			$org_image_breaks = explode('_',$org_image_breaks);
			array_pop($org_image_breaks);
			$org_image_breaks = implode('_',$org_image_breaks);
			$new_name =$org_image_breaks.'_'.time().'.'.$ext;
			$dst =  Configure::read('Path.feature_image').$new_name;
			
			$start_width = $this->data['x'];
			$start_height = $this->data['y'];
			$width = $this->data['width'];
			$height = $this->data['height'];
			$key = 'feature_image';
			$thumb = $this->Image->crop($src,$dst,$width,$height,$start_width,$start_height,$this->data['scale']);
			$event_data = array();
			$event_data['Event']['id'] = $id;
			$event_data['Event']['feature_image'] = $new_name;
			
			$_options = array(
						'destination'=>Configure::read('Path.Slide'),
						);
			if($this->Event->save($event_data,array('validate'=>false))){
				if($event_image['Event']['feature_image']!='' && file_exists($old_slide)){
					unlink($old_slide);
				}
				$this->Session->setFlash('Image cropped and saved.');
				$this->redirect(array('controller' => 'events', 'action' => 'admin_add',$id));
			}
			Cache::delete('site');
			$this->redirect(array('action'=>'admin_add',$id));
		}
		$this->set('feature_image',$slide_image);
	}
	
	
	
	function admin_add($id=null){
		
		
		$path  = $this->webroot;
		$galleries = array();
		if($this->_is_active_plugins('GalleryManager')){
			$this->loadModel('GalleryManager.Gallery');
			$galleries = $this->Gallery->find('list',array('fields'=>array('id','name'),'order'=>array('Gallery.id'=>'DESC')));
		}
			$this->loadModel('EventManager.ECategorie');
			$cat_list = $this->ECategorie->find('list',array('fields'=>array('id','cat_name'),'order'=>array('ECategorie.id'=>'DESC')));
		
		$this->breadcrumbs[] = array(
		'url'=>Router::url('/admin/home'),
		'name'=>'Dashboard'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/event_manager/events'),
				'name'=>'Manage Event'
		);
		$this->breadcrumbs[] = array(
				'url'=>Router::url('/admin/event_manager/events/add/'.$id),
				'name'=>($id==null)?'Add Event':'Update Event'
		);
		if($id==null){
			$this->heading =  array("Add","Event");
		}else{
			$this->heading =  array("Update","Event");
		}
		
			 
		if(!empty($this->request->data) && $this->validation()){
			$existing_image='';
			if($this->request->data['Event']['id'] && $this->request->data['Event']['feature_image']){
				$feature_image = $this->Event->find('first',array('fields'=>array('Event.feature_image'),'conditions'=>array('Event.id'=>$this->request->data['Event']['id'])));
				$existing_image = $feature_image['Event']['feature_image'];
			
			}
			if($this->request->data['Event']['feature_image'])
			{
				$_options = array(
			'destination'=>Configure::read('Path.feature_image'),
			'image'=>$this->request->data['Event']['feature_image']
			);
			if($this->request->data['Event']['feature_image']['error'] > 0 && !empty($this->request->data['Event']['id'])){
				$this->request->data['Event']['feature_image'] = $existing_image;
			}else{
				if($this->request->data['Event']['feature_image']['error'] < 1){
				$this->request->data['Event']['feature_image'] = $this->System->Image->upload($_options);
				$this->request->data['Event']['is_cropped'] = 0;
				}else{
					$this->request->data['Event']['feature_image'] = "";
				}
			}
		}
			$youTube = array();
			if(!empty($this->request->data['Event']['youtube'])){		
				foreach($this->request->data['Event']['youtube'] as $youtube){
					array_push($youTube,$youtube);	
				}
			}if(!empty($youTube)){
				$this->request->data['Event']['youtube'] = json_encode($youTube);
			}
			$slug_url = '';
			if(empty($this->request->data['Event']['id'])){
				if($this->request->data['Event']['slug_url']==''){
					$string = strtolower($this->request->data['Event']['event_title']);
					$slug_url = Inflector::slug($string, '-');
				}else{
					//echo "down";print_r($this->request->data['Event']['slug_url']);die;
					$slug_url = $this->request->data['Event']['slug_url'];
				}
			}else{
				
				$slug_url = $this->request->data['Event']['slug_url'];
			}
			
			
			$route = array();
			$route['request_uri'] = trim($slug_url);
			$route['object'] = 'Event';
			$route['object_id'] = $this->Event->id;
			$route['object_name'] = $this->request->data['Event']['event_title'];
			$route['values'] = json_encode(array('plugin'=>'event_manager','controller'=>'events','action'=>'view','id'=>$this->Event->id));
			
			$this->Event->save_routes($route); 
			if(!$id){
				$this->request->data['Event']['created_at']=date('Y-m-d H:i:s');
				$var =$this->request->data['Event']['event_start_date'];
                $event_start_time=date("Y-m-d", strtotime($var));
                $this->request->data['Event']['event_start']=$event_start_time.' '.$this->request->data['Event']['event_start_time']; 
                if($this->request->data['Event']['event_end_date']) 
                { 
                $var =$this->request->data['Event']['event_end_date'];
                $event_end_date=date("Y-m-d", strtotime($var));
				$this->request->data['Event']['event_end']=$event_end_date.' '.$this->request->data['Event']['event_end_time'];
				
			}
				
	      
				
			}else{
				$this->request->data['Event']['updated_at']=date('Y-m-d H:i:s');
				$var =$this->request->data['Event']['event_start_date'];
                $event_start_time=date("Y-m-d", strtotime($var));
                $this->request->data['Event']['event_start']=$event_start_time.' '.$this->request->data['Event']['event_start_time'];    
             if($this->request->data['Event']['event_end_date']) 
                { 
                $var =$this->request->data['Event']['event_end_date'];
                $event_end_date=date("Y-m-d", strtotime($var));
				$this->request->data['Event']['event_end']=$event_end_date.' '.$this->request->data['Event']['event_end_time'];
			}
				
						
				
			}
			
			if(empty($this->request->data['Event']['id'])){
				if(isset($this->request->data['save']) && $this->request->data['save']=='Save'){
					$this->request->data['Event']['status'] = 2;
				}else{
					$this->request->data['Event']['status'] = 1;
				}
			}
			
			$this->Event->create();
			$this->Event->save($this->request->data,array('validate'=>false));
		
				if($id)
			{
				 $max=$id;
				}
				else
				{
					$max= $this->Event->find('all',array('fields'=>array('MAX(Event.id) AS maxid')));
	        $max=$max[0][0]['maxid'];
	        $max=$max;
					}
			$eventloc=array(
			'EventLocation'=>array(
			'event_id'=>$max,
			'location_name'=>$this->request->data['Event']['location_name'],
			'address'=>$this->request->data['Event']['address'],
			'city'=>$this->request->data['Event']['city'],
			'state'=>$this->request->data['Event']['state'],
			
			'location_name'=>$this->request->data['Event']['location_name'],
			'country'=>$this->request->data['Event']['country'],
			'pincode'=>$this->request->data['Event']['pincode'],
            'latitude'=>$this->request->data['Event']['latitude'],
            'longitude'=>$this->request->data['Event']['longitude'],
			)
			);
			if($id)
			{
				$loc_id=$this->EventLocation->find('first',array('fields'=>array('EventLocation.id'),'conditions'=>array('EventLocation.event_id'=>$id)));
				$loc_id=$loc_id['EventLocation']['id'];
			$this->EventLocation->id=$loc_id;	
			$this->EventLocation->save($eventloc,array('validate'=>false));
				 }
		else
		{
			$this->EventLocation->create();	
			$this->EventLocation->save($eventloc,array('validate'=>false));
			
			}
				$id = $this->Event->id;
			if ($this->request->data['Event']['id']) {
				$this->Session->setFlash(__('Event has been updated successfully'));
			} 
			else{
				$this->Session->setFlash(__('Event has been added successfully'));
			}
			$this->redirect(array('action'=>'add',$id,'?'=>array('back'=>$this->request->data['Event']['url_back_redirect'])));
		}
		else{
			if(!empty($this->request->data)){
				$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
			}
			
			if($id!=null){
				$this->request->data = $this->Event->read(null,$id);
			}else{
				$this->request->data = array();
			}
		}
		
		$referer_url = $this->request->query('back');
		if(!empty($referer_url)){
			$referer_url= $this->request->query('back');
		}else{
			$referer_url=(Controller::referer()=="/")? Router::url('/admin/event_manager/events',true) :Controller::referer();
		
		}
		
		$this->set('referer_url',$referer_url);
		$this->set('galleries',$galleries);
		$this->set('cat_list',$cat_list);
		$this->set('event_id',$id);
			
	//echo "down";print_r($this->request->data);die;
			
			 
	}
	public function admin_one_delete($event_id = null){
		$this->autoRender = false;
		if($event_id==null){
			$this->redirect(Controller::referer());
		}
		$event = $this->Event->find('first', array('conditions'=> array('Event.id' => $event_id)));
		if (!empty($event['Event']['feature_image'])) {
			   @unlink(WWW_ROOT."img/featureimage/". $event['Event']['feature_image']);
		}
		$this->Event->delete($event_id);
		$this->EventLocation->deleteAll(array('EventLocation.event_id' => $event_id));
		$this->Session->setFlash(__('Event has been deleted successfully'));
		$redirect_url = $this->request->query('back');
		if(!empty($redirect_url)){
			$this->redirect($redirect_url);
		}else{
			$this->redirect(array('action'=>'admin_index'));
		}
		
		
		
	}
	
	function admin_delete_event_image($id= null){
		$this->event = $this->Event->read(null,$id);
		$this->Event->updateAll(
				array('Event.feature_image' => null),
				array('Event.id'=>$id)
			);
		self::__delete_event_image();
		if ($this->request->is('ajax')) {
			$this->autoRender = false;
		}else{
			$this->redirect(array('action'=>'add',$id));
		}
	}
	private function __delete_event_image(){
		App::uses('ImageResizeHelper', 'View/Helper');
		$ImageResize = new ImageResizeHelper();
		$imgArr = array('source_path'=>Configure::read('Path.feature_image'),'img_name'=>$this->event['Event']['feature_image'],'width'=>Configure::read('image_edit_width'),'height'=>Configure::read('image_edit_height'));
		$ImageResize->deleteThumbImage($imgArr);
		
		$imgArr = array('source_path'=>Configure::read('Path.feature_image'),'img_name'=>$this->event['Event']['feature_image'],'width'=>Configure::read('feature_image_width'),'height'=>Configure::read('feature_image_height'));
		$ImageResize->deleteThumbImage($imgArr);
		
		@unlink(Configure::read('Path.feature_image'). $this->event['Event']['feature_image']);
		
	}
	
	function admin_delete($id=null){
		$this->autoRender = false;
		$data=$this->request->data['Event']['id'];
		$action = $this->request->data['Event']['action'];
		$ans="0";
		foreach($data as $value){
			
			if($value!='0'){
				$event = $this->Event->find('first', array('conditions'=> array('Event.id' => $value)));
				if((int)$event['Event']['status']==2){
					continue;
				}
				
				if($action=='Publish'){
					$event['Event']['id'] = $value;
					$event['Event']['status']=1;
					$this->Event->create();
					$this->Event->save($event);
					$ans="1";
				}
				if($action=='Unpublish'){
					$event['Event']['id'] = $value;
					$event['Event']['status']=0;
					$this->Event->create();
					$this->Event->save($event);
					$ans="1";
				}
				if($action=='Delete'){
					if (!empty($event['Event']['feature_image'])) {
						   @unlink(WWW_ROOT."img/featureimage/". $event['Event']['feature_image']);
					}
					$this->Event->delete($value);
					$this->EventLocation->deleteAll(array('EventLocation.event_id' => $value));
					$ans="2";
				}
			}
		}
		if($ans=="1"){
			$this->Session->setFlash(__('Event has been '.strtolower($this->data['Event']['action']).'ed successfully', true));
		}
		else if($ans=="2"){
			$this->Session->setFlash(__('Event has been '.strtolower($this->data['Event']['action']).'d successfully', true));
		}else{
			$this->Session->setFlash(__('Please select events', true),'default','','error');
		}
		$this->redirect($this->request->data['Event']['redirect']);
                 
	}

	
		function validation(){
		
		if(!empty($this->request->data['Event']['form'])){
			if($this->request->data['Event']['form']=="event_add" && $this->request->data['Event']['status']==2){
				return true;
			}
			$this->Event->setValidation($this->request->data['Event']['form']);
		}else{
			throw new NotFoundException('404 Error - Event not found');
		}
		$this->Event->set($this->request->data);
		return $this->Event->validates();
	}
	public function ajax_validation($returnType = 'json'){
		//print_r($this->request->data);die;
		$this->autoRender = false;
		if(!empty($this->request->data)){
			if(!empty($this->request->data['Event']['form'])){
				$this->Event->setValidation($this->request->data['Event']['form']);
			}
			$this->Event->set($this->request->data);
			$result = array();
			if($this->request->data['Event']['form']=="event_add" && $this->request->data['Event']['status']==2){
				$result['error'] = 0;
			}else{
				if($this->Event->validates()){
					$result['error'] = 0;
				}else{
					$result['error'] = 1;
					$this->Session->setFlash(__('Please fill all the required fields'),'default',array(),'error');
				}
			}
			$errors = array();
			$result['errors'] = $this->Event->validationErrors;
			foreach($result['errors'] as $field => $data){
			  $errors['Event'.Inflector::camelize($field)] = array_pop($data);
			}
			$result['errors'] = $errors;
			$view = new View();
			
			$result['error_message'] = $view->element('admin/message');
			echo json_encode($result);
			return;
		}
		echo json_encode(array());
	}
	public function admin_settings(){
		$this->UserLib->add_authorize_action(array('admin_settings'));
		$this->UserLib->add_authenticate_action(array('admin_settings'));
		$this->UserLib->check_authenticate($this);
		$this->UserLib->check_authorize($this);
		$this->loadModel('Setting');
		if(!empty($this->request->data)){
			foreach($this->request->data['Event'] as $key => $value){
				if($key == 'url_back_redirect' || $key == 'form' ){
					continue;
				}
				if(is_array($value)){
					
					if($key=='feature_image'){
						
						$_options = array(
										'destination'=>Configure::read('Path.feature_image'),
										'image'=>$value,
									);
						$_file = $this->System->get_setting('evnt',$key);
						if(!empty($_file) && !empty($value['name'])){
							if(file_exists(Configure::read('Path.feature_image').$this->System->get_setting('page',$key))){
								unlink(Configure::read('Path.feature_image').$this->System->get_setting('page',$key));
							}
						}
						if($value['error'] > 0){
							$value=$_file;
						}else{
							//$value = $this->Upload->move_uploaded_file($value,$_options);
							$value = $this->System->Image->upload($_options);
						}
					}else if ($key=='home_page_blocks'){
						$value = json_encode($value);
					}else{
						continue;
					}
				}
				$value = addslashes($value);
				
				if($this->Setting->find('count',array('conditions'=>array('Setting.key'=>$key,'Setting.module'=>'event')))){
					$this->Setting->query("UPDATE `settings` SET `values`=\"$value\" , module=\"event\" WHERE `key`=\"$key\"");
				} else{
					$this->Setting->query("INSERT `settings` SET `values`=\"$value\"  , `key`=\"$key\" , module=\"event\"");
				}
				$this->Session->setFlash(__('Team Setting(s) has been saved successfully'));
			}
			$this->redirect(array('action'=>'settings','?'=>array('back'=>$this->request->data['Event']['url_back_redirect'])));
		}
		Cache::delete('site');
		$this->request->data['Event'] = $this->Setting->find('list',array('fields'=>array('Setting.key','Setting.values'),'conditions'=>array('Setting.module'=>'event')));
		$referer_url = $this->request->query('back');
		if(!empty($referer_url)){
			$referer_url= $this->request->query('back');
		}else{
			$referer_url=(Controller::referer()=="/")? Router::url('/admin/event_manager/settings',true) :Controller::referer();
		
		}
		$this->set('referer_url',$referer_url);
		
		
	}
	
}
?>